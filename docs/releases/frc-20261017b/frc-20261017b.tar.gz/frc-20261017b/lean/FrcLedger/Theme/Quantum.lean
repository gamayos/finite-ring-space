import Mathlib

/-!
# FrcLedger.Theme.Quantum — the quantum theme on Mathlib: the ledger's identities (22-quantum, 15 October 2026)

What the core states on every shell (`FrcCore/Theme/Observation.lean`, `Interference.lean`, `Composite.lean`) is read
here on the ledger itself:

* the Sorkin hierarchy on every commutative ring with an additive conjugation — the ledgers `ℤ[i]` and `ℤ[ζ_d]`
  among them (`sorkin_hierarchy`, `sorkin_second`, 22:C8, X8, P2);
* the ledger weight `z z̄ = N(z)` of a Gaussian-integer amplitude is a nonnegative rational integer, a realised tally
  (`pair_count_tally`, 22:C7, X1);
* the Hadamard layers on the Gaussian integers: `(1 + i)^{2m} = 2^m i^m`, the norm `2^k`, and the minimal
  denominator — `2` does not divide `i^m (1 + i)` (`gaussian_layers`, `gaussian_norm`, `gaussian_minimal`,
  `tally_norm_eq`, 22:C14, P5).

Exact throughout (`ℤ[i]`, commutative rings): the readings against the continuum — the Tsirelson value `2√2`, the
singlet law `cos(πΔ/40)` and the channel's chart `cos(φ/2)`, `sin(φ/2)` — are the chart theme's, in
`FrcLedger/Theme/Chart.lean` (section `quantum`), the one theme with the reals.
-/

namespace FRC.QuantumML

/-! ## The Sorkin hierarchy on the ledger -/

/-- The `k`-fold mixed difference of `f : R → R` along the directions `a 0, …, a (k−1)`. -/
def mixedDiff {R : Type*} [CommRing R] (a : ℕ → R) (f : R → R) : ℕ → R → R
  | 0, x => f x
  | k + 1, x => mixedDiff a f k (x + a k) - mixedDiff a f k x

/-- The second difference of the weight `w(x) = x c(x)` with `c` additive is the cross term `b c(a) + a c(b)`. -/
theorem sorkin_second {R : Type*} [CommRing R] {c : R → R} (hc : ∀ x y, c (x + y) = c x + c y) (a : ℕ → R)
    (x : R) : mixedDiff a (fun x => x * c x) 2 x = a 1 * c (a 0) + a 0 * c (a 1) := by
  simp only [mixedDiff, hc]
  ring

/-- 22:C8, X8, P2 — **the Sorkin hierarchy on the ledger**: on every commutative ring `R` (the ledgers `ℤ[i]`
and `ℤ[ζ_d]` among them) with an additive conjugation `c`, the `k`-fold mixed difference of the weight
`w(x) = x c(x)` vanishes for every `k ≥ 3` and every base point; so the interference terms `I_k` (the mixed difference
at the origin) are zero exactly from the third order on. -/
theorem sorkin_hierarchy {R : Type*} [CommRing R] {c : R → R} (hc : ∀ x y, c (x + y) = c x + c y) (a : ℕ → R) :
    ∀ k x, mixedDiff a (fun x => x * c x) (k + 3) x = 0
  | 0, x => by
    show mixedDiff a (fun x => x * c x) 2 (x + a 2) - mixedDiff a (fun x => x * c x) 2 x = 0
    rw [sorkin_second hc, sorkin_second hc, sub_self]
  | k + 1, x => by
    show mixedDiff a (fun x => x * c x) (k + 3) (x + a (k + 3)) - mixedDiff a (fun x => x * c x) (k + 3) x = 0
    rw [sorkin_hierarchy hc a k, sorkin_hierarchy hc a k, sub_self]

/-- 22:C8 — `I₂` is generically nonzero: on `ℤ[i]` with the conjugation and the paths `a = b = 1`, `I₂ = 2`. -/
theorem sorkin_second_witness :
    mixedDiff (fun _ => (1 : GaussianInt)) (fun x => x * star x) 2 0 = 2 := by
  rw [sorkin_second (fun x y => star_add x y)]
  decide

/-! ## The Hadamard layers on the Gaussian integers -/

/-- The Gaussian unit `i` and the ramified `1 + i`. -/
def gi : GaussianInt := ⟨0, 1⟩
def onePlusI : GaussianInt := ⟨1, 1⟩

theorem onePlusI_sq : onePlusI ^ 2 = 2 * gi := by decide

theorem gi_norm : Zsqrtd.norm gi = 1 := by decide
theorem onePlusI_norm : Zsqrtd.norm onePlusI = 2 := by decide

/-- 22:C14 — `2m` balanced layers: `(1 + i)^{2m} = 2^m i^m`, and `2m + 1` layers give `2^m i^m (1 + i)`. -/
theorem gaussian_layers (m : ℕ) :
    onePlusI ^ (2 * m) = 2 ^ m * gi ^ m ∧ onePlusI ^ (2 * m + 1) = 2 ^ m * gi ^ m * onePlusI := by
  constructor
  · rw [pow_mul, onePlusI_sq, mul_pow]
  · rw [pow_succ, pow_mul, onePlusI_sq, mul_pow]

theorem norm_pow (x : GaussianInt) : ∀ k : ℕ, Zsqrtd.norm (x ^ k) = (Zsqrtd.norm x) ^ k
  | 0 => by simp
  | k + 1 => by rw [pow_succ, Zsqrtd.norm_mul, norm_pow x k, pow_succ]

/-- 22:C14 — the norm of `k` layers is `2^k`. -/
theorem gaussian_norm (k : ℕ) : Zsqrtd.norm (onePlusI ^ k) = 2 ^ k := by
  rw [norm_pow, onePlusI_norm]

/-- 22:C14 — the minimal denominator: `2` does not divide `i^m (1 + i)` in `ℤ[i]` (its norm is `2`, not a multiple
of `4`), so the amplitude `i^m (1 + i)/2^{m+1}` of `2m + 1` layers has the denominator `2^{m+1}` exactly, and
`i^m/2^m` of `2m` layers the denominator `2^m` (`i^m` a unit). -/
theorem gaussian_minimal (m : ℕ) : ¬ (2 : GaussianInt) ∣ gi ^ m * onePlusI := by
  intro ⟨z, hz⟩
  have h := congrArg Zsqrtd.norm hz
  rw [Zsqrtd.norm_mul, Zsqrtd.norm_mul, norm_pow, gi_norm, onePlusI_norm, one_pow, one_mul] at h
  have h2 : Zsqrtd.norm (2 : GaussianInt) = 4 := by decide
  rw [h2] at h
  omega

/-- 22:C7, 22:X1 — the ledger weight is a realised tally: for a Gaussian-integer amplitude `z` the weight `z z̄` is
the norm `N(z) = a² + b²`, a nonnegative rational integer (the coincidence count). -/
theorem pair_count_tally (z : GaussianInt) : z * star z = (Zsqrtd.norm z : GaussianInt) ∧ 0 ≤ Zsqrtd.norm z :=
  ⟨(Zsqrtd.norm_eq_mul_conj z).symm, Zsqrtd.norm_nonneg (by norm_num) z⟩

/-- 22:C14, P5 — the minimal tally norm `T(k) = 2^{k + [k odd]}` is the square of the minimal denominator
`2^{⌈k/2⌉}`. -/
theorem tally_norm_eq (k : ℕ) : 2 ^ (k + k % 2) = (2 ^ ((k + 1) / 2)) ^ 2 := by
  rw [← pow_mul]
  congr 1
  omega

end FRC.QuantumML
