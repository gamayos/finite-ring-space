import Mathlib

/-!
# 8-dirac — Schrödinger and Dirac dynamics over the finite substrate: the ledger predicates in Lean (2026-09-20)

Rows of the predicate ledger of *Schrödinger and Dirac Dynamics over Finite Substrate* (tree
`8-dirac-20260709`). The coefficient field `K = F[w]/(w² − ν)` on components with its Frobenius conjugation
and norm, a field when `ν` is a nonsquare, `|K| = |F|²` (A2, B1); the square-class arithmetic on
`ZMod p`: two nonsquares differ by a square and the Lorentzian form depends on `ν` through its class alone
(B2); chronon parity — `g^k` is a square exactly when `k` is even, so the drive and its inverse are
nonsquares and `2`, `2⁻¹`, `−2` and the quarter-turn `i = g^{3κ}` are squares exactly when `κ` is even (B3,
B5); the two seats `ν = g = c²·(2g)` (B4); the norm growth `N(gz) = g² N(z)` (B6); over `K` every base element
is a square, the dichotomy collapsing (B7). The Hermitian form on functions of a finite set — symmetric,
nondegenerate, the translations unitary with `T_u† = T_{−u}`, the Laplacian and the Hamiltonians
self-adjoint (C2); the Cayley step unitary for any anti-involution, hence for the form and for the `X`-form
(C4, D10); the Cayley transform norm-one valued, injective, inverted by the orientation gauge, and the torus
of `|F| + 1` points (C5); kinetic Hamiltonians nilpotent with `𝒜(H) = K⁻`, the Cayley step of period exactly
`p` (C6, E4). The Clifford relations from `i² = −1`, `w² = ν` alone, by the block computation of the paper's
proof (D2); the boost torus — `A² − νB² = 1`, the group law of the entries, the boost `z ↦ z/z̄` a
homomorphism onto `N¹` with kernel the scalar line (Hilbert 90), `N¹ ≅ C_{p+1}` cyclic, an element of order
three exactly when `3 ∣ p + 1` (D5); spin conjugation and the transported gammas (D6, D7); the spinor twist
`X = γ⁰γ¹γ³` with `X² = ν`, its commutations, the dagger signs with `γ²` the obstruction, `(γ^μ)†X = −Xγ^μ`
and the failure of the `γ⁰`-twist (D9); the transport of the form `S†XS = δX` (D11); the worked shells
`𝔽₁₃`, `𝔽₁₇` and the laboratory Carrier (D12, B4). The loss factor and the power-map counts on the cyclic
group `(ZMod p)ˣ` (E2, E3), the potential period `p + 1` attained (E4); the latitude identities (F2); the
drive on the characters — the eigenvalues `g^{−k}`, the isotropy `Σ_x x^{2k}` by the character sum, the
exceptional lines `±1` (F3); the sector separation, no meridional plane waves, the dispersion relation (F4).
Classical (tier 2) on Mathlib's hierarchy; the finite content — parity, latitude and spectral rows on every
frame, the worked shells decided by the kernel — is proved with no axioms in `FrcCore/Dirac.lean`. Outside
both modules: the factorization `(𝒟 − m)(𝒟 + m) = KG − m²` (D3), the pullback identity and the transported
factorization (D7), the covariance of the transported family (D8), the operator clauses of D9 (`T − T⁻¹`
nilpotent and anti-self-adjoint, `𝒟^s` `X`-self-adjoint and nilpotent — the package's instances), the massless
clause and the numerals `5`, `75`, `150` of D10 (the Cayley step's `X`-unitarity is `cayley_unitary` given that
self-adjointness), the pullback and transport clauses of D11, the frame covariance of C2, the surjectivity
of the Cayley transform onto `N¹ ∖ {−1}` (C5 — injectivity and the count are proved), the mixed datum `1563`
of E4, the general count of the unit-norm circle (F2 — instances in the core), and the realisation rows B8,
D13, F5.
-/

namespace FRC.Dirac

@[ext]
structure Ext (F : Type*) (ν : F) where
  re : F
  im : F

namespace Ext
variable {F : Type*} [CommRing F] {ν : F}

instance : Zero (Ext F ν) := ⟨⟨0, 0⟩⟩
instance : One (Ext F ν) := ⟨⟨1, 0⟩⟩
instance : Add (Ext F ν) := ⟨fun z z' => ⟨z.re + z'.re, z.im + z'.im⟩⟩
instance : Neg (Ext F ν) := ⟨fun z => ⟨-z.re, -z.im⟩⟩
instance : Sub (Ext F ν) := ⟨fun z z' => ⟨z.re - z'.re, z.im - z'.im⟩⟩
instance : Mul (Ext F ν) := ⟨fun z z' => ⟨z.re * z'.re + ν * (z.im * z'.im), z.re * z'.im + z.im * z'.re⟩⟩
instance : SMul ℕ (Ext F ν) := ⟨fun n z => ⟨n • z.re, n • z.im⟩⟩
instance : SMul ℤ (Ext F ν) := ⟨fun n z => ⟨n • z.re, n • z.im⟩⟩

@[simp] theorem zero_re : (0 : Ext F ν).re = 0 := rfl
@[simp] theorem zero_im : (0 : Ext F ν).im = 0 := rfl
@[simp] theorem one_re : (1 : Ext F ν).re = 1 := rfl
@[simp] theorem one_im : (1 : Ext F ν).im = 0 := rfl
@[simp] theorem add_re (z z' : Ext F ν) : (z + z').re = z.re + z'.re := rfl
@[simp] theorem add_im (z z' : Ext F ν) : (z + z').im = z.im + z'.im := rfl
@[simp] theorem neg_re (z : Ext F ν) : (-z).re = -z.re := rfl
@[simp] theorem neg_im (z : Ext F ν) : (-z).im = -z.im := rfl
@[simp] theorem sub_re (z z' : Ext F ν) : (z - z').re = z.re - z'.re := rfl
@[simp] theorem sub_im (z z' : Ext F ν) : (z - z').im = z.im - z'.im := rfl
@[simp] theorem mul_re (z z' : Ext F ν) : (z * z').re = z.re * z'.re + ν * (z.im * z'.im) := rfl
@[simp] theorem mul_im (z z' : Ext F ν) : (z * z').im = z.re * z'.im + z.im * z'.re := rfl
@[simp] theorem nsmul_re (n : ℕ) (z : Ext F ν) : (n • z).re = n • z.re := rfl
@[simp] theorem nsmul_im (n : ℕ) (z : Ext F ν) : (n • z).im = n • z.im := rfl
@[simp] theorem zsmul_re (n : ℤ) (z : Ext F ν) : (n • z).re = n • z.re := rfl
@[simp] theorem zsmul_im (n : ℤ) (z : Ext F ν) : (n • z).im = n • z.im := rfl

instance : CommRing (Ext F ν) where
  add_assoc _ _ _ := by ext <;> simp [add_assoc]
  zero_add _ := by ext <;> simp
  add_zero _ := by ext <;> simp
  add_comm _ _ := by ext <;> simp [add_comm]
  nsmul := (· • ·)
  nsmul_zero _ := by ext <;> simp
  nsmul_succ _ _ := by ext <;> simp [add_smul]
  zsmul := (· • ·)
  zsmul_zero' _ := by ext <;> simp
  zsmul_succ' _ _ := by ext <;> simp [add_smul]
  zsmul_neg' _ _ := by ext <;> simp [add_smul] <;> ring
  neg_add_cancel _ := by ext <;> simp
  sub_eq_add_neg _ _ := by ext <;> simp [sub_eq_add_neg]
  mul_assoc _ _ _ := by ext <;> simp <;> ring
  one_mul _ := by ext <;> simp
  mul_one _ := by ext <;> simp
  left_distrib _ _ _ := by ext <;> simp <;> ring
  right_distrib _ _ _ := by ext <;> simp <;> ring
  zero_mul _ := by ext <;> simp
  mul_zero _ := by ext <;> simp
  mul_comm _ _ := by ext <;> simp <;> ring

def ofBase (a : F) : Ext F ν := ⟨a, 0⟩
def w : Ext F ν := ⟨0, 1⟩
def conj (z : Ext F ν) : Ext F ν := ⟨z.re, -z.im⟩
def norm (z : Ext F ν) : F := z.re * z.re - ν * (z.im * z.im)

@[simp] theorem ofBase_re (a : F) : (ofBase a : Ext F ν).re = a := rfl
@[simp] theorem ofBase_im (a : F) : (ofBase a : Ext F ν).im = 0 := rfl
@[simp] theorem w_re : (w : Ext F ν).re = 0 := rfl
@[simp] theorem w_im : (w : Ext F ν).im = 1 := rfl
@[simp] theorem conj_re (z : Ext F ν) : (conj z).re = z.re := rfl
@[simp] theorem conj_im (z : Ext F ν) : (conj z).im = -z.im := rfl

theorem w_sq : (w : Ext F ν) ^ 2 = ofBase ν := by ext <;> simp [sq]
theorem conj_mul (z z' : Ext F ν) : conj (z * z') = conj z * conj z' := by ext <;> simp <;> ring
theorem conj_add (z z' : Ext F ν) : conj (z + z') = conj z + conj z' := by ext <;> simp [add_comm]
theorem conj_conj (z : Ext F ν) : conj (conj z) = z := by ext <;> simp
theorem conj_one : conj (1 : Ext F ν) = 1 := by ext <;> simp
theorem mul_conj (z : Ext F ν) : z * conj z = ofBase (norm z) := by ext <;> simp [norm] <;> ring
/-- 8:A2 — the norm is multiplicative: `N(zz') = N(z)N(z')`. -/
theorem norm_mul (z z' : Ext F ν) : norm (z * z') = norm z * norm z' := by
  simp only [norm, mul_re, mul_im]; ring
theorem ofBase_mul (a b : F) : (ofBase (a * b) : Ext F ν) = ofBase a * ofBase b := by ext <;> simp
theorem ofBase_add (a b : F) : (ofBase (a + b) : Ext F ν) = ofBase a + ofBase b := by ext <;> simp
theorem ofBase_one : (ofBase 1 : Ext F ν) = 1 := rfl
theorem ofBase_zero : (ofBase 0 : Ext F ν) = 0 := rfl
theorem ofBase_injective : Function.Injective (ofBase : F → Ext F ν) := fun a b h => by
  simpa using congrArg re h
theorem conj_ofBase (a : F) : conj (ofBase a : Ext F ν) = ofBase a := by ext <;> simp
theorem conj_w : conj (w : Ext F ν) = -w := by ext <;> simp
theorem conj_eq_self_iff (z : Ext F ν) (h2 : (2 : F) ≠ 0) [NoZeroDivisors F] :
    conj z = z ↔ z.im = 0 := by
  constructor
  · intro h
    have := congrArg im h
    simp at this
    have h' : (2 : F) * z.im = 0 := by linear_combination -this
    rcases mul_eq_zero.1 h' with h0 | h0
    · exact absurd h0 h2
    · exact h0
  · intro h; ext <;> simp [h]
theorem conj_eq_neg_iff (z : Ext F ν) (h2 : (2 : F) ≠ 0) [NoZeroDivisors F] :
    conj z = -z ↔ z.re = 0 := by
  constructor
  · intro h
    have := congrArg re h
    simp at this
    have h' : (2 : F) * z.re = 0 := by linear_combination this
    rcases mul_eq_zero.1 h' with h0 | h0
    · exact absurd h0 h2
    · exact h0
  · intro h; ext <;> simp [h]

instance : StarRing (Ext F ν) where
  star := conj
  star_involutive := conj_conj
  star_mul z z' := by rw [conj_mul, mul_comm]
  star_add z z' := conj_add z z'

theorem star_def (z : Ext F ν) : star z = conj z := rfl

/-- `w` generates: `z = re + im · w`. -/
theorem eq_re_add_im_w (z : Ext F ν) : z = ofBase z.re + ofBase z.im * w := by ext <;> simp

end Ext

/-! ## The field: `ν` a nonsquare makes `K` a field -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

theorem norm_eq_zero_iff (hν : ¬ IsSquare ν) (z : Ext F ν) : norm z = 0 ↔ z = 0 := by
  constructor
  · intro h
    by_cases hb : z.im = 0
    · have : z.re * z.re = 0 := by simpa [norm, hb] using h
      ext <;> simp [hb, mul_self_eq_zero.1 this]
    · exfalso; apply hν
      refine ⟨z.re / z.im, ?_⟩
      have : z.re * z.re = ν * (z.im * z.im) := by
        simpa [norm, sub_eq_zero] using h
      rw [div_mul_div_comm, eq_div_iff (mul_ne_zero hb hb), this]
  · rintro rfl; simp [norm]

noncomputable instance instInv : Inv (Ext F ν) := ⟨fun z => ofBase (norm z)⁻¹ * conj z⟩

theorem inv_def (z : Ext F ν) : z⁻¹ = ofBase (norm z)⁻¹ * conj z := rfl

theorem mul_inv_cancel' (hν : ¬ IsSquare ν) (z : Ext F ν) (hz : z ≠ 0) : z * z⁻¹ = 1 := by
  rw [inv_def, mul_left_comm, mul_conj, ← ofBase_mul, inv_mul_cancel₀ ((norm_eq_zero_iff hν z).not.2 hz)]
  rfl

/-- 8:A2 — the field structure under `¬ IsSquare ν`, `z⁻¹ = z̄/N(z)` (a `def`, not an instance: the hypothesis is
not a class). -/
@[instance_reducible] noncomputable def field (hν : ¬ IsSquare ν) : Field (Ext F ν) where
  __ := (inferInstance : CommRing (Ext F ν))
  inv := (·⁻¹)
  exists_pair_ne := ⟨0, 1, fun h => by simpa using congrArg re h⟩
  mul_inv_cancel z hz := mul_inv_cancel' hν z hz
  inv_zero := by ext <;> simp [inv_def, norm]
  nnqsmul := _
  nnqsmul_def _ _ := rfl
  qsmul := _
  qsmul_def _ _ := rfl

end Ext

/-! ## The norm-one torus and the Cayley transform -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

/-- The finite Cayley transform `φ_α(t) = (1 + αt)/(1 − αt)` for `α = k w`, computed by the conjugate:
`(1 + αt) · conj(1 − αt) / N(1 − αt)`. -/
noncomputable def cayley (k t : F) : Ext F ν :=
  (1 + ofBase (k * t) * w) * (1 - ofBase (k * t) * w)⁻¹

theorem norm_ofBase_mul (a : F) (z : Ext F ν) : norm (ofBase a * z) = a ^ 2 * norm z := by
  simp only [norm, mul_re, mul_im, ofBase_re, ofBase_im]; ring

theorem norm_one_add_kw (k t : F) : norm ((1 : Ext F ν) + ofBase (k * t) * w) = 1 - ν * (k * t) ^ 2 := by
  simp only [norm, add_re, add_im, one_re, one_im, mul_re, mul_im, ofBase_re, ofBase_im, w_re, w_im]; ring

theorem norm_one_sub_kw (k t : F) : norm ((1 : Ext F ν) - ofBase (k * t) * w) = 1 - ν * (k * t) ^ 2 := by
  simp only [norm, sub_re, sub_im, one_re, one_im, mul_re, mul_im, ofBase_re, ofBase_im, w_re, w_im]; ring

theorem norm_conj (z : Ext F ν) : norm (conj z) = norm z := by simp [norm]

/-- `N(z⁻¹) = N(z)⁻¹`. -/
theorem norm_inv (hν : ¬ IsSquare ν) (z : Ext F ν) : norm z⁻¹ = (norm z)⁻¹ := by
  by_cases hz : z = 0
  · subst hz
    rw [inv_def]
    simp [norm]
  · rw [inv_def, norm_ofBase_mul, norm_conj]
    have := (norm_eq_zero_iff hν z).not.2 hz
    field_simp

theorem one_sub_nu_sq_ne_zero (hν : ¬ IsSquare ν) (t : F) : 1 - ν * t ^ 2 ≠ 0 := by
  intro h
  by_cases ht : t = 0
  · simp [ht] at h
  · apply hν
    refine ⟨t⁻¹, ?_⟩
    field_simp
    linear_combination -h

/-- 8:C5 — the Cayley transform takes values in the norm-one torus: `N(φ_α(λ)) = 1` for every `λ ∈ F`, the
denominator never vanishing (Theorem `cayley-transform`). -/
theorem cayley_norm (hν : ¬ IsSquare ν) (k t : F) : norm (cayley k t : Ext F ν) = 1 := by
  unfold cayley
  rw [norm_mul, norm_inv hν, norm_one_add_kw, norm_one_sub_kw]
  exact mul_inv_cancel₀ (one_sub_nu_sq_ne_zero hν _)

end Ext

/-! ## The norm-one torus as a group, the boost homomorphism and Hilbert 90 (8:D5, C5) -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

/-- Conjugation as a ring homomorphism. -/
def conjHom : Ext F ν →+* Ext F ν where
  toFun := conj
  map_one' := conj_one
  map_mul' := conj_mul
  map_zero' := by ext <;> simp
  map_add' := conj_add

@[simp] theorem conjHom_apply (z : Ext F ν) : conjHom z = conj z := rfl

instance : Nontrivial (Ext F ν) := ⟨⟨0, 1, fun h => by simpa using congrArg re h⟩⟩

/-- The base field as a ring homomorphism into `K`. -/
def ofBaseHom : F →+* Ext F ν where
  toFun := ofBase
  map_one' := rfl
  map_mul' := ofBase_mul
  map_zero' := rfl
  map_add' := ofBase_add

@[simp] theorem ofBaseHom_apply (a : F) : ofBaseHom a = (ofBase a : Ext F ν) := rfl

theorem norm_one : norm (1 : Ext F ν) = 1 := by simp [norm]

/-- `N¹`, the norm-one torus, as a subgroup of the units of `K` (no field structure needed). -/
def normOneGroup (F : Type*) [Field F] (ν : F) : Subgroup (Ext F ν)ˣ where
  carrier := {u | norm (u : Ext F ν) = 1}
  mul_mem' {a b} ha hb := by
    simp only [Set.mem_setOf_eq, Units.val_mul] at *
    rw [norm_mul, ha, hb, one_mul]
  one_mem' := by simp [norm_one]
  inv_mem' {a} ha := by
    simp only [Set.mem_setOf_eq] at *
    have h := norm_mul (a : Ext F ν) (↑a⁻¹ : Ext F ν)
    rw [Units.mul_inv, norm_one, ha, one_mul] at h
    exact h.symm

theorem mem_normOneGroup {u : (Ext F ν)ˣ} : u ∈ normOneGroup F ν ↔ norm (u : Ext F ν) = 1 := Iff.rfl

/-- Conjugation on the units. -/
def conjUnits : (Ext F ν)ˣ →* (Ext F ν)ˣ where
  toFun z := ⟨conj z, conj (↑z⁻¹ : Ext F ν), by rw [← conj_mul, Units.mul_inv, conj_one],
    by rw [← conj_mul, Units.inv_mul, conj_one]⟩
  map_one' := Units.ext (by simp [conj_one])
  map_mul' z z' := Units.ext (by simp [conj_mul])

@[simp] theorem conjUnits_val (z : (Ext F ν)ˣ) : ((conjUnits z : (Ext F ν)ˣ) : Ext F ν) = conj z := rfl

/-- The boost map `z ↦ z / z̄` on the units, a homomorphism (Lemma `boost-torus`). -/
def boost : (Ext F ν)ˣ →* (Ext F ν)ˣ where
  toFun z := z * (conjUnits z)⁻¹
  map_one' := by simp
  map_mul' z z' := by
    simp only [map_mul, mul_inv]
    exact mul_mul_mul_comm _ _ _ _

theorem boost_def (z : (Ext F ν)ˣ) : boost z = z * (conjUnits z)⁻¹ := rfl

theorem boost_val (z : (Ext F ν)ˣ) : (boost z : Ext F ν) * conj (z : Ext F ν) = (z : Ext F ν) := by
  rw [boost_def, Units.val_mul, mul_assoc, ← conjUnits_val, ← Units.val_mul, inv_mul_cancel, Units.val_one,
    mul_one]

/-- 8:D5 — the boost of every unit lies in `N¹`: `N(z/z̄) = 1`. -/
theorem boost_mem (z : (Ext F ν)ˣ) : boost z ∈ normOneGroup F ν := by
  rw [mem_normOneGroup]
  have h := congrArg norm (boost_val z)
  rw [norm_mul, norm_conj] at h
  have hz : norm (z : Ext F ν) ≠ 0 := by
    intro h0
    have := norm_mul (z : Ext F ν) (↑z⁻¹ : Ext F ν)
    rw [Units.mul_inv, norm_one, h0, zero_mul] at this
    exact one_ne_zero this
  exact mul_right_cancel₀ hz (by rw [h, one_mul])

/-- 8:D5 — the kernel of the boost is the scalar line: `z/z̄ = 1 ⟺ z̄ = z ⟺ z ∈ F`. -/
theorem boost_eq_one_iff (h2 : (2 : F) ≠ 0) [NoZeroDivisors F] (z : (Ext F ν)ˣ) :
    boost z = 1 ↔ (z : Ext F ν).im = 0 := by
  rw [← conj_eq_self_iff (z : Ext F ν) h2, boost_def, mul_inv_eq_one]
  constructor
  · intro h; exact (congrArg Units.val h).symm
  · intro h; exact Units.ext h.symm

/-- 8:D5, 8:A2 — Hilbert 90 on the torus: every `u ∈ N¹` is a boost — `u = (1 + u)/(1 + ū)` for `u ≠ −1`, and
`−1 = w/w̄`. -/
theorem exists_boost_eq (hν : ¬ IsSquare ν) {u : (Ext F ν)ˣ} (hu : u ∈ normOneGroup F ν) :
    ∃ z : (Ext F ν)ˣ, boost z = u := by
  letI := field hν
  rw [mem_normOneGroup] at hu
  have hconj : conj (u : Ext F ν) = ((u⁻¹ : (Ext F ν)ˣ) : Ext F ν) := by
    have := mul_conj (u : Ext F ν)
    rw [hu, ofBase_one] at this
    exact (Units.inv_eq_of_mul_eq_one_right this).symm
  by_cases hm : (u : Ext F ν) = -1
  · -- `u = −1 = w / w̄`
    have hw : (w : Ext F ν) ≠ 0 := fun h => by simpa using congrArg im h
    refine ⟨Units.mk0 w hw, Units.ext ?_⟩
    apply mul_right_cancel₀ (show conj (w : Ext F ν) ≠ 0 by rw [conj_w]; exact neg_ne_zero.2 hw)
    have hb := boost_val (Units.mk0 w hw)
    rw [Units.val_mk0] at hb
    rw [hb, hm, conj_w, neg_one_mul, neg_neg]
  · have h1 : (1 : Ext F ν) + (u : Ext F ν) ≠ 0 := fun h => hm (by linear_combination h)
    refine ⟨Units.mk0 ((1 : Ext F ν) + (u : Ext F ν)) h1, Units.ext ?_⟩
    apply mul_right_cancel₀ (show conj ((1 : Ext F ν) + (u : Ext F ν)) ≠ 0 by
      intro h
      have := congrArg conj h
      rw [conj_conj] at this
      exact h1 (this.trans (by ext <;> simp)))
    have hb := boost_val (Units.mk0 ((1 : Ext F ν) + (u : Ext F ν)) h1)
    rw [Units.val_mk0] at hb
    rw [hb, conj_add, conj_one, hconj]
    have : (u : Ext F ν) * ((u⁻¹ : (Ext F ν)ˣ) : Ext F ν) = 1 := Units.mul_inv u
    linear_combination -this

end Ext

/-! ## The cardinalities: `|K| = |F|²`, `|N¹| = |F| + 1` (8:C5, D5) -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

/-- `K ≃ F × F` on components. -/
def equivProd : Ext F ν ≃ F × F where
  toFun z := (z.re, z.im)
  invFun x := ⟨x.1, x.2⟩
  left_inv z := by cases z; rfl
  right_inv x := by cases x; rfl

instance [Finite F] : Finite (Ext F ν) := Finite.of_equiv _ (equivProd (ν := ν)).symm

omit [Field F] in
theorem card_ext [CommRing F] [Finite F] : Nat.card (Ext F ν) = Nat.card F ^ 2 := by
  rw [Nat.card_congr (equivProd (ν := ν)), Nat.card_prod, sq]

/-- The kernel of the boost is the image of `Fˣ`: its cardinality is `|F| − 1`. -/
def baseUnits (h2 : (2 : F) ≠ 0) : Fˣ ≃ (boost (F := F) (ν := ν)).ker where
  toFun a := ⟨Units.map (ofBaseHom (ν := ν)).toMonoidHom a, by
      rw [MonoidHom.mem_ker, boost_eq_one_iff h2]; rfl⟩
  invFun z := Units.mk0 ((z : (Ext F ν)ˣ) : Ext F ν).re (by
      intro h
      have hz := (z : (Ext F ν)ˣ).ne_zero
      have him : ((z : (Ext F ν)ˣ) : Ext F ν).im = 0 := (boost_eq_one_iff h2 _).1 (MonoidHom.mem_ker.1 z.2)
      exact hz (by ext <;> simp [h, him]))
  left_inv a := by ext; rfl
  right_inv z := by
    have him : ((z : (Ext F ν)ˣ) : Ext F ν).im = 0 := (boost_eq_one_iff h2 _).1 (MonoidHom.mem_ker.1 z.2)
    apply Subtype.ext; apply Units.ext
    ext
    · rfl
    · exact him.symm

/-- 8:D5, 8:C5 — the torus has `|F| + 1` elements: `|Kˣ| = |ker| · |N¹|`, `(q² − 1) = (q − 1)(q + 1)`. -/
theorem card_normOneGroup [Finite F] (hν : ¬ IsSquare ν) (h2 : (2 : F) ≠ 0) :
    Nat.card (normOneGroup F ν) = Nat.card F + 1 := by
  letI := field hν
  have hrange : (boost (F := F) (ν := ν)).range = normOneGroup F ν := by
    ext u
    constructor
    · rintro ⟨z, rfl⟩; exact boost_mem z
    · intro hu; exact exists_boost_eq hν hu
  have h1 : Nat.card (Ext F ν)ˣ = Nat.card (Ext F ν) - 1 := Nat.card_units _
  have h2' : Nat.card (Ext F ν)ˣ = Nat.card ((Ext F ν)ˣ ⧸ (boost (F := F) (ν := ν)).ker) * Nat.card (boost (F := F) (ν := ν)).ker :=
    Subgroup.card_eq_card_quotient_mul_card_subgroup _
  have h3 : Nat.card ((Ext F ν)ˣ ⧸ (boost (F := F) (ν := ν)).ker) = Nat.card (normOneGroup F ν) := by
    rw [Nat.card_congr (QuotientGroup.quotientKerEquivRange (boost (F := F) (ν := ν))).toEquiv, hrange]
  have h4 : Nat.card (boost (F := F) (ν := ν)).ker = Nat.card F - 1 := by
    rw [← Nat.card_congr (baseUnits h2), Nat.card_units]
  have hq : 2 ≤ Nat.card F := by
    have := Nat.card_pos (α := F)
    by_contra hlt
    have h1' : Nat.card F = 1 := by omega
    have := Nat.card_eq_one_iff_unique.1 h1'
    obtain ⟨hsub, _⟩ := this
    exact one_ne_zero (hsub.elim 1 0)
  rw [h3, h4] at h2'
  rw [card_ext] at h1
  -- (q² − 1) = N · (q − 1)  ⇒  N = q + 1
  have key : Nat.card F ^ 2 - 1 = Nat.card (normOneGroup F ν) * (Nat.card F - 1) := by rw [← h1]; exact h2'
  have hsq : Nat.card F ^ 2 - 1 = (Nat.card F + 1) * (Nat.card F - 1) := by
    have := sq_tsub_sq (Nat.card F) 1
    rw [one_pow] at this
    exact this
  rw [hsq] at key
  exact (Nat.eq_of_mul_eq_mul_right (by omega) key).symm

end Ext

/-! ## Field-generic lemmas (the `ZMod p` instances under `Fact p.Prime` are not `ring`-friendly) -/
section generic
variable {K : Type*} [Field K]

theorem inv_square_iff (a : K) : IsSquare a⁻¹ ↔ IsSquare a := by
  constructor
  · rintro ⟨r, hr⟩; exact ⟨r⁻¹, by rw [← mul_inv, ← hr, inv_inv]⟩
  · rintro ⟨r, hr⟩; exact ⟨r⁻¹, by rw [← mul_inv, ← hr]⟩

theorem neg_two_square_iff {i : K} (hi : -1 = i * i) : IsSquare (-2 : K) ↔ IsSquare (2 : K) := by
  constructor
  · rintro ⟨r, hr⟩; exact ⟨i * r, by linear_combination (r * r) * hi - hr⟩
  · rintro ⟨r, hr⟩; exact ⟨i * r, by linear_combination (r * r) * hi - hr⟩

theorem three_kappa_pow (g : K) (κ : ℕ) (h : g ^ (2 * κ) = -1) : g ^ (3 * κ) = -g ^ κ := by
  rw [show 3 * κ = 2 * κ + κ by ring, pow_add, h, neg_one_mul]

theorem sq_eq_one_cases {x : K} (h : x ^ 2 = 1) : x = 1 ∨ x = -1 := by
  rw [sq] at h; exact mul_self_eq_one_iff.1 h

theorem neg_inv_of_mul {a c : K} (hc : c ≠ 0) (h : c * a = -1) : a = -c⁻¹ := by
  field_simp; linear_combination h

theorem three_quarters {a : K} (h4 : (4 : K) ≠ 0) (h : a = -4⁻¹) : 1 + a = 3 * 4⁻¹ := by
  rw [h]; field_simp; ring

theorem half_neg {a : K} (h2 : (2 : K) ≠ 0) (h : 4 * a = -1) : 2 * a = -2⁻¹ := by
  field_simp; linear_combination h

theorem four_ne_zero_of_two {K : Type*} [Ring K] (h : (2 : K) ≠ 0) [NoZeroDivisors K] : (4 : K) ≠ 0 := by
  intro h4; apply h
  have : (4 : K) = 2 * 2 := by norm_num
  rw [this] at h4
  rcases mul_eq_zero.1 h4 with h0 | h0 <;> exact h0

end generic

/-! ## Chronon parity (8:B5, B3, B4) on `ZMod p` -/
section parity
variable {p : ℕ} [hp : Fact (Nat.Prime p)]

/-- 8:B5 — the square class is chronon parity: for a primitive root `g` (`orderOf g = p − 1`), `g^k` is a
square exactly when `k` is even (Theorem `parity`). -/
theorem parity_iff {g : ZMod p} (hg : orderOf g = p - 1) (hodd : p % 2 = 1) (k : ℕ) :
    IsSquare (g ^ k) ↔ Even k := by
  have hg0 : g ≠ 0 := by
    rintro rfl
    have := hp.out.two_le
    have h : orderOf (0 : ZMod p) = 0 := by
      rw [orderOf_eq_zero_iff']
      intro n hn h0
      rw [zero_pow hn.ne'] at h0
      exact zero_ne_one h0
    omega
  have hgk : g ^ k ≠ 0 := pow_ne_zero k hg0
  rw [ZMod.euler_criterion p hgk, ← pow_mul, ← orderOf_dvd_iff_pow_eq_one, hg]
  have hp2 : p - 1 = 2 * (p / 2) := by have := hp.out.two_le; omega
  rw [hp2]
  constructor
  · rintro ⟨c, hc⟩
    have hpos : 0 < p / 2 := by have := hp.out.two_le; omega
    have : k = 2 * c := Nat.eq_of_mul_eq_mul_right hpos (by rw [hc]; ring)
    exact ⟨c, by omega⟩
  · rintro ⟨c, rfl⟩
    exact ⟨c, by ring⟩

/-- 8:B3 — the drive is a nonsquare (`g^{(p−1)/2} = −1`), and so is its inverse `g^{p−2}`: `[g⁻¹] = [g]`. -/
theorem drive_nonsquare {g : ZMod p} (hg : orderOf g = p - 1) (hodd : p % 2 = 1) :
    ¬ IsSquare g ∧ ¬ IsSquare g⁻¹ := by
  have h1 := parity_iff hg hodd 1
  have h2 := parity_iff hg hodd (p - 2)
  rw [pow_one] at h1
  have hinv : g⁻¹ = g ^ (p - 2) := by
    have hg0 : g ≠ 0 := by
      rintro rfl
      have := hp.out.two_le
      have h : orderOf (0 : ZMod p) = 0 := by
        rw [orderOf_eq_zero_iff']
        intro n hn h0
        rw [zero_pow hn.ne'] at h0
        exact zero_ne_one h0
      omega
    have : g ^ (p - 1) = 1 := by rw [← hg]; exact pow_orderOf_eq_one g
    have hp3 : p - 1 = (p - 2) + 1 := by have := hp.out.two_le; omega
    rw [hp3, pow_succ] at this
    exact (eq_inv_of_mul_eq_one_left this).symm
  refine ⟨fun h => ?_, fun h => ?_⟩
  · exact Nat.not_even_one (h1.1 h)
  · rw [hinv] at h
    obtain ⟨c, hc⟩ := h2.1 h
    have := hp.out.two_le
    omega

/-- 8:B3, 8:B4 — on the shell `p = 4κ + 1`: `2` is a square ⟺ `κ` even (the second supplementary law), and
so `2⁻¹ = c²` and `−2` (`−1` a square); the quarter-turn `i = g^{−κ} = g^{3κ}` is a square ⟺ `κ` even. -/
theorem named_residues (κ : ℕ) [hp' : Fact (Nat.Prime (4 * κ + 1))] {g : ZMod (4 * κ + 1)}
    (hg : orderOf g = 4 * κ) :
    (IsSquare (2 : ZMod (4 * κ + 1)) ↔ Even κ) ∧ (IsSquare (2⁻¹ : ZMod (4 * κ + 1)) ↔ Even κ) ∧
    (IsSquare (-2 : ZMod (4 * κ + 1)) ↔ Even κ) ∧ (IsSquare (g ^ (3 * κ)) ↔ Even κ) ∧
    g ^ (3 * κ) = -g ^ κ ∧ IsSquare (-1 : ZMod (4 * κ + 1)) := by
  have hne : 4 * κ + 1 ≠ 2 := by omega
  have h2 : IsSquare (2 : ZMod (4 * κ + 1)) ↔ Even κ := by
    rw [ZMod.exists_sq_eq_two_iff hne, Nat.even_iff]; omega
  have hm1 : IsSquare (-1 : ZMod (4 * κ + 1)) := (ZMod.exists_sq_eq_neg_one_iff (p := 4 * κ + 1)).2 (by omega)
  have h2z : (2 : ZMod (4 * κ + 1)) ≠ 0 := by
    intro h
    have := (ZMod.natCast_eq_zero_iff 2 (4 * κ + 1)).1 (by exact_mod_cast h)
    have := Nat.le_of_dvd (by norm_num) this
    have := hp'.out.two_le
    omega
  have hodd : (4 * κ + 1) % 2 = 1 := by omega
  have hg' : orderOf g = 4 * κ + 1 - 1 := by rw [hg]; rfl
  have hhalf : g ^ (2 * κ) = -1 := by
    have h1 := pow_orderOf_eq_one g
    rw [hg] at h1
    have h2' : (g ^ (2 * κ)) ^ 2 = 1 := by rw [← pow_mul, show 2 * κ * 2 = 4 * κ by ring]; exact h1
    rcases sq_eq_one_cases h2' with h | h
    · exfalso
      have := orderOf_dvd_iff_pow_eq_one.2 h
      rw [hg] at this
      have hκ : 0 < κ := by
        by_contra hk; push_neg at hk
        have : κ = 0 := by omega
        subst this; exact absurd hp'.out (by decide)
      have := Nat.le_of_dvd (by omega) this
      omega
    · exact h
  refine ⟨h2, ?_, ?_, ?_, ?_, hm1⟩
  · exact (inv_square_iff (2 : ZMod (4 * κ + 1))).trans h2
  · obtain ⟨i, hi⟩ := hm1
    exact (neg_two_square_iff hi).trans h2
  · rw [parity_iff hg' hodd, Nat.even_mul]
    constructor
    · rintro (h | h)
      · exact absurd h (by decide)
      · exact h
    · intro h; exact Or.inr h
  · exact three_kappa_pow g κ hhalf

end parity

/-! ## The Cayley step preserves any Hermitian pairing (8:C4, D10) -/
section cayley
variable {R : Type*} [Ring R]

/-- 8:C4, 8:D10 — the exact Hermitian preservation, for any anti-involution `σ` of the operator ring (the
adjoint of a nondegenerate Hermitian form, or the `X`-adjoint of the spinor form): if `σ h = h`, the scalar
`a` is central with `σ a = −a`, and `1 − a h` is a unit, then `u = (1 − a h)⁻¹ (1 + a h)` satisfies
`σ u · u = 1` — the Cayley step is unitary (Theorem `cayley-preservation`). For D10 the premise
`σ h = h` is the `X`-self-adjointness of `𝒟^s − m` (D9's operator clause, decided by the package at
`p = 5, 13, 17` and not proved here). -/
theorem cayley_unitary (σ : R → R) (hmul : ∀ x y, σ (x * y) = σ y * σ x) (hadd : ∀ x y, σ (x + y) = σ x + σ y)
    (hone : σ 1 = 1) (hneg : ∀ x, σ (-x) = -σ x)
    {h a : R} (hh : σ h = h) (ha : σ a = -a) (hc : ∀ x, Commute a x)
    (hu : IsUnit (1 - a * h)) :
    let u := (hu.unit⁻¹ : Rˣ) * (1 + a * h)
    σ (u : R) * u = 1 := by
  intro u
  -- σ(1 − a h) = 1 + a h and σ(1 + a h) = 1 − a h
  have hsub : σ (1 - a * h) = 1 + a * h := by
    rw [sub_eq_add_neg, hadd, hone, hneg, hmul, hh, ha, mul_neg, neg_neg, (hc h).eq]
  have hadd' : σ (1 + a * h) = 1 - a * h := by
    rw [hadd, hone, hmul, hh, ha, mul_neg, (hc h).eq, sub_eq_add_neg]
  -- the inverse commutes with 1 + a h
  have hcomm : Commute (1 - a * h) (1 + a * h) :=
    (Commute.one_left _).sub_left ((Commute.one_right (a * h)).add_right (Commute.refl (a * h)))
  have hinv_comm : Commute ((hu.unit⁻¹ : Rˣ) : R) (1 + a * h) := by
    have hcu : Commute (hu.unit : R) (1 + a * h) := by rw [IsUnit.unit_spec]; exact hcomm
    exact (Commute.units_inv_left_iff).2 hcu
  -- σ of the inverse is the inverse of σ
  have hσinv : σ ((hu.unit⁻¹ : Rˣ) : R) * (1 + a * h) = 1 := by
    have e : (1 - a * h) * ((hu.unit⁻¹ : Rˣ) : R) = 1 := by
      have := hu.unit.mul_inv
      rw [IsUnit.unit_spec] at this
      exact this
    have := congrArg σ e
    rw [hmul, hsub, hone] at this
    exact this
  show σ (((hu.unit⁻¹ : Rˣ) : R) * (1 + a * h)) * (((hu.unit⁻¹ : Rˣ) : R) * (1 + a * h)) = 1
  rw [hmul, hadd']
  -- (1 − a h) · σ(inv) · inv · (1 + a h): use σ(inv)(1 + a h) = 1 and commutation
  calc (1 - a * h) * σ ((hu.unit⁻¹ : Rˣ) : R) * (((hu.unit⁻¹ : Rˣ) : R) * (1 + a * h))
      = (1 - a * h) * σ ((hu.unit⁻¹ : Rˣ) : R) * ((1 + a * h) * ((hu.unit⁻¹ : Rˣ) : R)) := by
        rw [hinv_comm.eq]
    _ = (1 - a * h) * (σ ((hu.unit⁻¹ : Rˣ) : R) * (1 + a * h)) * ((hu.unit⁻¹ : Rˣ) : R) := by
        simp only [mul_assoc]
    _ = (1 - a * h) * ((hu.unit⁻¹ : Rˣ) : R) := by rw [hσinv, mul_one]
    _ = 1 := by
        have := hu.unit.mul_inv
        rw [IsUnit.unit_spec] at this
        exact this

/-- 8:C4 — every orbit is periodic: a unit of a finite ring has finite order (Corollary
`finite-periodicity`). -/
theorem cayley_periodic {R : Type*} [Ring R] [Finite R] (u : Rˣ) : IsOfFinOrder u := isOfFinOrder_of_finite u

end cayley

/-! ## Kinetic Hamiltonians: nilpotent, fully admissible, of period `p` (8:C6, E4) -/
section kinetic
variable {R : Type*} [Ring R] {p : ℕ} [hp : Fact (Nat.Prime p)] [CharP R p]

/-- 8:E4 (1), 8:C6, 8:D10 — the translation `t` of order `p` (`t^p = 1`) has `(t − 1)^p = 0` in
characteristic `p`: the kinetic Hamiltonians and the symmetric differences are nilpotent (Theorem
`period-dichotomy` (1), Corollary `kinetic-admissible`). -/
theorem translation_nilpotent {t : R} (ht : t ^ p = 1) : (t - 1) ^ p = 0 := by
  rw [sub_pow_char_of_commute p (Commute.one_right t), ht, one_pow, sub_self]

/-- 8:E4 (1), 8:C6 — `h = c (t + t^{p−1} − 2) = c t^{p−1} (t − 1)²` and with it `a h` for any `a` commuting with
`t` and `c` is nilpotent, `(a h)^p = 0`, so `1 − a h` is a unit: the Cayley step is defined for every `a` —
`𝒜(H) = K⁻` (Corollary `kinetic-admissible`; `H = −Δ` at `c = −1`). -/
theorem kinetic_nilpotent {t c a : R} (ht : t ^ p = 1) (hct : Commute c t) (hat : Commute a t)
    (hac : Commute a c) :
    let h := c * (t + t ^ (p - 1) - 2)
    (a * h) ^ p = 0 ∧ IsNilpotent (a * h) ∧ IsUnit (1 - a * h) := by
  intro h
  have hp1 : (p - 1) + 1 = p := Nat.sub_add_cancel hp.out.one_le
  -- h = c t^{p−1} (t − 1)²
  have hfac : h = c * t ^ (p - 1) * (t - 1) ^ 2 := by
    show c * (t + t ^ (p - 1) - 2) = c * t ^ (p - 1) * (t - 1) ^ 2
    have e : t ^ (p - 1) * (t - 1) ^ 2 = t + t ^ (p - 1) - 2 := by
      have : t ^ (p - 1) * t = 1 := by rw [← pow_succ, hp1, ht]
      have h2 : t ^ (p - 1) * t ^ 2 = t := by rw [pow_two, ← mul_assoc, this, one_mul]
      calc t ^ (p - 1) * (t - 1) ^ 2 = t ^ (p - 1) * t ^ 2 - 2 * (t ^ (p - 1) * t) + t ^ (p - 1) := by
            noncomm_ring
        _ = t + t ^ (p - 1) - 2 := by rw [h2, this, mul_one]; noncomm_ring
    rw [mul_assoc, e]
  have hcomm : Commute a (c * t ^ (p - 1) * (t - 1) ^ 2) :=
    (hac.mul_right (hat.pow_right _)).mul_right ((hat.sub_right (Commute.one_right a)).pow_right 2)
  have hcomm2 : Commute (a * (c * t ^ (p - 1))) ((t - 1) ^ 2) := by
    have h1 : Commute a ((t - 1) ^ 2) := (hat.sub_right (Commute.one_right a)).pow_right 2
    have h2 : Commute (c * t ^ (p - 1)) ((t - 1) ^ 2) :=
      ((hct.sub_right (Commute.one_right c)).pow_right 2).mul_left ((Commute.refl t).pow_left _ |>.sub_right (Commute.one_right _) |>.pow_right 2)
    exact h1.mul_left h2
  have key : (a * h) ^ p = 0 := by
    rw [hfac, ← mul_assoc, hcomm2.mul_pow, ← pow_mul, show 2 * p = p + p by ring, pow_add,
      translation_nilpotent ht, mul_zero, mul_zero]
  refine ⟨key, ⟨p, key⟩, IsNilpotent.isUnit_one_sub ⟨p, key⟩⟩

/-- 8:E4 (1), 8:C6 — the period: for a nilpotent `n` with `n^p = 0` and `2` a unit, the Cayley step
`u = (1 − n)⁻¹(1 + n)` is unipotent — `u − 1 = 2(1 − n)⁻¹ n`, `(u − 1)^p = 0`, `u^p = 1` — and `u ≠ 1` when
`n ≠ 0`, so in the prime characteristic `ord(U) = p` exactly (Theorem `period-dichotomy` (1); on `𝔽₁₃`,
`ord(U_{kw, −Δ}) = 13` for every `k ≠ 0`, Example `cayley-13`). -/
theorem cayley_period {n : R} (hn : n ^ p = 0) (h2 : IsUnit (2 : R)) (hn0 : n ≠ 0) :
    let hu : IsUnit (1 - n) := IsNilpotent.isUnit_one_sub ⟨p, hn⟩
    let hu' : IsUnit (1 + n) := by
      rw [← sub_neg_eq_add]; exact IsNilpotent.isUnit_one_sub ⟨p, by rw [neg_pow, hn, mul_zero]⟩
    let u : Rˣ := hu.unit⁻¹ * hu'.unit
    (u : R) = ((hu.unit⁻¹ : Rˣ) : R) * (1 + n) ∧ u ^ p = 1 ∧ u ≠ 1 ∧ orderOf u = p := by
  intro hu hu' u
  have hval : (u : R) = ((hu.unit⁻¹ : Rˣ) : R) * (1 + n) := by
    show ((hu.unit⁻¹ : Rˣ) : R) * (hu'.unit : R) = _
    rw [IsUnit.unit_spec]
  have hv : ((hu.unit⁻¹ : Rˣ) : R) * (1 - n) = 1 := by
    have := hu.unit.inv_mul; rwa [IsUnit.unit_spec] at this
  have hvn : Commute ((hu.unit⁻¹ : Rˣ) : R) n := by
    have : Commute (hu.unit : R) n := by
      rw [IsUnit.unit_spec]; exact (Commute.one_left n).sub_left (Commute.refl n)
    exact (Commute.units_inv_left_iff).2 this
  have hu1 : (u : R) - 1 = 2 * (((hu.unit⁻¹ : Rˣ) : R) * n) := by
    rw [hval]
    calc ((hu.unit⁻¹ : Rˣ) : R) * (1 + n) - 1
        = ((hu.unit⁻¹ : Rˣ) : R) * (1 + n) - ((hu.unit⁻¹ : Rˣ) : R) * (1 - n) := by rw [hv]
      _ = 2 * (((hu.unit⁻¹ : Rˣ) : R) * n) := by noncomm_ring
  have hpow : ((u : R) - 1) ^ p = 0 := by
    rw [hu1, (Commute.ofNat_left 2 _).mul_pow, hvn.mul_pow, hn, mul_zero, mul_zero]
  have hup : u ^ p = 1 := by
    apply Units.ext
    rw [Units.val_pow_eq_pow_val, Units.val_one]
    have : (u : R) = ((u : R) - 1) + 1 := (sub_add_cancel _ _).symm
    rw [this, add_pow_char_of_commute p (Commute.one_right _), hpow, one_pow, zero_add]
  have hne : u ≠ 1 := by
    intro h
    have : (u : R) - 1 = 0 := by rw [h, Units.val_one, sub_self]
    rw [hu1] at this
    have := (h2.mul_right_eq_zero).1 this
    have := ((Units.isUnit (hu.unit⁻¹)).mul_right_eq_zero).1 this
    exact hn0 this
  exact ⟨hval, hup, hne, orderOf_eq_prime hup hne⟩

end kinetic

/-! ## The Hermitian form on a finite configuration space (8:C2) -/
section hermitian
variable {K : Type*} [CommRing K] [StarRing K] {X : Type*} [Fintype X]

/-- `⟨ψ, φ⟩_X = Σ_x ψ(x)* φ(x)` (Definition `hermitian-form`). -/
def herm (ψ φ : X → K) : K := ∑ x, star (ψ x) * φ x

/-- 8:C2 — Hermitian symmetry `⟨ψ, φ⟩* = ⟨φ, ψ⟩`; linearity in the second slot, conjugate-linearity in the first. -/
theorem herm_star (ψ φ : X → K) : star (herm ψ φ) = herm φ ψ := by
  simp [herm, star_sum, star_mul, mul_comm]

theorem herm_add_right (ψ φ φ' : X → K) : herm ψ (φ + φ') = herm ψ φ + herm ψ φ' := by
  simp [herm, mul_add, Finset.sum_add_distrib]

theorem herm_sub_right (ψ φ φ' : X → K) : herm ψ (φ - φ') = herm ψ φ - herm ψ φ' := by
  simp [herm, mul_sub, Finset.sum_sub_distrib]

theorem herm_smul_right (ψ φ : X → K) (c : K) : herm ψ (c • φ) = c * herm ψ φ := by
  simp [herm, Finset.mul_sum, mul_left_comm]

theorem herm_add_left (ψ ψ' φ : X → K) : herm (ψ + ψ') φ = herm ψ φ + herm ψ' φ := by
  simp [herm, add_mul, Finset.sum_add_distrib]

theorem herm_sub_left (ψ ψ' φ : X → K) : herm (ψ - ψ') φ = herm ψ φ - herm ψ' φ := by
  simp [herm, sub_mul, Finset.sum_sub_distrib]

theorem herm_smul_left (ψ φ : X → K) (c : K) : herm (c • ψ) φ = star c * herm ψ φ := by
  simp [herm, Finset.mul_sum, mul_assoc]

/-- 8:C2 — nondegeneracy: `⟨ψ, φ⟩ = 0` for every `φ` forces `ψ = 0` (Lemma `hermitian-nondeg`; the test
function is the point mass at `x₀`). -/
theorem herm_nondegenerate [DecidableEq X] (ψ : X → K) (h : ∀ φ, herm ψ φ = 0) : ψ = 0 := by
  funext x₀
  have := h (Pi.single x₀ 1)
  simp [herm, Pi.single_apply] at this
  have h2 := congrArg star this
  simpa using h2

/-- The translation `(T_u ψ)(x) = ψ(x + u)` on an additive group. -/
def translate {G : Type*} [AddGroup G] (u : G) (ψ : G → K) : G → K := fun x => ψ (x + u)

/-- 8:C2 — every translation is unitary for the form, and `T_u† = T_{−u}` (Proposition
`translation-unitary`). -/
theorem herm_translate {G : Type*} [AddGroup G] [Fintype G] (u : G) (ψ φ : G → K) :
    herm (translate u ψ) (translate u φ) = herm ψ φ := by
  unfold herm translate
  exact Fintype.sum_equiv (Equiv.addRight u) _ _ (fun x => rfl)

/-- 8:C2 — the adjoint of a translation is the opposite translation, `T_u† = T_{−u}` (Proposition
`translation-unitary`). -/
theorem herm_translate_adjoint {G : Type*} [AddGroup G] [Fintype G] (u : G) (ψ φ : G → K) :
    herm (translate u ψ) φ = herm ψ (translate (-u) φ) := by
  unfold herm translate
  refine (Fintype.sum_equiv (Equiv.addRight u) _ _ (fun x => ?_))
  simp

/-- The finite Laplacian along one direction, `Δ = T_e + T_{−e} − 2`, and the Hamiltonian
`H = −ϰ Δ + M_V` (`(M_V ψ)(x) = V(x) ψ(x)`). -/
def laplacian {G : Type*} [AddGroup G] (e : G) (ψ : G → K) : G → K :=
  translate e ψ + translate (-e) ψ - (2 : K) • ψ

def hamiltonian {G : Type*} [AddGroup G] (e : G) (ϰ : K) (V : G → K) (ψ : G → K) : G → K :=
  (-ϰ) • laplacian e ψ + fun x => V x * ψ x

/-- 8:C2 — the Laplacian along one direction is self-adjoint, `⟨Δψ, φ⟩ = ⟨ψ, Δφ⟩` (Proposition
`laplacian-sa`; the `d`-dimensional Laplacian is the sum over the directions), and with it every Hamiltonian
`−ϰΔ + M_V` with `ϰ` and `V` Frobenius-fixed (Corollary `hamiltonian-sa`). -/
theorem herm_laplacian {G : Type*} [AddGroup G] [Fintype G] (e : G) (ψ φ : G → K) :
    herm (laplacian e ψ) φ = herm ψ (laplacian e φ) := by
  unfold laplacian
  rw [herm_sub_left, herm_add_left, herm_smul_left, herm_sub_right, herm_add_right, herm_smul_right,
    herm_translate_adjoint, herm_translate_adjoint (-e), neg_neg, star_ofNat, add_comm (herm ψ (translate (-e) φ))]

/-- 8:C2 — every Hamiltonian `−ϰΔ + M_V` with `ϰ` and `V` Frobenius-fixed is self-adjoint (Corollary
`hamiltonian-sa`). -/
theorem herm_hamiltonian {G : Type*} [AddGroup G] [Fintype G] (e : G) (ϰ : K) (hϰ : star ϰ = ϰ)
    (V : G → K) (hV : ∀ x, star (V x) = V x) (ψ φ : G → K) :
    herm (hamiltonian e ϰ V ψ) φ = herm ψ (hamiltonian e ϰ V φ) := by
  unfold hamiltonian
  rw [herm_add_left, herm_smul_left, herm_laplacian, herm_add_right, herm_smul_right, star_neg, hϰ]
  congr 1
  unfold herm
  refine Finset.sum_congr rfl (fun x _ => ?_)
  rw [star_mul, hV]; ring

end hermitian


/-! ## The free evolution is the drive: the characters, the spectrum and the isotropy (8:F3, F4) -/
section drive
variable {p : ℕ} [hp : Fact (Nat.Prime p)]

/-- The drive pullback on functions of the phase cycle `Φ = (ZMod p)ˣ`: `(Dψ)(x) = ψ(g⁻¹ x)`. -/
def drive (g : (ZMod p)ˣ) (ψ : (ZMod p)ˣ → ZMod p) : (ZMod p)ˣ → ZMod p := fun x => ψ (g⁻¹ * x)

/-- The multiplicative characters `χ_k(x) = x^k` (the winding-`k` modes). -/
def chi (k : ℕ) : (ZMod p)ˣ → ZMod p := fun x => (x : ZMod p) ^ k

/-- 8:F3 (2) — the characters are eigenvectors of the drive with eigenvalue `g^{−k}`: the winding-`k` mode
acquires the phase `g^{−k}` per chronon (Theorem `zonal`). -/
theorem drive_chi (g : (ZMod p)ˣ) (k : ℕ) : drive g (chi k) = fun x => ((g⁻¹ : (ZMod p)ˣ) : ZMod p) ^ k * chi k x := by
  funext x
  simp only [drive, chi, Units.val_mul, mul_pow]

/-- 8:F3 (1) — the drive is a permutation of the cycle: it preserves the sum defining the form (unitary). -/
theorem drive_sum (g : (ZMod p)ˣ) (f : (ZMod p)ˣ → ZMod p) : ∑ x, f (g⁻¹ * x) = ∑ x, f x :=
  Fintype.sum_equiv (Equiv.mulLeft g⁻¹) _ _ (fun _ => rfl)

/-- 8:F3 (3) — isotropy: the character values are Frobenius-fixed, so `⟨χ_k, χ_k⟩ = Σ_x x^{2k}`, which is
`0` unless `(p − 1) ∣ 2k` and `−1` otherwise (Mathlib's `FiniteField.sum_pow_units`): every character line is
isotropic except `k = 0` and `k = (p − 1)/2`. -/
theorem chi_isotropy (k : ℕ) :
    (∑ x : (ZMod p)ˣ, chi k x * chi k x) = if p - 1 ∣ 2 * k then -1 else 0 := by
  rw [show (∑ x : (ZMod p)ˣ, chi k x * chi k x) = ∑ x : (ZMod p)ˣ, (x : ZMod p) ^ (2 * k) from
    Finset.sum_congr rfl (fun x _ => by rw [chi, ← mul_pow, ← sq, ← pow_mul])]
  have := FiniteField.sum_pow_units (K := ZMod p) (2 * k)
  rwa [ZMod.card] at this

/-- 8:F3 (3), 8:F4 — the exceptional eigenvalues are `±1`: on the shell `p = 4κ + 1` with `g` of order `4κ`,
`k = 2κ` gives `g^{−2κ} = −1` (and `k = 0` gives `1`); and these are all of `N¹ ∩ 𝔽_p`: a base-field element
of norm one (`u ū = u² = 1`) is `±1` (Corollary `sectors`). -/
theorem exceptional_eigen (κ : ℕ) [Fact (Nat.Prime (4 * κ + 1))] (g : (ZMod (4 * κ + 1))ˣ)
    (hg : orderOf g = 4 * κ) :
    ((g⁻¹ : (ZMod (4 * κ + 1))ˣ) : ZMod (4 * κ + 1)) ^ (2 * κ) = -1 ∧
    ∀ u : ZMod (4 * κ + 1), u * u = 1 → u = 1 ∨ u = -1 := by
  refine ⟨?_, fun u hu => mul_self_eq_one_iff.1 hu⟩
  have h4 : g ^ (4 * κ) = 1 := by have := pow_orderOf_eq_one g; rwa [hg] at this
  have h2 : (g ^ (2 * κ)) ^ 2 = 1 := by rw [← pow_mul, show 2 * κ * 2 = 4 * κ by ring, h4]
  have hne : g ^ (2 * κ) ≠ 1 := by
    intro h
    have := orderOf_dvd_iff_pow_eq_one.2 h
    rw [hg] at this
    have hκ : 0 < κ := by
      rcases Nat.eq_zero_or_pos κ with h0 | h0
      · subst h0; exact absurd (Fact.out : Nat.Prime (4 * 0 + 1)) (by decide)
      · exact h0
    have := Nat.le_of_dvd (by omega) this
    omega
  have hval : ((g ^ (2 * κ) : (ZMod (4 * κ + 1))ˣ) : ZMod (4 * κ + 1)) = -1 := by
    have h2' : (((g ^ (2 * κ) : (ZMod (4 * κ + 1))ˣ) : ZMod (4 * κ + 1))) ^ 2 = 1 := by
      rw [← Units.val_pow_eq_pow_val, h2, Units.val_one]
    rw [sq] at h2'
    rcases mul_self_eq_one_iff.1 h2' with h | h
    · exact absurd (Units.ext h) hne
    · exact h
  rw [← Units.val_pow_eq_pow_val, inv_pow, ← hval]
  have : (g ^ (2 * κ))⁻¹ = g ^ (2 * κ) := by
    rw [inv_eq_iff_mul_eq_one, ← sq, h2]
  rw [this]

/-- 8:F4 — the sector separation: `ord(g⁻¹) = ord(g) = p − 1`, the drive's phases run on the split cycle
`μ_{p−1}`, while the norm-one torus has order `p + 1`; and there are no meridional plane waves: no
`K`-valued character of the translation cycle `C_p`, since `p ∤ p² − 1` — no unit of `K` has order `p`
(`gcd(p, |Kˣ|) = 1`). -/
theorem sector_separation {K : Type*} [Field K] [Finite K] (hK : Nat.card K = p ^ 2)
    (g : (ZMod p)ˣ) (hg : orderOf g = p - 1) :
    orderOf g⁻¹ = p - 1 ∧ ∀ x : Kˣ, orderOf x ≠ p := by
  refine ⟨by rw [orderOf_inv, hg], fun x hx => ?_⟩
  have hd := orderOf_dvd_natCard x
  rw [Nat.card_units, hK, hx] at hd
  have hp2 : p ∣ p ^ 2 := dvd_pow_self p two_ne_zero
  have h1 : p ∣ 1 := by
    have := Nat.dvd_sub hp2 hd
    have hle : 1 ≤ p ^ 2 := Nat.one_le_pow _ _ hp.out.pos
    rwa [Nat.sub_sub_self hle] at this
  exact hp.out.one_lt.ne' (Nat.dvd_one.1 h1)

/-- The dispersion identity in any commutative ring. -/
theorem dispersion_generic {R : Type*} [CommRing R] (a b c : R) (k : ℕ) :
    -((a * c) ^ k + (b * c) ^ k - 2 * c ^ k) = (2 - b ^ k - a ^ k) * c ^ k := by ring

/-- 8:F4 — the dispersion relation on the cycle: `−Δ_Φ χ_k = (2 − g^k − g^{−k}) χ_k` with
`Δ_Φ = D + D⁻¹ − 2` (the finite band curve). -/
theorem dispersion (g : (ZMod p)ˣ) (k : ℕ) :
    (fun x => -(drive g (chi k) x + drive g⁻¹ (chi k) x - 2 * chi k x)) =
      fun x => (2 - ((g : ZMod p)) ^ k - ((g⁻¹ : (ZMod p)ˣ) : ZMod p) ^ k) * chi k x := by
  funext x
  simp only [drive, chi, inv_inv, Units.val_mul]
  exact dispersion_generic _ _ _ k

end drive

/-! ## Reversibility and the information counts (8:E2, E3) -/
section counts
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- 8:E2 — a self-map of a finite set is bijective exactly when its image count is the whole count (loss
factor `1`): `|f(X)| = |X| ⟺ f bijective` (Proposition `loss-factor-one`). -/
theorem loss_factor_one (f : X → X) : (Finset.univ.image f).card = Fintype.card X ↔ Function.Bijective f := by
  rw [← Finset.card_univ, Finset.card_image_iff, Finset.coe_univ, Set.injOn_univ]
  exact Finite.injective_iff_bijective

/-- 8:E3 — an invertible map has loss factor one: left multiplication by a unit is a bijection (the Cayley
propagators and the boost transports). -/
theorem unit_loss_factor_one {R : Type*} [Monoid R] (u : Rˣ) : Function.Bijective (fun x : R => (u : R) * x) :=
  (Units.mulLeft u).bijective

variable {p : ℕ} [hp : Fact (Nat.Prime p)]

/-- 8:E2 — the power-map count on the phase cycle: `x ↦ x^ε` on `(ZMod p)ˣ` has image of size
`(p − 1)/gcd(ε, p − 1)`, and its kernel — the fibre over `1`, of which every nonempty fibre is a coset —
has `gcd(ε, p − 1)` elements (Proposition `power-map-count`, on the cyclic group of order `p − 1`). -/
theorem power_map_count (ε : ℕ) :
    Nat.card ((powMonoidHom ε : (ZMod p)ˣ →* (ZMod p)ˣ).ker) = Nat.gcd (p - 1) ε ∧
    Nat.card ((powMonoidHom ε : (ZMod p)ˣ →* (ZMod p)ˣ).range) = (p - 1) / Nat.gcd (p - 1) ε := by
  have hc : Nat.card (ZMod p)ˣ = p - 1 := by rw [Nat.card_eq_fintype_card, ZMod.card_units]
  refine ⟨?_, ?_⟩
  · rw [IsCyclic.card_powMonoidHom_ker, hc]
  · rw [IsCyclic.card_powMonoidHom_range, hc]

end counts


/-! ## The torus as a cyclic group of order `p + 1`: the potential periods and the triality clause (8:D5, E4) -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

/-- 8:D5 — the range of the boost is exactly `N¹` (Lemma `boost-torus`: `G_ν ≅ K^×/F^× ≅ N¹`). -/
theorem boost_range (hν : ¬ IsSquare ν) :
    (boost (F := F) (ν := ν)).range = normOneGroup F ν := by
  ext u
  constructor
  · rintro ⟨z, rfl⟩; exact boost_mem z
  · intro hu; exact exists_boost_eq hν hu

/-- 8:D5, 8:C5 — `N¹` is cyclic (a finite subgroup of the units of a field), of order `p + 1` on `F = 𝔽_p`:
`N¹ ≅ C_{p+1}`. -/
theorem normOne_cyclic [Finite F] (hν : ¬ IsSquare ν) :
    letI := field hν; IsCyclic (normOneGroup F ν) := by
  letI := field hν
  infer_instance

/-- 8:E4 (2) — every phase on the torus has `u^{p+1} = 1`: a potential propagator, diagonal with entries in
`N¹`, has order dividing `p + 1`; and some phase has order exactly `p + 1` (the torus is cyclic), so the bound
is attained (Theorem `period-dichotomy` (2)). -/
theorem torus_period [Finite F] (hν : ¬ IsSquare ν) (h2 : (2 : F) ≠ 0) :
    (∀ u : normOneGroup F ν, u ^ (Nat.card F + 1) = 1) ∧ ∃ u : normOneGroup F ν, orderOf u = Nat.card F + 1 := by
  letI := field hν
  have hc := card_normOneGroup hν h2
  refine ⟨fun u => by rw [← hc]; exact pow_card_eq_one', ?_⟩
  obtain ⟨u, hu⟩ := IsCyclic.exists_ofOrder_eq_natCard (α := normOneGroup F ν)
  exact ⟨u, by rw [hu, hc]⟩

/-- 8:D5 — the triality clause: the torus carries an element of order three exactly when `3 ∣ p + 1`
(Cauchy in the cyclic group `C_{p+1}`; `|G_3| = 18` at `17`, `|G_2| = 14` at `13`). -/
theorem order_three_iff [Finite F] (hν : ¬ IsSquare ν) (h2 : (2 : F) ≠ 0) :
    (∃ u : normOneGroup F ν, orderOf u = 3) ↔ 3 ∣ Nat.card F + 1 := by
  have hc := card_normOneGroup hν h2
  constructor
  · rintro ⟨u, hu⟩
    rw [← hc, ← hu]; exact orderOf_dvd_natCard u
  · intro h
    rw [← hc] at h
    exact exists_prime_orderOf_dvd_card' 3 h

end Ext

/-! ## The Cayley transform: injective, norm-one valued, inverted by the orientation gauge (8:C5) -/
namespace Ext
variable {F : Type*} [Field F] {ν : F}

/-- 8:C5 — `φ_α(λ) = (1 + αλ)/(1 − αλ)`, `α = kw ≠ 0`, is injective on `F` (a nonconstant Möbius map): the
self-adjoint line embeds in the torus (Theorem `cayley-transform`). -/
theorem cayley_injective (hν : ¬ IsSquare ν) (h2 : (2 : F) ≠ 0) {k : F} (hk : k ≠ 0) :
    Function.Injective (cayley (ν := ν) k) := by
  letI := field hν
  intro s t hst
  unfold cayley at hst
  have hs := one_sub_nu_sq_ne_zero hν (k * s)
  have ht := one_sub_nu_sq_ne_zero hν (k * t)
  have hs' : (1 : Ext F ν) - ofBase (k * s) * w ≠ 0 := fun h => hs (by rw [← norm_one_sub_kw, h]; simp [norm])
  have ht' : (1 : Ext F ν) - ofBase (k * t) * w ≠ 0 := fun h => ht (by rw [← norm_one_sub_kw, h]; simp [norm])
  rw [← div_eq_mul_inv, ← div_eq_mul_inv, div_eq_div_iff hs' ht'] at hst
  -- (1 + αs)(1 − αt) = (1 + αt)(1 − αs) ⇒ 2α(s − t) = 0
  have him := congrArg im hst
  simp at him
  have : (2 : F) * (k * (s - t)) = 0 := by linear_combination him
  rcases mul_eq_zero.1 this with h | h
  · exact absurd h h2
  · rcases mul_eq_zero.1 h with h | h
    · exact absurd h hk
    · exact sub_eq_zero.1 h

/-- 8:C5 — the orientation gauge `α ↦ −α` inverts every value: `φ_{−α}(λ) · φ_α(λ) = 1` (Remark
`forward-step`: the forward step imports the derived orientation of the shell). -/
theorem cayley_gauge (hν : ¬ IsSquare ν) (k t : F) :
    (cayley (ν := ν) (-k) t) * cayley k t = 1 := by
  letI := field hν
  unfold cayley
  have h1 := one_sub_nu_sq_ne_zero hν (k * t)
  have hs' : (1 : Ext F ν) - ofBase (k * t) * w ≠ 0 := fun h => h1 (by rw [← norm_one_sub_kw, h]; simp [norm])
  have ha' : (1 : Ext F ν) + ofBase (k * t) * w ≠ 0 := fun h => h1 (by rw [← norm_one_add_kw, h]; simp [norm])
  have e1 : (1 : Ext F ν) + ofBase (-k * t) * w = 1 - ofBase (k * t) * w := by ext <;> simp
  have e2 : (1 : Ext F ν) - ofBase (-k * t) * w = 1 + ofBase (k * t) * w := by ext <;> simp
  rw [e1, e2, ← div_eq_mul_inv, ← div_eq_mul_inv, div_mul_div_comm,
    mul_comm ((1 : Ext F ν) - ofBase (k * t) * w) (1 + ofBase (k * t) * w), div_self (mul_ne_zero ha' hs')]

end Ext

/-! ## The class is the datum, and the extension erases it (8:B2, B7) -/
section classes
variable {p : ℕ} [hp : Fact (Nat.Prime p)]

/-- 8:B2 — two nonsquares differ by a square factor: `F^×/(F^×)²` has order two (Lemma `class-datum`); the
Lorentzian form then depends on `ν` only through its class, `−(m²ν) x₀² = −ν (m x₀)²`. -/
theorem class_datum {a b : ZMod p} (ha0 : a ≠ 0) (hb0 : b ≠ 0) (ha : ¬ IsSquare a) (hb : ¬ IsSquare b) :
    IsSquare (a * b) := by
  have h := quadraticChar_one_iff_isSquare (F := ZMod p) (mul_ne_zero ha0 hb0)
  rw [← h, map_mul, (quadraticChar_neg_one_iff_not_isSquare (F := ZMod p)).2 ha,
    (quadraticChar_neg_one_iff_not_isSquare (F := ZMod p)).2 hb]
  norm_num

/-- 8:B2 — the rescaling `x₀ ↦ m x₀` identifies the forms of `ν` and `m²ν`: a ring identity, the content of
the clause "the form depends on `ν` only through its class". -/
theorem form_class {K : Type*} [CommRing K] (ν m x₀ x₁ x₂ x₃ : K) :
    -(m ^ 2 * ν) * x₀ ^ 2 + x₁ ^ 2 + x₂ ^ 2 + x₃ ^ 2 = -ν * (m * x₀) ^ 2 + x₁ ^ 2 + x₂ ^ 2 + x₃ ^ 2 := by ring

/-- 8:B7 — over the quadratic extension every element of `F_p` is a square: a nonsquare `a = m² ν` becomes
`(m w)²`, so the Euclidean–Lorentzian dichotomy collapses in `K` (Remark `signature-record`). -/
theorem ext_square (hν : ¬ IsSquare (ν : ZMod p)) (a : ZMod p) : IsSquare (Ext.ofBase a : Ext (ZMod p) ν) := by
  by_cases ha : IsSquare a
  · obtain ⟨r, hr⟩ := ha
    exact ⟨Ext.ofBase r, by rw [hr, Ext.ofBase_mul]⟩
  · by_cases ha0 : a = 0
    · exact ⟨0, by rw [ha0, mul_zero]; exact Ext.ofBase_zero⟩
    · have hν0 : ν ≠ 0 := fun h => hν ⟨0, by rw [h]; ring⟩
      obtain ⟨m, hm⟩ := class_datum ha0 hν0 ha hν
      -- a ν = m², so a = (m/ν)² ν = (m/ν · w)²
      refine ⟨Ext.ofBase (m / ν) * Ext.w, ?_⟩
      ext
      · simp; field_simp; linear_combination hm
      · simp

end classes

/-! ## The factorisation of the coefficient and the norm growth (8:B4, B6) -/
section factorisation
variable {K : Type*} [Field K]

/-- 8:B4 — with `c² = 2⁻¹`, the temporal coefficient factors identically, `ν = g = c² · (2g)`, on every
shell (Corollary `two-seats`; the classes of the two factors: `named_residues`, `two_g_class`). -/
theorem nu_factorisation (g : K) (h2 : (2 : K) ≠ 0) : (2 : K)⁻¹ * (2 * g) = g := by
  field_simp

/-- 8:B6 — norm growth: `N(gz) = g² N(z)` (Theorem `even-transport`; `g²` is even by `parity_iff`). -/
theorem norm_growth {ν : K} (g : K) (z : FRC.Dirac.Ext K ν) :
    Ext.norm (Ext.ofBase g * z) = g ^ 2 * Ext.norm z :=
  Ext.norm_ofBase_mul g z

end factorisation

section twog
variable {p : ℕ} [hp : Fact (Nat.Prime p)]

/-- 8:B4 — the cofactor's class: for a primitive root `g` (a nonsquare), `2g` is a square exactly when `2` is
not, i.e. exactly when `κ` is odd on the shell `p = 4κ + 1` (`named_residues`): the product `ν = g` is odd
always, `c² = 2⁻¹` even exactly on the admissibility class. -/
theorem two_g_class {g : ZMod p} (hg0 : g ≠ 0) (hg : ¬ IsSquare g) (h2 : (2 : ZMod p) ≠ 0) :
    IsSquare (2 * g) ↔ ¬ IsSquare (2 : ZMod p) := by
  have h := quadraticChar_one_iff_isSquare (F := ZMod p) (mul_ne_zero h2 hg0)
  rw [← h, map_mul, (quadraticChar_neg_one_iff_not_isSquare (F := ZMod p)).2 hg, mul_neg_one, neg_eq_iff_eq_neg,
    quadraticChar_neg_one_iff_not_isSquare]

end twog

/-! ## The latitude identities (8:F2) -/
section latitude

/-- 8:F2 — on the shell `p = 4κ + 1`: `4κ = −1`, so `κ = −4⁻¹`, the energy radius `1 + κ = 3·4⁻¹`,
`π = 2κ = −2⁻¹`; `g^κ = −i` for `i = g^{−κ} = g^{3κ}` (`−1 = g^{2κ}`); and `κ + 1`, the first rung past the
midpoint of the ladder `1, …, 2κ`, is still a rung. -/
theorem latitude_identities (κ : ℕ) [hp : Fact (Nat.Prime (4 * κ + 1))] {g : ZMod (4 * κ + 1)}
    (hg : orderOf g = 4 * κ) :
    (4 * κ : ZMod (4 * κ + 1)) = -1 ∧ (κ : ZMod (4 * κ + 1)) = -4⁻¹ ∧
    (1 + κ : ZMod (4 * κ + 1)) = 3 * 4⁻¹ ∧ (2 * κ : ZMod (4 * κ + 1)) = -2⁻¹ ∧
    g ^ κ = -g ^ (3 * κ) ∧ κ + 1 ≤ 2 * κ := by
  have h4 : (4 * κ : ZMod (4 * κ + 1)) = -1 := by
    have := ZMod.natCast_self (4 * κ + 1)
    push_cast at this
    exact eq_neg_of_add_eq_zero_left this
  have hκ0 : 0 < κ := by
    rcases Nat.eq_zero_or_pos κ with h0 | h0
    · subst h0; exact absurd hp.out (by decide)
    · exact h0
  have h2z : (2 : ZMod (4 * κ + 1)) ≠ 0 := by
    intro h
    have := (ZMod.natCast_eq_zero_iff 2 (4 * κ + 1)).1 (by exact_mod_cast h)
    have := Nat.le_of_dvd (by norm_num) this
    omega
  have h4z : (4 : ZMod (4 * κ + 1)) ≠ 0 := four_ne_zero_of_two h2z
  have hκ : (κ : ZMod (4 * κ + 1)) = -4⁻¹ := neg_inv_of_mul h4z h4
  refine ⟨h4, hκ, three_quarters h4z hκ, half_neg h2z h4, ?_, by omega⟩
  have hh : g ^ (2 * κ) = -1 := by
    have h1 := pow_orderOf_eq_one g
    rw [hg] at h1
    have h2' : (g ^ (2 * κ)) ^ 2 = 1 := by rw [← pow_mul, show 2 * κ * 2 = 4 * κ by ring]; exact h1
    rcases sq_eq_one_cases h2' with h | h
    · exfalso
      have := orderOf_dvd_iff_pow_eq_one.2 h
      rw [hg] at this
      have := Nat.le_of_dvd (by omega) this
      omega
    · exact h
  rw [three_kappa_pow g κ hh]
  exact (neg_neg _).symm

end latitude


/-! ## The gamma matrices in blocks, and the Clifford relations (8:D2) -/
section clifford
variable {K : Type*} [CommRing K]
open Matrix

/-- The Pauli matrices over `K`, with the shell's quarter-turn `i` (`i² = −1`) in `σ²`. -/
def σ1 : Matrix (Fin 2) (Fin 2) K := !![0, 1; 1, 0]
def σ2 (i : K) : Matrix (Fin 2) (Fin 2) K := !![0, -i; i, 0]
def σ3 : Matrix (Fin 2) (Fin 2) K := !![1, 0; 0, -1]
/-- `J = σ¹σ³ = (0 −1; 1 0)`, the block of the spinor twist. -/
def J : Matrix (Fin 2) (Fin 2) K := !![0, -1; 1, 0]

/-- `β = (0 I; I 0)` and `ρ(σ) = (0 σ; −σ 0)` on `K² ⊕ K²`. -/
def β : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := fromBlocks 0 1 1 0
def ρ (s : Matrix (Fin 2) (Fin 2) K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := fromBlocks 0 s (-s) 0

/-- The gamma matrices of `(eq:gamma-definition)`: `γ⁰ = i w β`, `γ^k = i ρ(σ^k)`. -/
def γ0 (i w : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := (i * w) • β
def γ1 (i : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := i • ρ σ1
def γ2 (i : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := i • ρ (σ2 i)
def γ3 (i : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := i • ρ σ3

/-- 8:D2 — the Pauli identities `σ^j σ^k + σ^k σ^j = 2 δ_{jk} I₂` over `K`, from `i² = −1`. -/
theorem pauli {i : K} (hi : i * i = -1) :
    σ1 * σ1 = (1 : Matrix (Fin 2) (Fin 2) K) ∧ σ2 i * σ2 i = 1 ∧ σ3 * σ3 = (1 : Matrix (Fin 2) (Fin 2) K) ∧
    σ1 * σ2 i + σ2 i * σ1 = 0 ∧ σ1 * σ3 + σ3 * σ1 = (0 : Matrix (Fin 2) (Fin 2) K) ∧ σ2 i * σ3 + σ3 * σ2 i = 0 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
  · ext a b
    fin_cases a <;> fin_cases b <;>
    simp [σ1, σ2, σ3, Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply] <;>
    linear_combination (-1 : K) * hi

theorem β_sq : (β : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K) * β = 1 := by
  simp [β, fromBlocks_multiply, fromBlocks_one]

theorem ρ_mul (s t : Matrix (Fin 2) (Fin 2) K) : ρ s * ρ t = fromBlocks (-(s * t)) 0 0 (-(s * t)) := by
  simp [ρ, fromBlocks_multiply]

theorem β_ρ_anticomm (s : Matrix (Fin 2) (Fin 2) K) : β * ρ s + ρ s * β = 0 := by
  simp [β, ρ, fromBlocks_multiply, fromBlocks_add]

/-- 8:D2 — the Clifford relations `γ^μ γ^ν + γ^ν γ^μ = 2 η_{μν} I₄`, `η = diag(−ν, 1, 1, 1)`, from `i² = −1` and
`w² = ν` alone (Proposition `clifford`), by the block computation of its proof: `β² = I`, `(ρ^k)² = −I`,
`ρ^jρ^k + ρ^kρ^j = 0`, `βρ^k + ρ^kβ = 0`. -/
theorem clifford {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) :
    γ0 i w * γ0 i w = (-ν) • (1 : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K) ∧
    γ1 i * γ1 i = 1 ∧ γ2 i * γ2 i = 1 ∧ γ3 i * γ3 i = 1 ∧
    γ0 i w * γ1 i + γ1 i * γ0 i w = 0 ∧ γ0 i w * γ2 i + γ2 i * γ0 i w = 0 ∧
    γ0 i w * γ3 i + γ3 i * γ0 i w = 0 ∧ γ1 i * γ2 i + γ2 i * γ1 i = 0 ∧
    γ1 i * γ3 i + γ3 i * γ1 i = 0 ∧ γ2 i * γ3 i + γ3 i * γ2 i = 0 := by
  obtain ⟨h11, h22, h33, h12, h13, h23⟩ := pauli hi
  have hsq : ∀ s : Matrix (Fin 2) (Fin 2) K, s * s = 1 → (i • ρ s) * (i • ρ s) = 1 := fun s hs => by
    rw [Matrix.smul_mul, Matrix.mul_smul, smul_smul, ρ_mul, hs, hi]
    simp [fromBlocks_one, fromBlocks_neg]
  have hanti : ∀ s t : Matrix (Fin 2) (Fin 2) K, s * t + t * s = 0 →
      (i • ρ s) * (i • ρ t) + (i • ρ t) * (i • ρ s) = 0 := fun s t hst => by
    rw [Matrix.smul_mul, Matrix.mul_smul, smul_smul, Matrix.smul_mul, Matrix.mul_smul, smul_smul, ← smul_add,
      ρ_mul, ρ_mul, fromBlocks_add]
    have : -(s * t) + -(t * s) = 0 := by rw [← neg_add, hst, neg_zero]
    simp [this]
  have h0k : ∀ s : Matrix (Fin 2) (Fin 2) K, γ0 i w * (i • ρ s) + (i • ρ s) * γ0 i w = 0 := fun s => by
    unfold γ0
    rw [Matrix.smul_mul, Matrix.mul_smul, smul_smul, Matrix.smul_mul, Matrix.mul_smul, smul_smul,
      mul_comm i (i * w), ← smul_add, β_ρ_anticomm, smul_zero]
  refine ⟨?_, hsq _ h11, hsq _ h22, hsq _ h33, h0k _, h0k _, h0k _, hanti _ _ h12, hanti _ _ h13, hanti _ _ h23⟩
  unfold γ0
  rw [Matrix.smul_mul, Matrix.mul_smul, smul_smul, β_sq]
  congr 1
  linear_combination (w * w) * hi - hw

/-- `M = γ⁰γ¹` and the spinor twist `X = γ⁰γ¹γ³`. -/
def Mγ (i w : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := γ0 i w * γ1 i
def Xγ (i w : K) : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K := γ0 i w * γ1 i * γ3 i

/-- Push a block identity down to its four `2 × 2` blocks and close each entrywise, reducing the powers of
`i` and `w`. -/
macro "block_entries" hs:term : tactic =>
  `(tactic| (rw [fromBlocks_inj]; refine ⟨?_, ?_, ?_, ?_⟩ <;>
      (ext a b; fin_cases a <;> fin_cases b <;>
        (try simp [σ1, σ2, σ3, J, Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply, Matrix.conjTranspose_apply,
          $hs:term]) <;>
        (try ring_nf) <;> (try simp only [$hs:term]) <;> (try ring_nf))))

theorem powers {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) :
    i ^ 2 = -1 ∧ i ^ 3 = -i ∧ i ^ 4 = 1 ∧ i ^ 5 = i ∧ i ^ 6 = -1 ∧ i ^ 7 = -i ∧ i ^ 8 = 1 ∧
    w ^ 2 = ν ∧ w ^ 3 = ν * w ∧ w ^ 4 = ν ^ 2 ∧ w ^ 5 = ν ^ 2 * w := by
  have hi2 : i ^ 2 = -1 := by rw [sq]; exact hi
  have hw2 : w ^ 2 = ν := by rw [sq]; exact hw
  refine ⟨hi2, ?_, ?_, ?_, ?_, ?_, ?_, hw2, ?_, ?_, ?_⟩
  · rw [pow_succ, hi2]; ring
  · rw [show (4 : ℕ) = 2 * 2 by rfl, pow_mul, hi2]; ring
  · rw [pow_succ, show (4 : ℕ) = 2 * 2 by rfl, pow_mul, hi2]; ring
  · rw [show (6 : ℕ) = 2 * 3 by rfl, pow_mul, hi2]; ring
  · rw [pow_succ, show (6 : ℕ) = 2 * 3 by rfl, pow_mul, hi2]; ring
  · rw [show (8 : ℕ) = 2 * 4 by rfl, pow_mul, hi2]; ring
  · rw [pow_succ, hw2]
  · rw [show (4 : ℕ) = 2 * 2 by rfl, pow_mul, hw2]
  · rw [pow_succ, show (4 : ℕ) = 2 * 2 by rfl, pow_mul, hw2]

/-- `M = γ⁰γ¹ = diag(w σ¹, −w σ¹)` in blocks. -/
theorem Mγ_eq {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) :
    Mγ i w = fromBlocks (w • σ1) 0 0 (-(w • σ1)) := by
  have hs := powers hi hw
  simp only [Mγ, γ0, γ1, β, ρ, Matrix.smul_mul, Matrix.mul_smul, smul_smul, fromBlocks_multiply, fromBlocks_smul]
  block_entries hs

/-- `X = γ⁰γ¹γ³ = (0, i w J; i w J, 0)` in blocks, `J = σ¹σ³`. -/
theorem Xγ_eq {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) :
    Xγ i w = fromBlocks 0 ((i * w) • J) ((i * w) • J) 0 := by
  have hs := powers hi hw
  have : Xγ i w = Mγ i w * γ3 i := rfl
  rw [this, Mγ_eq hi hw]
  simp only [γ3, ρ, Matrix.smul_mul, Matrix.mul_smul, smul_smul, fromBlocks_multiply, fromBlocks_smul]
  block_entries hs

/-- 8:D6, 8:D7 (the transported gammas) — spin conjugation up to the scalar `δ`: `M² = ν`,
`(x − yM) γ⁰ (x + yM) = (x² + νy²) γ⁰ − 2xyν γ¹`, `(x − yM) γ¹ (x + yM) = −2xy γ⁰ + (x² + νy²) γ¹`, and `M`
commutes with `γ²` and `γ³` (Proposition `spin-conjugation`; the division by `δ = x² − νy²` onto
`A = (x² + νy²)/δ`, `B = −2xy/δ` is `spin_conjugation_AB`); `y ↦ −y` gives the transported gammas
`γ̂⁰ = Aγ⁰ − νBγ¹`, `γ̂¹ = −Bγ⁰ + Aγ¹` (Proposition `transported-dirac-form`, the pullback identity and the
transported factorization not formalised). -/
theorem spin_conjugation {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) (x y : K) :
    Mγ i w * Mγ i w = ν • 1 ∧
    (x • 1 + (-y) • Mγ i w) * γ0 i w * (x • 1 + y • Mγ i w) = (x ^ 2 + ν * y ^ 2) • γ0 i w + (-(2 * x * y * ν)) • γ1 i ∧
    (x • 1 + (-y) • Mγ i w) * γ1 i * (x • 1 + y • Mγ i w) = (-(2 * x * y)) • γ0 i w + (x ^ 2 + ν * y ^ 2) • γ1 i ∧
    Mγ i w * γ2 i = γ2 i * Mγ i w ∧ Mγ i w * γ3 i = γ3 i * Mγ i w := by
  have hs := powers hi hw
  rw [Mγ_eq hi hw]
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;>
  · simp only [γ0, γ1, γ2, γ3, β, ρ, ← fromBlocks_one, Matrix.smul_mul, Matrix.mul_smul, smul_smul,
      fromBlocks_multiply, fromBlocks_smul, fromBlocks_add, fromBlocks_neg]
    block_entries hs

/-- 8:D9 — the spinor twist: `X² = ν`, `X` commutes with `γ⁰, γ¹, γ³` and anticommutes with `γ²` (Lemma
`spinor-form`, the algebraic part). -/
theorem spinor_twist {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) :
    Xγ i w * Xγ i w = ν • 1 ∧ Xγ i w * γ0 i w = γ0 i w * Xγ i w ∧ Xγ i w * γ1 i = γ1 i * Xγ i w ∧
    Xγ i w * γ3 i = γ3 i * Xγ i w ∧ Xγ i w * γ2 i = -(γ2 i * Xγ i w) := by
  have hs := powers hi hw
  rw [Xγ_eq hi hw]
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;>
  · simp only [γ0, γ1, γ2, γ3, β, ρ, ← fromBlocks_one, Matrix.smul_mul, Matrix.mul_smul, smul_smul,
      fromBlocks_multiply, fromBlocks_smul, fromBlocks_add, fromBlocks_neg]
    block_entries hs

end clifford


section spinorform
variable {K : Type*} [CommRing K] [StarRing K]
open Matrix

theorem σ1_dagger : (σ1 : Matrix (Fin 2) (Fin 2) K)ᴴ = σ1 := by
  ext a b; fin_cases a <;> fin_cases b <;> simp [σ1, Matrix.conjTranspose_apply]
theorem σ3_dagger : (σ3 : Matrix (Fin 2) (Fin 2) K)ᴴ = σ3 := by
  ext a b; fin_cases a <;> fin_cases b <;> simp [σ3, Matrix.conjTranspose_apply]
theorem J_dagger : (J : Matrix (Fin 2) (Fin 2) K)ᴴ = -J := by
  ext a b; fin_cases a <;> fin_cases b <;> simp [J, Matrix.conjTranspose_apply]
theorem σ2_dagger {i : K} (hsi : star i = i) : (σ2 i)ᴴ = -σ2 i := by
  ext a b; fin_cases a <;> fin_cases b <;> simp [σ2, Matrix.conjTranspose_apply, hsi]

/-- 8:D9 — under the conjugate transpose (Frobenius fixing `i`, negating `w`): `(γ⁰)† = −γ⁰`, `(γ¹)† = −γ¹`,
`(γ²)† = +γ²` (the obstruction: `σ²` is antisymmetric with `i` Frobenius-fixed), `(γ³)† = −γ³`, and
`X† = X` for the twist `X = γ⁰γ¹γ³` (Lemma `spinor-form`). -/
theorem gamma_dagger {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) (hsi : star i = i) (hsw : star w = -w) :
    (γ0 i w)ᴴ = -γ0 i w ∧ (γ1 i)ᴴ = -γ1 i ∧ (γ2 i)ᴴ = γ2 i ∧ (γ3 i)ᴴ = -γ3 i ∧ (Xγ i w)ᴴ = Xγ i w := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · simp only [γ0, β, Matrix.conjTranspose_smul, star_mul', hsi, hsw, fromBlocks_conjTranspose,
      Matrix.conjTranspose_zero, Matrix.conjTranspose_one, ← neg_smul]
    congr 1; ring
  · simp only [γ1, ρ, Matrix.conjTranspose_smul, hsi, fromBlocks_conjTranspose, Matrix.conjTranspose_zero,
      Matrix.conjTranspose_neg, σ1_dagger, ← smul_neg, fromBlocks_neg, neg_neg, neg_zero]
  · simp only [γ2, ρ, Matrix.conjTranspose_smul, hsi, fromBlocks_conjTranspose, Matrix.conjTranspose_zero,
      Matrix.conjTranspose_neg, σ2_dagger hsi, neg_neg]
  · simp only [γ3, ρ, Matrix.conjTranspose_smul, hsi, fromBlocks_conjTranspose, Matrix.conjTranspose_zero,
      Matrix.conjTranspose_neg, σ3_dagger, ← smul_neg, fromBlocks_neg, neg_neg, neg_zero]
  · rw [Xγ_eq hi hw]
    simp only [fromBlocks_conjTranspose, Matrix.conjTranspose_zero, Matrix.conjTranspose_smul, star_mul', hsi, hsw,
      J_dagger, smul_neg, neg_smul, neg_neg, mul_neg]

/-- 8:D9 — the twist conjugates every gamma to its negative, `(γ^μ)† X = −X γ^μ` (so `X⁻¹(γ^μ)†X = −γ^μ`),
while the `γ⁰`-twist leaves mixed signs: `(γ⁰)† γ⁰ = −γ⁰γ⁰` but `(γ¹)† γ⁰ = +γ⁰γ¹` (Lemma `spinor-form`). -/
theorem twist_adjoint {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) (hsi : star i = i) (hsw : star w = -w) :
    (γ0 i w)ᴴ * Xγ i w = -(Xγ i w * γ0 i w) ∧ (γ1 i)ᴴ * Xγ i w = -(Xγ i w * γ1 i) ∧
    (γ2 i)ᴴ * Xγ i w = -(Xγ i w * γ2 i) ∧ (γ3 i)ᴴ * Xγ i w = -(Xγ i w * γ3 i) ∧
    (γ0 i w)ᴴ * γ0 i w = -(γ0 i w * γ0 i w) ∧ (γ1 i)ᴴ * γ0 i w = γ0 i w * γ1 i := by
  obtain ⟨d0, d1, d2, d3, _⟩ := gamma_dagger hi hw hsi hsw
  obtain ⟨_, c0, c1, c3, a2⟩ := spinor_twist hi hw
  have hs := powers hi hw
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [d0, neg_mul, c0]
  · rw [d1, neg_mul, c1]
  · rw [d2, a2, neg_neg]
  · rw [d3, neg_mul, c3]
  · rw [d0, neg_mul]
  · rw [d1, neg_mul, neg_eq_iff_eq_neg]
    simp only [γ0, γ1, β, ρ, Matrix.smul_mul, Matrix.mul_smul, smul_smul, fromBlocks_multiply, fromBlocks_smul,
      fromBlocks_neg]
    block_entries hs

/-- `M† = −M`. -/
theorem Mγ_dagger {i w ν : K} (hi : i * i = -1) (hw : w * w = ν) (hsw : star w = -w) :
    (Mγ i w)ᴴ = -(Mγ i w) := by
  rw [Mγ_eq hi hw]
  simp only [fromBlocks_conjTranspose, Matrix.conjTranspose_smul, Matrix.conjTranspose_neg,
    Matrix.conjTranspose_zero, fromBlocks_neg, hsw, σ1_dagger, neg_smul, neg_neg, neg_zero]

/-- 8:D11 — the lift's adjoint: `S† = S(x, −y)` for Frobenius-fixed `x, y` (so, `X` commuting with `M`,
`S^# = X⁻¹S†X = S(x, −y)`), and `S(x, −y) S(x, y) = (x² − νy²) I = δ I` (Proposition `two-diracs`). -/
theorem lift_adjoint {i w ν x y : K} (hi : i * i = -1) (hw : w * w = ν) (hsw : star w = -w)
    (hx : star x = x) (hy : star y = y) :
    (x • 1 + y • Mγ i w)ᴴ = x • 1 + (-y) • Mγ i w ∧
    (x • 1 + (-y) • Mγ i w) * (x • 1 + y • Mγ i w) = (x ^ 2 - ν * y ^ 2) • (1 : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K) := by
  obtain ⟨hM2, _, _, _, _⟩ := spin_conjugation hi hw x y
  refine ⟨?_, ?_⟩
  · rw [Matrix.conjTranspose_add, Matrix.conjTranspose_smul, Matrix.conjTranspose_smul, Matrix.conjTranspose_one,
      Mγ_dagger hi hw hsw, hx, hy, smul_neg, neg_smul]
  · simp only [add_mul, mul_add, smul_mul_assoc, mul_smul_comm, one_mul, mul_one, neg_mul, mul_neg, smul_smul,
      smul_neg, smul_add, neg_smul, hM2]
    module

/-- 8:D11 — the transport of the spinor form: for a lift `S = x + yM` with Frobenius-fixed `x, y`,
`S† X S = (x² − νy²) X = δ X` — norm-one lifts preserve the form exactly, and the odd coset scales it by
the lift norm `δ` (Proposition `two-diracs`). -/
theorem lift_transport {i w ν x y : K} (hi : i * i = -1) (hw : w * w = ν) (hsi : star i = i) (hsw : star w = -w)
    (hx : star x = x) (hy : star y = y) :
    (x • 1 + y • Mγ i w)ᴴ * Xγ i w * (x • 1 + y • Mγ i w) = (x ^ 2 - ν * y ^ 2) • Xγ i w := by
  obtain ⟨hM2, _, _, _, _⟩ := spin_conjugation hi hw x y
  obtain ⟨_, c0, c1, _, _⟩ := spinor_twist hi hw
  have hXM : Xγ i w * Mγ i w = Mγ i w * Xγ i w := by
    show Xγ i w * (γ0 i w * γ1 i) = γ0 i w * γ1 i * Xγ i w
    rw [← mul_assoc, c0, mul_assoc, c1, ← mul_assoc]
  rw [Matrix.conjTranspose_add, Matrix.conjTranspose_smul, Matrix.conjTranspose_smul, Matrix.conjTranspose_one,
    Mγ_dagger hi hw hsw, hx, hy]
  have e1 : (x • (1 : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K) + y • -Mγ i w) * Xγ i w =
      Xγ i w * (x • 1 + y • -Mγ i w) := by
    simp only [add_mul, mul_add, smul_mul_assoc, mul_smul_comm, one_mul, mul_one, neg_mul, mul_neg, hXM]
  rw [e1, mul_assoc]
  have e2 : (x • (1 : Matrix (Fin 2 ⊕ Fin 2) (Fin 2 ⊕ Fin 2) K) + y • -Mγ i w) * (x • 1 + y • Mγ i w) =
      (x ^ 2 - ν * y ^ 2) • 1 := by
    simp only [add_mul, mul_add, smul_mul_assoc, mul_smul_comm, one_mul, mul_one, neg_mul, mul_neg, smul_smul,
      smul_neg, smul_add, hM2]
    module
  rw [e2, mul_smul_comm, mul_one]

end spinorform

/-! ## The coordinate boost (8:D5) -/
section boostmatrix
variable {F : Type*} [Field F]

/-- The boost entries `A = (x² + νy²)/δ`, `B = −2xy/δ`, `δ = x² − νy²`. -/
noncomputable def Aent (ν x y : F) : F := (x ^ 2 + ν * y ^ 2) / (x ^ 2 - ν * y ^ 2)
noncomputable def Bent (ν x y : F) : F := -(2 * x * y) / (x ^ 2 - ν * y ^ 2)

/-- 8:D5, 8:D7 — `Λ(x, y) ∈ O(Q_ν)`: `A² − νB² = 1` (Proposition `boost-orthogonal`); and the group law
`Λ(x, y)Λ(u, v) = Λ(xu + νyv, xv + yu)` on the entries, with `Λ(1, 0) = I` and `Λ(x, −y) = Λ(x, y)⁻¹`
(Proposition `boost-subgroup`). -/
theorem boost_entries (ν x y u v : F) (hd : x ^ 2 - ν * y ^ 2 ≠ 0) (hd' : u ^ 2 - ν * v ^ 2 ≠ 0) :
    Aent ν x y ^ 2 - ν * Bent ν x y ^ 2 = 1 ∧
    Aent ν x y * Aent ν u v + ν * (Bent ν x y * Bent ν u v) = Aent ν (x * u + ν * y * v) (x * v + y * u) ∧
    Aent ν x y * Bent ν u v + Bent ν x y * Aent ν u v = Bent ν (x * u + ν * y * v) (x * v + y * u) ∧
    Aent ν 1 0 = 1 ∧ Bent ν 1 0 = 0 ∧ Aent ν x (-y) = Aent ν x y ∧ Bent ν x (-y) = -Bent ν x y := by
  have hdd : (x * u + ν * y * v) ^ 2 - ν * (x * v + y * u) ^ 2 = (x ^ 2 - ν * y ^ 2) * (u ^ 2 - ν * v ^ 2) := by
    ring
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> simp only [Aent, Bent]
  · field_simp; ring
  · rw [hdd]; field_simp; ring
  · rw [hdd]; field_simp; ring
  · norm_num
  · norm_num
  · ring
  · ring

/-- 8:D6 — the spin conjugation with the inverse: for `δ = x² − νy² ≠ 0`, `S⁻¹ = δ⁻¹(x − yM)` and
`S⁻¹γ⁰S = Aγ⁰ + νBγ¹`, `S⁻¹γ¹S = Bγ⁰ + Aγ¹` with `A = (x² + νy²)/δ`, `B = −2xy/δ` (Proposition
`spin-conjugation`). -/
theorem spin_conjugation_AB {i w ν x y : F} (hi : i * i = -1) (hw : w * w = ν) (hd : x ^ 2 - ν * y ^ 2 ≠ 0) :
    ((x ^ 2 - ν * y ^ 2)⁻¹ • (x • 1 + (-y) • Mγ i w)) * γ0 i w * (x • 1 + y • Mγ i w) =
      Aent ν x y • γ0 i w + (ν * Bent ν x y) • γ1 i ∧
    ((x ^ 2 - ν * y ^ 2)⁻¹ • (x • 1 + (-y) • Mγ i w)) * γ1 i * (x • 1 + y • Mγ i w) =
      Bent ν x y • γ0 i w + Aent ν x y • γ1 i := by
  obtain ⟨_, h0, h1, _, _⟩ := spin_conjugation hi hw x y
  refine ⟨?_, ?_⟩
  · rw [Matrix.smul_mul, Matrix.smul_mul, h0, smul_add, smul_smul, smul_smul]
    simp only [Aent, Bent]
    congr 2 <;> field_simp
  · rw [Matrix.smul_mul, Matrix.smul_mul, h1, smul_add, smul_smul, smul_smul]
    simp only [Aent, Bent]
    congr 2 <;> field_simp

end boostmatrix

/-! ## The worked shells (8:D12, B4, B3) -/
section shells

instance : Fact (Nat.Prime 13) := ⟨by norm_num⟩
instance : Fact (Nat.Prime 17) := ⟨by norm_num⟩

/-- 8:D12, 8:B4, 8:B3 [value] — `𝔽₁₃` with `ν = g = 2`, `x = y = 1`: `A = 10`, `B = 2`, `A² − νB² = 1`;
`2⁻¹ = 7` is a nonsquare and `e = 2^5 = 6` a nonsquare; `2` is primitive (`orderOf 2 = 12`). -/
theorem shell13 :
    Aent (2 : ZMod 13) 1 1 = 10 ∧ Bent (2 : ZMod 13) 1 1 = 2 ∧ (10 : ZMod 13) ^ 2 - 2 * 2 ^ 2 = 1 ∧
    (2 : ZMod 13) * 7 = 1 ∧ ¬ IsSquare (7 : ZMod 13) ∧ (2 : ZMod 13) ^ 5 = 6 ∧ ¬ IsSquare (6 : ZMod 13) ∧
    orderOf (2 : ZMod 13) = 12 := by
  refine ⟨?_, ?_, by decide, by decide, by decide, by decide, by decide, ?_⟩
  · simp only [Aent]; rw [div_eq_iff (by decide)]; decide
  · simp only [Bent]; rw [div_eq_iff (by decide)]; decide
  · rw [orderOf_eq_iff (by norm_num)]
    exact ⟨by decide, fun m hm hm0 => by interval_cases m <;> decide⟩

/-- 8:D12, 8:B3 [value] — `𝔽₁₇` (`κ = 4`) with `ν = g = 3`, `i = 4`: `A = 15`, `B = 1`, `A² − νB² = 1`;
`2 = 6²`, `i = 2²`, `e = 3⁴ = 13 = 8²` are squares (so the class of `e` is not stable across shells), `3` a
nonsquare, `3` primitive; `17 ≡ 5 (mod 12)`, and no capacity below `4` is even and `≡ 1 (mod 3)`: the
minimal admissible shell. -/
theorem shell17 :
    Aent (3 : ZMod 17) 1 1 = 15 ∧ Bent (3 : ZMod 17) 1 1 = 1 ∧ (15 : ZMod 17) ^ 2 - 3 * 1 ^ 2 = 1 ∧
    (3 : ZMod 17) ^ 4 = 13 ∧ (4 : ZMod 17) ^ 2 = -1 ∧ IsSquare (2 : ZMod 17) ∧ IsSquare (4 : ZMod 17) ∧
    IsSquare (13 : ZMod 17) ∧ ¬ IsSquare (3 : ZMod 17) ∧ orderOf (3 : ZMod 17) = 16 ∧ 17 % 12 = 5 ∧
    (Even 4 ∧ 4 % 3 = 1 ∧ Nat.Prime 17) ∧
    ∀ κ < 4, ¬ (Even κ ∧ κ % 3 = 1 ∧ Nat.Prime (4 * κ + 1)) := by
  refine ⟨?_, ?_, by decide, by decide, by decide, by decide, by decide, by decide, by decide, ?_, by decide,
    ⟨by decide, by decide, by norm_num⟩, ?_⟩
  · simp only [Aent]; rw [div_eq_iff (by decide)]; decide
  · simp only [Bent]; rw [div_eq_iff (by decide)]; decide
  · rw [orderOf_eq_iff (by norm_num)]
    exact ⟨by decide, fun m hm hm0 => by interval_cases m <;> decide⟩
  · intro κ hκ
    interval_cases κ <;> simp [Nat.even_iff]

/-- 8:B4, 8:A5 [value] — the laboratory Carrier `Ω = 2 408 561`: `c = 171 106` is base-rational with `c² = 2⁻¹`
(`171106² · 2 ≡ 1`), `2⁻¹ = 1 204 281`, and the two seats compose: `2⁻¹ · 12 ≡ 6 = g`. -/
theorem carrier_constants :
    (171106 * 171106 * 2) % 2408561 = 1 ∧ (2 * 1204281) % 2408561 = 1 ∧ (1204281 * 12) % 2408561 = 6 ∧
    Nat.Prime 2408561 := by
  refine ⟨by norm_num, by norm_num, by norm_num, by norm_num⟩

end shells

-- Ledger predicates of 8-dirac (generated by make_predicates.py from docs/8-dirac/8-dirac-ledger.json; edit the ledger, not this section)
/-- 8:A2 (p08002) — Finite-field algebra: the quadratic extension $K=\Fp[\w]/(\w^{2}-\nu)$ with Frobenius conjugation and norm, Hilbert's Theorem~90, the square classes by Euler's criterion, the unitary group of a nondegenerate Hermitian form over a finite field. Cited definitions (not proofs): FRC.Dirac.Ext.field. -/
theorem p08002 : (∀ {F : Type u_1} [CommRing F] {ν : F} (z z' : FRC.Dirac.Ext F ν), (z * z').norm = z.norm * z'.norm) ∧ ∀ {F : Type u_2} [Field F] {ν : F}, ¬IsSquare ν → ∀ {u : (FRC.Dirac.Ext F ν)ˣ}, u ∈ FRC.Dirac.Ext.normOneGroup F ν → ∃ z, FRC.Dirac.Ext.boost z = u :=
  And.intro @FRC.Dirac.Ext.norm_mul (@FRC.Dirac.Ext.exists_boost_eq)
/-- 8:A5 (p08005) — The programme's admissibility congruences ($\kap$ even, $\kap\equiv1\pmod3$, $\p\equiv5\pmod{12}$), the laboratory Carrier $\Omega=2\,408\,561$ with $S=602\,140$, and the constants web ($c^{2}=2^{-1}$, $\hbar=\It$). -/
theorem p08005 : (171106 : ℕ) * (171106 : ℕ) * (2 : ℕ) % (2408561 : ℕ) = (1 : ℕ) ∧ (2 : ℕ) * (1204281 : ℕ) % (2408561 : ℕ) = (1 : ℕ) ∧ (1204281 : ℕ) * (12 : ℕ) % (2408561 : ℕ) = (6 : ℕ) ∧ Nat.Prime (2408561 : ℕ) :=
  @FRC.Dirac.carrier_constants
/-- 8:B2 (p08008) — The class is the datum: $\Fpx/(\Fpx)^{2}$ has order two, any two nonsquares differ by a square factor, and the Lorentzian form depends on $\nu$ only through its class. -/
theorem p08008 : (∀ {p : ℕ} [hp : Fact (Nat.Prime p)] {a b : ZMod p}, a ≠ (0 : ZMod p) → b ≠ (0 : ZMod p) → ¬IsSquare a → ¬IsSquare b → IsSquare (a * b)) ∧ ∀ {K : Type u_1} [CommRing K] (ν m x₀ x₁ x₂ x₃ : K), -(m ^ (2 : ℕ) * ν) * x₀ ^ (2 : ℕ) + x₁ ^ (2 : ℕ) + x₂ ^ (2 : ℕ) + x₃ ^ (2 : ℕ) = -ν * (m * x₀) ^ (2 : ℕ) + x₁ ^ (2 : ℕ) + x₂ ^ (2 : ℕ) + x₃ ^ (2 : ℕ) :=
  And.intro @FRC.Dirac.class_datum (@FRC.Dirac.form_class)
/-- 8:B3 (p08009) — The drive is canonical: $g$ is a nonsquare on every shell and the only named residue whose class is nonsquare on every symmetry-complete shell; $\It$, $2$, $2^{-1}$, $-2$ are squares exactly when $\kap$ is even; $e=g^{\It}$ has no stable class; $[g^{-1}]=[g]$. Exhaustive on $\p<2000$. -/
theorem p08009 : (∀ {p : ℕ} [hp : Fact (Nat.Prime p)] {g : ZMod p}, orderOf g = p - (1 : ℕ) → p % (2 : ℕ) = (1 : ℕ) → ¬IsSquare g ∧ ¬IsSquare g⁻¹) ∧ (∀ (κ : ℕ) [hp' : Fact (Nat.Prime ((4 : ℕ) * κ + (1 : ℕ)))] {g : ZMod ((4 : ℕ) * κ + (1 : ℕ))}, orderOf g = (4 : ℕ) * κ → (IsSquare (2 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) ↔ Even κ) ∧ (IsSquare (2 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))⁻¹ ↔ Even κ) ∧ (IsSquare (-2 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) ↔ Even κ) ∧ (IsSquare (g ^ ((3 : ℕ) * κ)) ↔ Even κ) ∧ g ^ ((3 : ℕ) * κ) = -g ^ κ ∧ IsSquare (-1 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))) ∧ (FRC.Dirac.Aent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (10 : ZMod (13 : ℕ)) ∧ FRC.Dirac.Bent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (2 : ZMod (13 : ℕ)) ∧ (10 : ZMod (13 : ℕ)) ^ (2 : ℕ) - (2 : ZMod (13 : ℕ)) * (2 : ZMod (13 : ℕ)) ^ (2 : ℕ) = (1 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) * (7 : ZMod (13 : ℕ)) = (1 : ZMod (13 : ℕ)) ∧ ¬IsSquare (7 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) ^ (5 : ℕ) = (6 : ZMod (13 : ℕ)) ∧ ¬IsSquare (6 : ZMod (13 : ℕ)) ∧ orderOf (2 : ZMod (13 : ℕ)) = (12 : ℕ)) ∧ FRC.Dirac.Aent (3 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) = (15 : ZMod (17 : ℕ)) ∧ FRC.Dirac.Bent (3 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) = (1 : ZMod (17 : ℕ)) ∧ (15 : ZMod (17 : ℕ)) ^ (2 : ℕ) - (3 : ZMod (17 : ℕ)) * (1 : ZMod (17 : ℕ)) ^ (2 : ℕ) = (1 : ZMod (17 : ℕ)) ∧ (3 : ZMod (17 : ℕ)) ^ (4 : ℕ) = (13 : ZMod (17 : ℕ)) ∧ (4 : ZMod (17 : ℕ)) ^ (2 : ℕ) = (-1 : ZMod (17 : ℕ)) ∧ IsSquare (2 : ZMod (17 : ℕ)) ∧ IsSquare (4 : ZMod (17 : ℕ)) ∧ IsSquare (13 : ZMod (17 : ℕ)) ∧ ¬IsSquare (3 : ZMod (17 : ℕ)) ∧ orderOf (3 : ZMod (17 : ℕ)) = (16 : ℕ) ∧ (17 : ℕ) % (12 : ℕ) = (5 : ℕ) ∧ (Even (4 : ℕ) ∧ (4 : ℕ) % (3 : ℕ) = (1 : ℕ) ∧ Nat.Prime (17 : ℕ)) ∧ ∀ κ < (4 : ℕ), ¬(Even κ ∧ κ % (3 : ℕ) = (1 : ℕ) ∧ Nat.Prime ((4 : ℕ) * κ + (1 : ℕ))) :=
  And.intro @FRC.Dirac.drive_nonsquare (And.intro @FRC.Dirac.named_residues (And.intro @FRC.Dirac.shell13 (@FRC.Dirac.shell17)))
/-- 8:B4 (p08010) — The two speed-of-light seats: $\nu=g=c^{2}\cdot(2g)$ exactly on every shell; $[c^{2}]$ is even iff $\kap$ is even, $[2g]$ odd iff $\kap$ is even, the product odd always; the temporal coefficient is not $c^{2}$; anchors $\F_{13}$ ($2^{-1}=7$ nonsquare), $\F_{17}$ ($2,\It,e$ squares), and the laboratory Carrier ($c=171\,106$ base-rational, $1\,204\,281\cdot12=6=g$). -/
theorem p08010 : (∀ {K : Type u_1} [Field K] (g : K), (2 : K) ≠ (0 : K) → (2 : K)⁻¹ * ((2 : K) * g) = g) ∧ (∀ {p : ℕ} [hp : Fact (Nat.Prime p)] {g : ZMod p}, g ≠ (0 : ZMod p) → ¬IsSquare g → (2 : ZMod p) ≠ (0 : ZMod p) → (IsSquare ((2 : ZMod p) * g) ↔ ¬IsSquare (2 : ZMod p))) ∧ (∀ (κ : ℕ) [hp' : Fact (Nat.Prime ((4 : ℕ) * κ + (1 : ℕ)))] {g : ZMod ((4 : ℕ) * κ + (1 : ℕ))}, orderOf g = (4 : ℕ) * κ → (IsSquare (2 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) ↔ Even κ) ∧ (IsSquare (2 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))⁻¹ ↔ Even κ) ∧ (IsSquare (-2 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) ↔ Even κ) ∧ (IsSquare (g ^ ((3 : ℕ) * κ)) ↔ Even κ) ∧ g ^ ((3 : ℕ) * κ) = -g ^ κ ∧ IsSquare (-1 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))) ∧ (FRC.Dirac.Aent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (10 : ZMod (13 : ℕ)) ∧ FRC.Dirac.Bent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (2 : ZMod (13 : ℕ)) ∧ (10 : ZMod (13 : ℕ)) ^ (2 : ℕ) - (2 : ZMod (13 : ℕ)) * (2 : ZMod (13 : ℕ)) ^ (2 : ℕ) = (1 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) * (7 : ZMod (13 : ℕ)) = (1 : ZMod (13 : ℕ)) ∧ ¬IsSquare (7 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) ^ (5 : ℕ) = (6 : ZMod (13 : ℕ)) ∧ ¬IsSquare (6 : ZMod (13 : ℕ)) ∧ orderOf (2 : ZMod (13 : ℕ)) = (12 : ℕ)) ∧ (171106 : ℕ) * (171106 : ℕ) * (2 : ℕ) % (2408561 : ℕ) = (1 : ℕ) ∧ (2 : ℕ) * (1204281 : ℕ) % (2408561 : ℕ) = (1 : ℕ) ∧ (1204281 : ℕ) * (12 : ℕ) % (2408561 : ℕ) = (6 : ℕ) ∧ Nat.Prime (2408561 : ℕ) :=
  And.intro @FRC.Dirac.nu_factorisation (And.intro @FRC.Dirac.two_g_class (And.intro @FRC.Dirac.named_residues (And.intro @FRC.Dirac.shell13 (@FRC.Dirac.carrier_constants))))
/-- 8:B5 (p08011) — The square class is chronon parity: the squares are $\langle g^{2}\rangle$, a residue's class is the parity of its drive-step count; on $\kap$-even shells every element of $Q_4=\{1,\It,-1,-\It\}$ is a square, so the order-four chart grading carries no signature. Exhaustive over every primitive root of $\F_{13}$, $\F_{17}$; Euler form on $\p<2000$. -/
theorem p08011 : ∀ {p : ℕ} [hp : Fact (Nat.Prime p)] {g : ZMod p}, orderOf g = p - (1 : ℕ) → p % (2 : ℕ) = (1 : ℕ) → ∀ (k : ℕ), IsSquare (g ^ k) ↔ Even k :=
  @FRC.Dirac.parity_iff
/-- 8:B6 (p08012) — Norm growth and parity: $N(gz)=g^{2}N(z)$ with $g^{2}$ a square, the single-chronon multiplier $g$ odd, $x^{2}=\nu$ unsolvable in $\Fp$; the flip $g\mapsto g^{-1}$ preserves the parity class. -/
theorem p08012 : ∀ {K : Type u_1} [Field K] {ν : K} (g : K) (z : FRC.Dirac.Ext K ν), (FRC.Dirac.Ext.ofBase g * z).norm = g ^ (2 : ℕ) * z.norm :=
  @FRC.Dirac.norm_growth
/-- 8:B7 (p08013) — Signature lives on $\Fp$: the Euclidean form has $\p^{3}+\p^{2}-\p$ zeros (hyperbolic, Witt index two), $Q_\nu$ has $\p^{3}-\p^{2}+\p$ (elliptic, Witt index one) on every symmetry-complete $\p<60$; $2353$ and $2041$ at $\p=13$; over $K$ every element of $\Fp$ is a square and the dichotomy collapses. -/
theorem p08013 : ∀ {p : Nat} [hp : Fact (Nat.Prime p)] {ν : ZMod p}, Not (@IsSquare (ZMod p) (@Distrib.toMul (ZMod p) (@instDistribOfSemiring (ZMod p) (@CommSemiring.toSemiring (ZMod p) (@Semifield.toCommSemiring (ZMod p) (@Field.toSemifield (ZMod p) (@ZMod.instField p hp)))))) ν) → ∀ (a : ZMod p), @IsSquare (FRC.Dirac.Ext (ZMod p) ν) (@FRC.Dirac.Ext.instMul (ZMod p) (ZMod.commRing p) ν) (@FRC.Dirac.Ext.ofBase (ZMod p) (ZMod.commRing p) ν a) :=
  @FRC.Dirac.ext_square
/-- 8:C2 (p08016) — The form is Hermitian and nondegenerate; $T_u$ is unitary with $T_u^{\dagger}=T_{-u}$; $\Delta_E$ and $H_{E,V,\vkap}$ are self-adjoint; under $A\in\mathrm{GL}_d(\Fp)$ the pullback $A_*$ intertwines translations, differences and Laplacians of the two frames. -/
theorem p08016 : (∀ {K : Type u_1} [CommRing K] [StarRing K] {X : Type u_5} [Fintype X] (ψ φ : X → K), star (FRC.Dirac.herm ψ φ) = FRC.Dirac.herm φ ψ) ∧ (∀ {K : Type u_6} [CommRing K] [StarRing K] {X : Type u_7} [Fintype X] [DecidableEq X] (ψ : X → K), (∀ (φ : X → K), FRC.Dirac.herm ψ φ = (0 : K)) → ψ = (0 : X → K)) ∧ (∀ {K : Type u_8} [CommRing K] [StarRing K] {G : Type u_9} [AddGroup G] [Fintype G] (u : G) (ψ φ : G → K), FRC.Dirac.herm (FRC.Dirac.translate u ψ) (FRC.Dirac.translate u φ) = FRC.Dirac.herm ψ φ) ∧ (∀ {K : Type u_10} [CommRing K] [StarRing K] {G : Type u_11} [AddGroup G] [Fintype G] (u : G) (ψ φ : G → K), FRC.Dirac.herm (FRC.Dirac.translate u ψ) φ = FRC.Dirac.herm ψ (FRC.Dirac.translate (-u) φ)) ∧ (∀ {K : Type u_12} [CommRing K] [StarRing K] {G : Type u_2} [AddGroup G] [Fintype G] (e : G) (ψ φ : G → K), FRC.Dirac.herm (FRC.Dirac.laplacian e ψ) φ = FRC.Dirac.herm ψ (FRC.Dirac.laplacian e φ)) ∧ ∀ {K : Type u_3} [CommRing K] [StarRing K] {G : Type u_4} [AddGroup G] [Fintype G] (e : G) (ϰ : K), star ϰ = ϰ → ∀ (V : G → K), (∀ (x : G), star (V x) = V x) → ∀ (ψ φ : G → K), FRC.Dirac.herm (FRC.Dirac.hamiltonian e ϰ V ψ) φ = FRC.Dirac.herm ψ (FRC.Dirac.hamiltonian e ϰ V φ) :=
  And.intro @FRC.Dirac.herm_star (And.intro @FRC.Dirac.herm_nondegenerate (And.intro @FRC.Dirac.herm_translate (And.intro @FRC.Dirac.herm_translate_adjoint (And.intro @FRC.Dirac.herm_laplacian (@FRC.Dirac.herm_hamiltonian)))))
/-- 8:C4 (p08018) — Exact Hermitian preservation: for self-adjoint $H$ and admissible $\alpha$ the Cayley step is unitary, and every orbit is periodic. -/
theorem p08018 : (∀ {R : Type u_1} [Ring R] (σ : R → R), (∀ (x y : R), σ (x * y) = σ y * σ x) → (∀ (x y : R), σ (x + y) = σ x + σ y) → σ (1 : R) = (1 : R) → (∀ (x : R), σ (-x) = -σ x) → ∀ {h a : R}, σ h = h → σ a = -a → (∀ (x : R), Commute a x) → ∀ (hu : IsUnit ((1 : R) - a * h)), have u := ↑hu.unit⁻¹ * ((1 : R) + a * h); σ u * u = (1 : R)) ∧ ∀ {R : Type u_2} [Ring R] [Finite R] (u : Rˣ), IsOfFinOrder u :=
  And.intro @FRC.Dirac.cayley_unitary (@FRC.Dirac.cayley_periodic)
set_option linter.defProp false in
/-- 8:C5 (p08019) — The finite Cayley transform: $\varphi(\lambda)=(1+\alpha\lambda)/(1-\alpha\lambda)$ is defined on all of $\Fp$, takes values in the norm-one torus $N^{1}$, and with $\varphi(\infty)=-1$ bijects $\mathbb P^{1}(\Fp)$ onto $N^{1}$, $|N^{1}|=\p+1$; the unitary group of one channel is $N^{1}$; the orientation gauge $\alpha\mapsto-\alpha$ inverts every $\varphi(\lambda)$ and imports the derived orientation of the shell. -/
def p08019 := And.intro @FRC.Dirac.Ext.cayley_norm (And.intro @FRC.Dirac.Ext.cayley_injective (And.intro @FRC.Dirac.Ext.card_normOneGroup (@FRC.Dirac.Ext.cayley_gauge)))
set_option linter.defProp false in
/-- 8:C6 (p08020) — The $\F_{13}$ Schr\"odinger example: $H=-\Delta_E$ on $\F_{13}$ is nilpotent, so $\calA(H)=K^{-}$; at $\alpha=c$, $U^{13}=I$; every $\alpha=kc$, $k\ne0$, gives order $13$, and $U$ is unitary for the form. -/
def p08020 := And.intro @FRC.Dirac.kinetic_nilpotent (@FRC.Dirac.cayley_period)
/-- 8:D2 (p08022) — The Clifford relations $\gamma^{\mu}\gamma^{\nu}+\gamma^{\nu}\gamma^{\mu}=2\eta_{\mu\nu}I_4$. -/
theorem p08022 : (∀ {K : Type u_1} [CommRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → FRC.Dirac.γ0 i w * FRC.Dirac.γ0 i w = -ν • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ1 i * FRC.Dirac.γ1 i = (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ2 i * FRC.Dirac.γ2 i = (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ3 i * FRC.Dirac.γ3 i = (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ0 i w * FRC.Dirac.γ1 i + FRC.Dirac.γ1 i * FRC.Dirac.γ0 i w = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ0 i w * FRC.Dirac.γ2 i + FRC.Dirac.γ2 i * FRC.Dirac.γ0 i w = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ0 i w * FRC.Dirac.γ3 i + FRC.Dirac.γ3 i * FRC.Dirac.γ0 i w = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ1 i * FRC.Dirac.γ2 i + FRC.Dirac.γ2 i * FRC.Dirac.γ1 i = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ1 i * FRC.Dirac.γ3 i + FRC.Dirac.γ3 i * FRC.Dirac.γ1 i = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.γ2 i * FRC.Dirac.γ3 i + FRC.Dirac.γ3 i * FRC.Dirac.γ2 i = (0 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K)) ∧ ∀ {K : Type u_2} [CommRing K] {i : K}, i * i = (-1 : K) → FRC.Dirac.σ1 * FRC.Dirac.σ1 = (1 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Dirac.σ2 i * FRC.Dirac.σ2 i = (1 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Dirac.σ3 * FRC.Dirac.σ3 = (1 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Dirac.σ1 * FRC.Dirac.σ2 i + FRC.Dirac.σ2 i * FRC.Dirac.σ1 = (0 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Dirac.σ1 * FRC.Dirac.σ3 + FRC.Dirac.σ3 * FRC.Dirac.σ1 = (0 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Dirac.σ2 i * FRC.Dirac.σ3 + FRC.Dirac.σ3 * FRC.Dirac.σ2 i = (0 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) :=
  And.intro @FRC.Dirac.clifford (@FRC.Dirac.pauli)
set_option linter.defProp false in
/-- 8:D5 (p08025) — The boost group is the non-split torus: $\Lambda(x,y)\in O(Q_\nu,\Fp)$, $G_\nu$ a subgroup, $z\mapsto\Lambda$ a surjection $K^{\times}\to G_\nu$ with kernel $\Fpx$ and $A-B\w=z/\bar z$; $G_\nu\simeq N^{1}\simeq C_{\p+1}$, cyclic; an order-three boost exists iff $3\mid\p+1$ ($|G_3|=18$ at $17$, $|G_2|=14$ at $13$). -/
def p08025 := And.intro @FRC.Dirac.boost_entries (And.intro @FRC.Dirac.Ext.boost_mem (And.intro @FRC.Dirac.Ext.boost_eq_one_iff (And.intro @FRC.Dirac.Ext.boost_range (And.intro @FRC.Dirac.Ext.card_normOneGroup (And.intro @FRC.Dirac.Ext.normOne_cyclic (@FRC.Dirac.Ext.order_three_iff))))))
/-- 8:D6 (p08026) — Spin conjugation: $S^{-1}\gamma^{0}S=A\gamma^{0}+\nu B\gamma^{1}$, $S^{-1}\gamma^{1}S=B\gamma^{0}+A\gamma^{1}$, $\gamma^{2},\gamma^{3}$ fixed. -/
theorem p08026 : (∀ {K : Type u_1} [CommRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → ∀ (x y : K), FRC.Dirac.Mγ i w * FRC.Dirac.Mγ i w = ν • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ0 i w * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = (x ^ (2 : ℕ) + ν * y ^ (2 : ℕ)) • FRC.Dirac.γ0 i w + -((2 : K) * x * y * ν) • FRC.Dirac.γ1 i ∧ (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ1 i * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = -((2 : K) * x * y) • FRC.Dirac.γ0 i w + (x ^ (2 : ℕ) + ν * y ^ (2 : ℕ)) • FRC.Dirac.γ1 i ∧ FRC.Dirac.Mγ i w * FRC.Dirac.γ2 i = FRC.Dirac.γ2 i * FRC.Dirac.Mγ i w ∧ FRC.Dirac.Mγ i w * FRC.Dirac.γ3 i = FRC.Dirac.γ3 i * FRC.Dirac.Mγ i w) ∧ ∀ {F : Type u_2} [Field F] {i w ν x y : F}, i * i = (-1 : F) → w * w = ν → x ^ (2 : ℕ) - ν * y ^ (2 : ℕ) ≠ (0 : F) → (x ^ (2 : ℕ) - ν * y ^ (2 : ℕ))⁻¹ • (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) F) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ0 i w * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) F) + y • FRC.Dirac.Mγ i w) = FRC.Dirac.Aent ν x y • FRC.Dirac.γ0 i w + (ν * FRC.Dirac.Bent ν x y) • FRC.Dirac.γ1 i ∧ (x ^ (2 : ℕ) - ν * y ^ (2 : ℕ))⁻¹ • (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) F) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ1 i * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) F) + y • FRC.Dirac.Mγ i w) = FRC.Dirac.Bent ν x y • FRC.Dirac.γ0 i w + FRC.Dirac.Aent ν x y • FRC.Dirac.γ1 i :=
  And.intro @FRC.Dirac.spin_conjugation (@FRC.Dirac.spin_conjugation_AB)
/-- 8:D7 (p08027) — The transported family: $\nabla^{E_\Lambda}_\mu\Lambda_*=\Lambda_*\nabla^{E_0}_\mu$; $\mathcal D_{\Lambda,S}=\sum\widehat\gamma^{\mu}\nabla^{E_\Lambda}_\mu$ with $\widehat\gamma^{0}=A\gamma^{0}-\nu B\gamma^{1}$, $\widehat\gamma^{1}=-B\gamma^{0}+A\gamma^{1}$; the transported Clifford relations and factorization. -/
theorem p08027 : (∀ {K : Type u_1} [CommRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → ∀ (x y : K), FRC.Dirac.Mγ i w * FRC.Dirac.Mγ i w = ν • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ0 i w * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = (x ^ (2 : ℕ) + ν * y ^ (2 : ℕ)) • FRC.Dirac.γ0 i w + -((2 : K) * x * y * ν) • FRC.Dirac.γ1 i ∧ (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w) * FRC.Dirac.γ1 i * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = -((2 : K) * x * y) • FRC.Dirac.γ0 i w + (x ^ (2 : ℕ) + ν * y ^ (2 : ℕ)) • FRC.Dirac.γ1 i ∧ FRC.Dirac.Mγ i w * FRC.Dirac.γ2 i = FRC.Dirac.γ2 i * FRC.Dirac.Mγ i w ∧ FRC.Dirac.Mγ i w * FRC.Dirac.γ3 i = FRC.Dirac.γ3 i * FRC.Dirac.Mγ i w) ∧ ∀ {F : Type u_2} [Field F] (ν x y u v : F), x ^ (2 : ℕ) - ν * y ^ (2 : ℕ) ≠ (0 : F) → u ^ (2 : ℕ) - ν * v ^ (2 : ℕ) ≠ (0 : F) → FRC.Dirac.Aent ν x y ^ (2 : ℕ) - ν * FRC.Dirac.Bent ν x y ^ (2 : ℕ) = (1 : F) ∧ FRC.Dirac.Aent ν x y * FRC.Dirac.Aent ν u v + ν * (FRC.Dirac.Bent ν x y * FRC.Dirac.Bent ν u v) = FRC.Dirac.Aent ν (x * u + ν * y * v) (x * v + y * u) ∧ FRC.Dirac.Aent ν x y * FRC.Dirac.Bent ν u v + FRC.Dirac.Bent ν x y * FRC.Dirac.Aent ν u v = FRC.Dirac.Bent ν (x * u + ν * y * v) (x * v + y * u) ∧ FRC.Dirac.Aent ν (1 : F) (0 : F) = (1 : F) ∧ FRC.Dirac.Bent ν (1 : F) (0 : F) = (0 : F) ∧ FRC.Dirac.Aent ν x (-y) = FRC.Dirac.Aent ν x y ∧ FRC.Dirac.Bent ν x (-y) = -FRC.Dirac.Bent ν x y :=
  And.intro @FRC.Dirac.spin_conjugation (@FRC.Dirac.boost_entries)
/-- 8:D9 (p08029) — The spinor form: under the plain conjugate transpose the gammas carry mixed signs ($\gamma^{2}$ the obstruction) and the $\gamma^{0}$-twist fails; $X=\gamma^{0}\gamma^{1}\gamma^{3}$ is Hermitian with $X^{2}=\nu$, commutes with $\gamma^{0},\gamma^{1},\gamma^{3}$, anticommutes with $\gamma^{2}$, and $X^{-1}(\gamma^{\mu})^{\dagger}X=-\gamma^{\mu}$ for all $\mu$; $\langle\cdot,\cdot\rangle_X$ is nondegenerate Hermitian, $T-T^{-1}$ nilpotent and anti-self-adjoint, $\mathcal D^{s}$ $X$-self-adjoint and nilpotent ($\p=5,13,17$). -/
theorem p08029 : (∀ {K : Type u_1} [CommRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → FRC.Dirac.Xγ i w * FRC.Dirac.Xγ i w = ν • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) ∧ FRC.Dirac.Xγ i w * FRC.Dirac.γ0 i w = FRC.Dirac.γ0 i w * FRC.Dirac.Xγ i w ∧ FRC.Dirac.Xγ i w * FRC.Dirac.γ1 i = FRC.Dirac.γ1 i * FRC.Dirac.Xγ i w ∧ FRC.Dirac.Xγ i w * FRC.Dirac.γ3 i = FRC.Dirac.γ3 i * FRC.Dirac.Xγ i w ∧ FRC.Dirac.Xγ i w * FRC.Dirac.γ2 i = -(FRC.Dirac.γ2 i * FRC.Dirac.Xγ i w)) ∧ (∀ {K : Type u_2} [CommRing K] [StarRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → star i = i → star w = -w → (FRC.Dirac.γ0 i w).conjTranspose = -FRC.Dirac.γ0 i w ∧ (FRC.Dirac.γ1 i).conjTranspose = -FRC.Dirac.γ1 i ∧ (FRC.Dirac.γ2 i).conjTranspose = FRC.Dirac.γ2 i ∧ (FRC.Dirac.γ3 i).conjTranspose = -FRC.Dirac.γ3 i ∧ (FRC.Dirac.Xγ i w).conjTranspose = FRC.Dirac.Xγ i w) ∧ ∀ {K : Type u_3} [CommRing K] [StarRing K] {i w ν : K}, i * i = (-1 : K) → w * w = ν → star i = i → star w = -w → (FRC.Dirac.γ0 i w).conjTranspose * FRC.Dirac.Xγ i w = -(FRC.Dirac.Xγ i w * FRC.Dirac.γ0 i w) ∧ (FRC.Dirac.γ1 i).conjTranspose * FRC.Dirac.Xγ i w = -(FRC.Dirac.Xγ i w * FRC.Dirac.γ1 i) ∧ (FRC.Dirac.γ2 i).conjTranspose * FRC.Dirac.Xγ i w = -(FRC.Dirac.Xγ i w * FRC.Dirac.γ2 i) ∧ (FRC.Dirac.γ3 i).conjTranspose * FRC.Dirac.Xγ i w = -(FRC.Dirac.Xγ i w * FRC.Dirac.γ3 i) ∧ (FRC.Dirac.γ0 i w).conjTranspose * FRC.Dirac.γ0 i w = -(FRC.Dirac.γ0 i w * FRC.Dirac.γ0 i w) ∧ (FRC.Dirac.γ1 i).conjTranspose * FRC.Dirac.γ0 i w = FRC.Dirac.γ0 i w * FRC.Dirac.γ1 i :=
  And.intro @FRC.Dirac.spinor_twist (And.intro @FRC.Dirac.gamma_dagger (@FRC.Dirac.twist_adjoint))
/-- 8:D10 (p08030) — Exact Dirac evolution: the Cayley step of $H=\mathcal D^{s}-mI$ preserves $\langle\cdot,\cdot\rangle_X$; for $m=0$ admissibility is automatic, $U$ unipotent with order a power of $\p$ ($25=\p^{2}$ in the $1{+}1$ computation at $\p=5$); for $m\ne0$, $U=\varphi(-m)V$ and $\operatorname{ord}(U)=\operatorname{lcm}(\p^{a},\operatorname{ord}_{N^{1}}\varphi(-m))$ ($75$, $150$ at $m=1,2$). -/
theorem p08030 : (∀ {R : Type u_1} [Ring R] (σ : R → R), (∀ (x y : R), σ (x * y) = σ y * σ x) → (∀ (x y : R), σ (x + y) = σ x + σ y) → σ (1 : R) = (1 : R) → (∀ (x : R), σ (-x) = -σ x) → ∀ {h a : R}, σ h = h → σ a = -a → (∀ (x : R), Commute a x) → ∀ (hu : IsUnit ((1 : R) - a * h)), have u := ↑hu.unit⁻¹ * ((1 : R) + a * h); σ u * u = (1 : R)) ∧ ∀ {R : Type u_2} [Ring R] {p : ℕ} [hp : Fact (Nat.Prime p)] [CharP R p] {t : R}, t ^ p = (1 : R) → (t - (1 : R)) ^ p = (0 : R) :=
  And.intro @FRC.Dirac.cayley_unitary (@FRC.Dirac.translation_nilpotent)
/-- 8:D11 (p08031) — The two Dirac operators are one covariant family: the pullback identity holds for the symmetric differences, $\mathcal T_{\Lambda,S}$ carries $\mathcal D^{s}$ to its transported form, and the spinor form transports by the norm, $S(x,y)^{\#}=S(x,-y)=\delta S^{-1}$: norm-one lifts preserve $\langle\cdot,\cdot\rangle_X$ exactly, the odd coset scales it by the nonsquare class. -/
theorem p08031 : (∀ {K : Type u_1} [CommRing K] [StarRing K] {i w ν x y : K}, i * i = (-1 : K) → w * w = ν → star w = -w → star x = x → star y = y → (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w).conjTranspose = x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w ∧ (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + -y • FRC.Dirac.Mγ i w) * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = (x ^ (2 : ℕ) - ν * y ^ (2 : ℕ)) • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K)) ∧ ∀ {K : Type u_2} [CommRing K] [StarRing K] {i w ν x y : K}, i * i = (-1 : K) → w * w = ν → star i = i → star w = -w → star x = x → star y = y → (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w).conjTranspose * FRC.Dirac.Xγ i w * (x • (1 : Matrix (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) (Fin (2 : ℕ) ⊕ Fin (2 : ℕ)) K) + y • FRC.Dirac.Mγ i w) = (x ^ (2 : ℕ) - ν * y ^ (2 : ℕ)) • FRC.Dirac.Xγ i w :=
  And.intro @FRC.Dirac.lift_adjoint (@FRC.Dirac.lift_transport)
/-- 8:D12 (p08032) — The worked shells: $\F_{13}$ with $\nu=g=2$, $x=y=1$: $A=10$, $B=2$, $S=I+\gamma^{0}\gamma^{1}$, $\widehat\gamma^{0}=10\gamma^{0}-4\gamma^{1}$, $\widehat\gamma^{1}=-2\gamma^{0}+10\gamma^{1}$; $\F_{17}$ the minimal admissible shell ($17\equiv5\bmod12$, no smaller symmetry-complete prime), $\It=4$, $2,\It,e$ squares, $\nu=3$, $A=15$, $B=1$, $|G_3|=18$, triality present. -/
theorem p08032 : (FRC.Dirac.Aent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (10 : ZMod (13 : ℕ)) ∧ FRC.Dirac.Bent (2 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) (1 : ZMod (13 : ℕ)) = (2 : ZMod (13 : ℕ)) ∧ (10 : ZMod (13 : ℕ)) ^ (2 : ℕ) - (2 : ZMod (13 : ℕ)) * (2 : ZMod (13 : ℕ)) ^ (2 : ℕ) = (1 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) * (7 : ZMod (13 : ℕ)) = (1 : ZMod (13 : ℕ)) ∧ ¬IsSquare (7 : ZMod (13 : ℕ)) ∧ (2 : ZMod (13 : ℕ)) ^ (5 : ℕ) = (6 : ZMod (13 : ℕ)) ∧ ¬IsSquare (6 : ZMod (13 : ℕ)) ∧ orderOf (2 : ZMod (13 : ℕ)) = (12 : ℕ)) ∧ FRC.Dirac.Aent (3 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) = (15 : ZMod (17 : ℕ)) ∧ FRC.Dirac.Bent (3 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) (1 : ZMod (17 : ℕ)) = (1 : ZMod (17 : ℕ)) ∧ (15 : ZMod (17 : ℕ)) ^ (2 : ℕ) - (3 : ZMod (17 : ℕ)) * (1 : ZMod (17 : ℕ)) ^ (2 : ℕ) = (1 : ZMod (17 : ℕ)) ∧ (3 : ZMod (17 : ℕ)) ^ (4 : ℕ) = (13 : ZMod (17 : ℕ)) ∧ (4 : ZMod (17 : ℕ)) ^ (2 : ℕ) = (-1 : ZMod (17 : ℕ)) ∧ IsSquare (2 : ZMod (17 : ℕ)) ∧ IsSquare (4 : ZMod (17 : ℕ)) ∧ IsSquare (13 : ZMod (17 : ℕ)) ∧ ¬IsSquare (3 : ZMod (17 : ℕ)) ∧ orderOf (3 : ZMod (17 : ℕ)) = (16 : ℕ) ∧ (17 : ℕ) % (12 : ℕ) = (5 : ℕ) ∧ (Even (4 : ℕ) ∧ (4 : ℕ) % (3 : ℕ) = (1 : ℕ) ∧ Nat.Prime (17 : ℕ)) ∧ ∀ κ < (4 : ℕ), ¬(Even κ ∧ κ % (3 : ℕ) = (1 : ℕ) ∧ Nat.Prime ((4 : ℕ) * κ + (1 : ℕ))) :=
  And.intro @FRC.Dirac.shell13 (@FRC.Dirac.shell17)
set_option linter.defProp false in
/-- 8:E2 (p08035) — A self-map is bijective iff $L_X(f)=1$; the power map $x\mapsto x^{\varepsilon}$ on $\Fpx$ has image $(\p-1)/d$ and loss factor $d=\gcd(\varepsilon,\p-1)$, every nonempty fibre of size $d$ ($\varepsilon=1,2,3,4,6,12$ on $\F_{13}$). -/
def p08035 := And.intro @FRC.Dirac.loss_factor_one (@FRC.Dirac.power_map_count)
set_option linter.defProp false in
/-- 8:E3 (p08036) — Cayley propagators and boost transports have loss factor one: the wave dynamics is isentropic, compression confined to the power-map layer. -/
def p08036 := @FRC.Dirac.unit_loss_factor_one
set_option linter.defProp false in
/-- 8:E4 (p08037) — Period dichotomy: kinetic Hamiltonians are nilpotent, fully admissible, with unipotent propagators of order $\p$; potential Hamiltonians give diagonal propagators with phases in $N^{1}$ and order dividing $\p+1$ ($14$ at $13$, $18$ at $17$); the mixed datum $\operatorname{ord}(U)=1563$ at $\p=5$; composites take the lcm ($13,14\mapsto182$); the three tori $C_{\p-1}$, $C_\p$, $C_{\p+1}$ each govern one dynamical role. -/
def p08037 := And.intro @FRC.Dirac.cayley_period (And.intro @FRC.Dirac.kinetic_nilpotent (@FRC.Dirac.Ext.torus_period))
/-- 8:F2 (p08039) — The latitude identities: $\kap+1$ is the first rung past the midpoint of the ladder $1,\dots,2\kap$; $m\mapsto m+\kap$ is multiplication by $g^{\kap}=\pm\It$ and $a\mapsto a+\kap$ sends $1$ to $\kap+1$; $\kap=-4^{-1}$ so the energy radius is $3\cdot4^{-1}$; $\pi=2\kap=-2^{-1}=-c^{2}$, on the Carrier $\pi_\Omega=2S$; the unit-norm circle has $\p-1$ points. On $\F_{13}$, $\F_{17}$ and the laboratory Carrier. -/
theorem p08039 : ∀ (κ : ℕ) [hp : Fact (Nat.Prime ((4 : ℕ) * κ + (1 : ℕ)))] {g : ZMod ((4 : ℕ) * κ + (1 : ℕ))}, orderOf g = (4 : ℕ) * κ → (4 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) * ↑κ = (-1 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) ∧ ↑κ = -(4 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))⁻¹ ∧ (1 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) + ↑κ = (3 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) * (4 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))⁻¹ ∧ (2 : ZMod ((4 : ℕ) * κ + (1 : ℕ))) * ↑κ = -(2 : ZMod ((4 : ℕ) * κ + (1 : ℕ)))⁻¹ ∧ g ^ κ = -g ^ ((3 : ℕ) * κ) ∧ κ + (1 : ℕ) ≤ (2 : ℕ) * κ :=
  @FRC.Dirac.latitude_identities
set_option linter.defProp false in
/-- 8:F3 (p08040) — The free evolution is the drive: the pullback $D\psi(x)=\psi(g^{-1}x)$ is unitary, the characters $\chi_k$ are its eigenvectors with $D\chi_k=g^{-k}\chi_k$, and every character line is isotropic except $k=0,(\p-1)/2$ with eigenvalues $\pm1=N^{1}\cap\mu_{\p-1}$. Exhaustive on $\F_{13}$, $\F_{17}$. -/
def p08040 := And.intro @FRC.Dirac.drive_chi (And.intro @FRC.Dirac.drive_sum (And.intro @FRC.Dirac.chi_isotropy (@FRC.Dirac.exceptional_eigen)))
set_option linter.defProp false in
/-- 8:F4 (p08041) — Two evolution sectors, one space: the split-phase sector of the drive and the norm-one sector of the Cayley propagators meet in $\{\pm1\}$ alone ($\operatorname{ord}(g^{-1})=\p-1$); the cycle Laplacian $\Delta_\Phi=D+D^{-1}-2I$ is self-adjoint, its Cayley steps commute with $D$ and the composite is unitary ($\p=13$); the dispersion relation $-\Delta_\Phi\chi_k=(2-g^{k}-g^{-k})\chi_k$; no meridional plane waves ($\gcd(\p,|K^{\times}|)=1$); $\mathcal D^{s}-m$ invertible for $m\ne0$, so mass is an evolution phase, not a kernel condition. -/
def p08041 := And.intro @FRC.Dirac.sector_separation (And.intro @FRC.Dirac.dispersion (@FRC.Dirac.exceptional_eigen))
-- end ledger predicates

end FRC.Dirac
