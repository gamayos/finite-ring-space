import Mathlib

/-!
# 6-fourier — the shell Fourier operator and its fractional family, for every shell (2026-09-15, extended 2026-09-17)

The shell Fourier matrix `W k j = g^(jk)` on `V = 𝔽_p^{Z_{p−1}}`, `g` a primitive root, the reversal `J`, and the
normalised operator `F = i W` with `i = −g^κ` (`i² = −1`): `W² = −J`, `F² = J`, `F⁴ = I`, `W J = J W` (predicates B5, B7).
The fractional family of the paper — the projectors `Π_ℓ = ¼ Σ_r i^{−ℓr} F^r`, the family `F^{[s]} = Σ_ℓ g^{−ℓs} Π_ℓ`
on `ZMod (4κ)` with its additivity, cardinal values, faithfulness and character sector (C2–C4, C8, C9, E6), the
multiplicities as traces and ranks with their parity sums and the dichotomy from the Gauss sign (C5, C7), the
parity permutation (D2), the rotation group `SO(2, 𝔽_p) ≃ 𝔽_p^×` with its cardinal values and eigenline (E2, E3),
the spectral obstruction (E5) and the shift–modulation covariance (E7) — proved for every prime shell `p = 4κ + 1`
and every primitive root, and where the algebra allows, for any element `f` with `f⁴ = 1` of any algebra over a
field with a quarter-turn. The paper's witness checks these on six shells. Classical (tier 2) on Mathlib's
hierarchy; predicates B2, B3, B5–B7 are also in the core with no axioms.
-/

namespace FRC.Fourier

open Matrix Finset

section base

variable {K : Type*} [Field K] {n : ℕ} [NeZero n]

omit [NeZero n] in
/-- The geometric sum of an `n`-th root of unity `ζ ≠ 1` over `Fin n` vanishes. -/
lemma sum_pow_eq_zero_of_ne_one {ζ : K} (hζn : ζ ^ n = 1) (hζ : ζ ≠ 1) :
    ∑ j : Fin n, ζ ^ (j : ℕ) = 0 := by
  have h := geom_sum_mul ζ n
  rw [hζn, sub_self] at h
  rw [Fin.sum_univ_eq_sum_range (fun j => ζ ^ j) n]
  exact (mul_eq_zero.1 h).resolve_right (sub_ne_zero.2 hζ)

/-- The shell Fourier matrix, `W k j = g^(j·k)`. -/
def W (g : K) : Matrix (Fin n) (Fin n) K := fun k j => g ^ ((j : ℕ) * (k : ℕ))

/-- The reversal `J k l = [l = −k]`. -/
def J : Matrix (Fin n) (Fin n) K := fun k l => if l = -k then 1 else 0

omit [NeZero n] in
lemma W_apply (g : K) (k j : Fin n) : (W g : Matrix (Fin n) (Fin n) K) k j = g ^ ((j : ℕ) * (k : ℕ)) := rfl
omit [NeZero n] in
lemma J_apply (k l : Fin n) : (J : Matrix (Fin n) (Fin n) K) k l = if l = -k then 1 else 0 := rfl

/-- `g^((-j).val) = (g^(j.val))⁻¹` for an `n`-th root of unity `g`. -/
lemma pow_neg_val {g : K} (hg : g ^ n = 1) (j : Fin n) :
    g ^ ((-j : Fin n) : ℕ) = (g ^ (j : ℕ))⁻¹ := by
  have hne : g ≠ 0 := by rintro rfl; simp [NeZero.ne n] at hg
  apply eq_inv_of_mul_eq_one_left
  rw [← pow_add]
  have hdvd : n ∣ ((-j : Fin n) : ℕ) + (j : ℕ) := by
    have h : (-j : Fin n) + j = 0 := neg_add_cancel j
    have := congrArg Fin.val h
    rw [Fin.val_add, Fin.val_zero] at this
    exact Nat.dvd_of_mod_eq_zero this
  obtain ⟨c, hc⟩ := hdvd
  rw [hc, pow_mul, hg, one_pow]

omit [NeZero n] in
/-- `J² = 1`. -/
theorem J_sq : (J : Matrix (Fin n) (Fin n) K) ^ 2 = 1 := by
  ext k l
  rw [sq, Matrix.mul_apply, Matrix.one_apply]
  simp only [J_apply, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_eq_single (-k)]
  · simp [neg_neg, eq_comm]
  · intro x _ hx; simp [hx]
  · intro h; exact absurd (Finset.mem_univ _) h

omit [NeZero n] in
/-- 6:D2 — `J` is a permutation matrix: `(M J) k j = M k (−j)`, so `M J` has the columns of `M`, reindexed by
the parity involution `j ↦ −j`. -/
theorem mul_J_apply (M : Matrix (Fin n) (Fin n) K) (k j : Fin n) :
    (M * (J : Matrix (Fin n) (Fin n) K)) k j = M k (-j) := by
  rw [Matrix.mul_apply]
  simp only [J_apply, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_eq_single (-j)]
  · simp
  · intro l _ hl
    have : ¬ (j = -l) := by rintro rfl; exact hl (neg_neg l).symm
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- `W² = n • J` for any primitive `n`-th root of unity `g` (the general identity). -/
theorem W_sq (g : K) (hg : IsPrimitiveRoot g n) :
    (W g : Matrix (Fin n) (Fin n) K) ^ 2 = (n : K) • J := by
  ext k l
  rw [sq, Matrix.mul_apply, Matrix.smul_apply, J_apply]
  simp only [W_apply]
  have hrw : ∀ j : Fin n, g ^ ((j : ℕ) * (k : ℕ)) * g ^ ((l : ℕ) * (j : ℕ))
      = (g ^ ((k : ℕ) + (l : ℕ))) ^ (j : ℕ) := by
    intro j; rw [← pow_add, ← pow_mul]; congr 1; ring
  simp_rw [hrw]
  have hdvd_iff : n ∣ (k : ℕ) + (l : ℕ) ↔ l = -k := by
    constructor
    · intro hd
      rw [eq_neg_iff_add_eq_zero, add_comm]
      apply Fin.ext
      rw [Fin.val_add, Fin.val_zero]
      exact Nat.mod_eq_zero_of_dvd hd
    · intro hl
      have h : k + l = 0 := by rw [hl, add_neg_cancel]
      have := congrArg Fin.val h
      rw [Fin.val_add, Fin.val_zero] at this
      exact Nat.dvd_of_mod_eq_zero this
  by_cases hkl : l = -k
  · obtain ⟨c, hc⟩ := hdvd_iff.2 hkl
    rw [hc, pow_mul, hg.pow_eq_one, one_pow]
    simp [hkl]
  · have hne : g ^ ((k : ℕ) + (l : ℕ)) ≠ 1 := by
      intro h1
      exact hkl (hdvd_iff.1 (hg.dvd_of_pow_eq_one _ h1))
    have hpow : (g ^ ((k : ℕ) + (l : ℕ))) ^ n = 1 := by
      rw [← pow_mul, mul_comm, pow_mul, hg.pow_eq_one, one_pow]
    rw [sum_pow_eq_zero_of_ne_one hpow hne]
    simp [hkl]

/-- `W J = J W` for any `n`-th root of unity `g`. -/
theorem W_mul_J_comm (g : K) (hg : g ^ n = 1) :
    (W g : Matrix (Fin n) (Fin n) K) * J = J * W g := by
  ext k l
  rw [Matrix.mul_apply, Matrix.mul_apply]
  simp only [W_apply, J_apply, mul_ite, ite_mul, mul_one, mul_zero, one_mul, zero_mul]
  rw [Finset.sum_eq_single (-l), Finset.sum_eq_single (-k)]
  · simp only [neg_neg, ite_true]
    -- g^((-l)·k) = g^(l·(-k))
    have hl : (g ^ (l : ℕ)) ^ n = 1 := by rw [← pow_mul, mul_comm, pow_mul, hg, one_pow]
    rw [pow_mul, pow_mul, pow_neg_val hg l, inv_pow, pow_neg_val hl k]
  · intro x _ hx; simp [hx]
  · intro h; exact absurd (Finset.mem_univ _) h
  · intro x _ hx
    have : l ≠ -x := fun h => hx (by rw [h, neg_neg])
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

/-! ## The shell: a field with `p = 4κ + 1` elements, `g` a primitive root, `i = −g^κ` -/

end base

section shell

variable {F : Type*} [Field F] [Fintype F]

/-- `(card F − 1 : ℕ) = −1` in a finite field `F`. -/
lemma natCast_card_pred_eq_neg_one : ((Fintype.card F - 1 : ℕ) : F) = -1 := by
  have h2 : 1 ≤ Fintype.card F := Fintype.card_pos
  rw [Nat.cast_sub h2, FiniteField.cast_card_eq_zero, Nat.cast_one, zero_sub]

/-- The quarter-turn `i = −g^κ` squares to `−1` (`g^{2κ}` is a primitive square root of unity). -/
lemma quarter_turn_sq (κ : ℕ) (hκ : Fintype.card F = 4 * κ + 1) (g : F)
    (hg : IsPrimitiveRoot g (Fintype.card F - 1)) :
    (-(g ^ κ)) ^ 2 = -1 := by
  have hκ' : Fintype.card F - 1 = 4 * κ := by omega
  have hκpos : κ ≠ 0 := by
    intro h; subst h; have := Fintype.one_lt_card (α := F); omega
  have hsq : (-(g ^ κ)) ^ 2 = g ^ (2 * κ) := by ring
  rw [hsq]
  have h2 : IsPrimitiveRoot (g ^ (2 * κ)) 2 := by
    have hd : 2 * κ ∣ Fintype.card F - 1 := by rw [hκ']; exact ⟨2, by ring⟩
    have := hg.pow_of_dvd (show 2 * κ ≠ 0 by omega) hd
    have hq : (Fintype.card F - 1) / (2 * κ) = 2 := by
      rw [hκ', show 4 * κ = 2 * κ * 2 by ring]; exact Nat.mul_div_cancel_left _ (by omega)
    rwa [hq] at this
  exact h2.eq_neg_one_of_two_right

/-- 6:B5, 6:B7 — every shell: on a field with `p = 4κ + 1` elements, `n = p − 1`,
`g` a primitive root and `F = i • W`: `W² = −J`, `F² = J`, `F⁴ = 1`, `W J = J W`. -/
theorem shell_relations (κ : ℕ) (hκ : Fintype.card F = 4 * κ + 1) (g : F)
    (hg : IsPrimitiveRoot g (Fintype.card F - 1)) :
    haveI : NeZero (Fintype.card F - 1) := ⟨by have := Fintype.one_lt_card (α := F); omega⟩
    (W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) ^ 2 = -J ∧
    ((-(g ^ κ)) • W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) ^ 2 = J ∧
    ((-(g ^ κ)) • W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) ^ 4 = 1 ∧
    (W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) * J = J * W g := by
  have : NeZero (Fintype.card F - 1) := ⟨by have := Fintype.one_lt_card (α := F); omega⟩
  have hW : (W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) ^ 2 = -J := by
    rw [W_sq g hg, natCast_card_pred_eq_neg_one, neg_one_smul]
  have hi := quarter_turn_sq κ hκ g hg
  have hF : ((-(g ^ κ)) • W g : Matrix (Fin (Fintype.card F - 1)) (Fin (Fintype.card F - 1)) F) ^ 2
      = J := by
    rw [smul_pow, hW, hi, neg_one_smul, neg_neg]
  refine ⟨hW, hF, ?_, W_mul_J_comm g hg.pow_eq_one⟩
  rw [show (4 : ℕ) = 2 * 2 by norm_num, pow_mul, hF, J_sq]

/-- 6:B5, 6:B7 on the prime shell `𝔽_p = ZMod p`, an instance: the relations hold there for every prime
`p = 4κ + 1` and primitive root `g`. -/
theorem shell_relations_zmod (p κ : ℕ) [hp : Fact (Nat.Prime p)] (hκ : p = 4 * κ + 1)
    (g : ZMod p) (hg : IsPrimitiveRoot g (p - 1)) :
    haveI : NeZero (Fintype.card (ZMod p) - 1) :=
      ⟨by have := Fintype.one_lt_card (α := ZMod p); omega⟩
    ((-(g ^ κ)) • W g : Matrix (Fin (Fintype.card (ZMod p) - 1))
      (Fin (Fintype.card (ZMod p) - 1)) (ZMod p)) ^ 2 = J := by
  have hc : Fintype.card (ZMod p) = p := ZMod.card p
  exact (shell_relations κ (by rw [hc, hκ]) g (by rw [hc]; exact hg)).2.1

end shell


/-! ## The fractional family, the rotation group and the readout of the meridian cycle (predicates C2–C9, D2, E2–E7; 17 Sep 2026) -/


section characters

variable {K : Type*} [Field K]

/-- `χ x = i^(x.val)`: the character of `ZMod 4` with value `i` at `1`, for `i⁴ = 1`. -/
def chi (i : K) (x : ZMod 4) : K := i ^ x.val

lemma chi_zero (i : K) : chi i 0 = 1 := by simp [chi]

lemma chi_add (i : K) (hi : i ^ 4 = 1) (x y : ZMod 4) : chi i (x + y) = chi i x * chi i y := by
  unfold chi
  rw [ZMod.val_add, ← pow_add, pow_eq_pow_mod (x.val + y.val) hi]

lemma chi_mul_val (i : K) (hi : i ^ 4 = 1) (x y : ZMod 4) : chi i (x * y) = chi i x ^ y.val := by
  unfold chi
  rw [ZMod.val_mul, ← pow_mul, pow_eq_pow_mod (x.val * y.val) hi]

lemma chi_neg_add_self (i : K) (hi : i ^ 4 = 1) (x : ZMod 4) : chi i (-x) * chi i x = 1 := by
  rw [← chi_add i hi, neg_add_cancel, chi_zero]

/-- A quarter-turn `i² = −1` in characteristic `≠ 2` is a primitive fourth root of unity: `χ d ≠ 1` off `0`. -/
lemma chi_ne_one (i : K) (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (d : ZMod 4) (hd : d ≠ 0) : chi i d ≠ 1 := by
  have hne1 : i ≠ 1 := by
    rintro rfl; apply h2; linear_combination hi
  have hne2 : i ≠ -1 := by
    rintro rfl; apply h2; linear_combination hi
  fin_cases d
  · exact absurd rfl hd
  · show i ^ 1 ≠ 1; simpa using hne1
  · simp only [chi]; show i ^ 2 ≠ 1
    rw [hi]; intro h; apply h2; linear_combination -h
  · simp only [chi]; show i ^ 3 ≠ 1
    intro h; apply hne2
    have : i ^ 3 = -i := by linear_combination i * hi
    rw [this] at h; linear_combination -h

lemma chi_pow_four (i : K) (hi : i ^ 4 = 1) (d : ZMod 4) : chi i d ^ 4 = 1 := by
  unfold chi; rw [← pow_mul, mul_comm, pow_mul, hi, one_pow]

/-- Orthogonality of the characters of `ZMod 4`: `Σ_r χ(d r) = 4·[d = 0]`. -/
lemma sum_chi (i : K) (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (d : ZMod 4) :
    ∑ r : ZMod 4, chi i (d * r) = if d = 0 then 4 else 0 := by
  by_cases hd : d = 0
  · subst hd
    simp only [zero_mul, chi_zero, ite_true, Finset.sum_const, Finset.card_univ, ZMod.card]
    norm_num
  · simp only [hd, ite_false]
    have h := sum_pow_eq_zero_of_ne_one (n := 4) (chi_pow_four i hi d) (hne d hd)
    simp_rw [chi_mul_val i hi]
    exact h

end characters

section algebra

variable {K : Type*} [Field K] {A : Type*} [Ring A] [Algebra K A]

/-- `φ r = f^(r.val)` for `f⁴ = 1`: the powers of `f` indexed by `ZMod 4`. -/
def phi (f : A) (r : ZMod 4) : A := f ^ r.val

lemma phi_zero (f : A) : phi f 0 = 1 := by simp [phi]

lemma phi_one (f : A) : phi f 1 = f := by unfold phi; exact pow_one f

lemma phi_add (f : A) (hf : f ^ 4 = 1) (r t : ZMod 4) : phi f (r + t) = phi f r * phi f t := by
  unfold phi
  rw [ZMod.val_add, ← pow_add, pow_eq_pow_mod (r.val + t.val) hf]

/-- The projector `Π_ℓ = ¼ Σ_r i^{−ℓr} f^r` (eq. projector-def), for `f⁴ = 1`. -/
def proj (i : K) (f : A) (ℓ : ZMod 4) : A := (4⁻¹ : K) • ∑ r : ZMod 4, chi i (-(ℓ * r)) • phi f r

variable (i : K) (f : A)

/-- 6:C2 — `f Π_ℓ = i^ℓ Π_ℓ`: `Π_ℓ` projects on the `i^ℓ`-eigenspace of `f`. -/
theorem mul_proj (hi : i ^ 4 = 1) (hf : f ^ 4 = 1) (ℓ : ZMod 4) :
    f * proj i f ℓ = chi i ℓ • proj i f ℓ := by
  have key : f * ∑ r : ZMod 4, chi i (-(ℓ * r)) • phi f r
      = chi i ℓ • ∑ r : ZMod 4, chi i (-(ℓ * r)) • phi f r := by
    rw [Finset.mul_sum, Finset.smul_sum]
    have h1 : ∀ r : ZMod 4, f * (chi i (-(ℓ * r)) • phi f r) = chi i (-(ℓ * r)) • phi f (1 + r) := by
      intro r; rw [mul_smul_comm, phi_add f hf, phi_one]
    simp_rw [h1]
    refine Fintype.sum_equiv (Equiv.addLeft (1 : ZMod 4)) _ _ (fun r => ?_)
    simp only [Equiv.coe_addLeft]
    rw [smul_smul, ← chi_add i hi]
    congr 2; ring
  unfold proj
  rw [mul_smul_comm, key, smul_comm]

/-- 6:C2 — the projectors are pairwise orthogonal idempotents: `Π_ℓ Π_m = [ℓ = m] Π_ℓ`. -/
theorem proj_mul_proj (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (ℓ m : ZMod 4) :
    proj i f ℓ * proj i f m = if ℓ = m then proj i f ℓ else 0 := by
  unfold proj
  rw [smul_mul_smul_comm, Finset.sum_mul_sum]
  -- the double sum, reindexed by `t = r + r'`
  have h1 : ∀ r r' : ZMod 4, chi i (-(ℓ * r)) • phi f r * chi i (-(m * r')) • phi f r'
      = (chi i (-(ℓ * r)) * chi i (-(m * r'))) • phi f (r + r') := by
    intro r r'; rw [smul_mul_smul_comm, phi_add f hf]
  simp_rw [h1]
  have h2 : ∀ r : ZMod 4, ∑ r' : ZMod 4, (chi i (-(ℓ * r)) * chi i (-(m * r'))) • phi f (r + r')
      = ∑ t : ZMod 4, (chi i (-(m * t)) * chi i ((m - ℓ) * r)) • phi f t := by
    intro r
    refine Fintype.sum_equiv (Equiv.addLeft r) _ _ (fun r' => ?_)
    simp only [Equiv.coe_addLeft]
    congr 1
    rw [← chi_add i hi, ← chi_add i hi]
    congr 1; ring
  simp_rw [h2]
  rw [Finset.sum_comm]
  have h3 : ∀ t : ZMod 4, ∑ r : ZMod 4, (chi i (-(m * t)) * chi i ((m - ℓ) * r)) • phi f t
      = (chi i (-(m * t)) * (if m - ℓ = 0 then 4 else 0)) • phi f t := by
    intro t
    rw [← Finset.sum_smul, ← Finset.mul_sum, sum_chi i hi hne]
  simp_rw [h3]
  by_cases hlm : ℓ = m
  · subst hlm
    simp only [sub_self, ite_true]
    rw [Finset.smul_sum, Finset.smul_sum]
    refine Finset.sum_congr rfl (fun t _ => ?_)
    rw [smul_smul, smul_smul]; congr 1
    field_simp
  · have : m - ℓ ≠ 0 := sub_ne_zero.2 (Ne.symm hlm)
    simp [this, hlm]

/-- 6:C2 — the projectors sum to the identity. -/
theorem sum_proj (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0) :
    ∑ ℓ : ZMod 4, proj i f ℓ = 1 := by
  unfold proj
  rw [← Finset.smul_sum, Finset.sum_comm]
  have h1 : ∀ r : ZMod 4, ∑ ℓ : ZMod 4, chi i (-(ℓ * r)) • phi f r
      = (if -r = 0 then (4 : K) else 0) • phi f r := by
    intro r
    rw [← Finset.sum_smul, ← sum_chi i hi hne (-r)]
    congr 1
    refine Finset.sum_congr rfl (fun ℓ _ => ?_)
    congr 1; ring
  simp_rw [h1]
  rw [Finset.sum_eq_single 0]
  · rw [show (if -(0 : ZMod 4) = 0 then (4 : K) else 0) = 4 from by simp]
    rw [phi_zero, smul_smul, inv_mul_cancel₀ h4, one_smul]
  · intro r _ hr
    have : -r ≠ 0 := by rwa [neg_ne_zero]
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- `f^k Π_ℓ = (i^ℓ)^k Π_ℓ`. -/
theorem pow_mul_proj (hi : i ^ 4 = 1) (hf : f ^ 4 = 1) (ℓ : ZMod 4) (k : ℕ) :
    f ^ k * proj i f ℓ = chi i ℓ ^ k • proj i f ℓ := by
  induction k with
  | zero => simp
  | succ k ih => rw [pow_succ', mul_assoc, ih, mul_smul_comm, mul_proj i f hi hf, smul_smul, pow_succ]

/-- The spectral resolution of the powers: `f^k = Σ_ℓ (i^ℓ)^k Π_ℓ`. -/
theorem pow_eq_sum_proj (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (k : ℕ) :
    f ^ k = ∑ ℓ : ZMod 4, chi i ℓ ^ k • proj i f ℓ := by
  conv_lhs => rw [← mul_one (f ^ k), ← sum_proj i f hi hne h4, Finset.mul_sum]
  simp_rw [pow_mul_proj i f hi hf]

/-- The spectral resolution is unique: a family `Q` of eigen-elements, `f Q_m = i^m Q_m`, summing to `1`, is the
family of projectors, `Q_ℓ = Π_ℓ`. -/
theorem proj_eq_of_resolution (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (Q : ZMod 4 → A) (hQ : ∀ m, f * Q m = chi i m • Q m) (hsum : ∑ m : ZMod 4, Q m = 1) (ℓ : ZMod 4) :
    proj i f ℓ = Q ℓ := by
  have hpow : ∀ k : ℕ, f ^ k = ∑ m : ZMod 4, chi i m ^ k • Q m := by
    intro k
    induction k with
    | zero => simp [hsum]
    | succ k ih =>
      rw [pow_succ', ih, Finset.mul_sum]
      refine Finset.sum_congr rfl (fun m _ => ?_)
      rw [mul_smul_comm, hQ, smul_smul, pow_succ]
  unfold proj phi
  simp_rw [hpow]
  rw [Finset.smul_sum]
  simp_rw [Finset.smul_sum, smul_smul]
  rw [Finset.sum_comm]
  have h1 : ∀ m : ZMod 4, ∑ r : ZMod 4, (4⁻¹ * (chi i (-(ℓ * r)) * chi i m ^ r.val)) • Q m
      = (if m - ℓ = 0 then (1 : K) else 0) • Q m := by
    intro m
    rw [← Finset.sum_smul]
    congr 1
    have h2 : ∀ r : ZMod 4, chi i (-(ℓ * r)) * chi i m ^ r.val = chi i ((m - ℓ) * r) := by
      intro r
      rw [← chi_mul_val i hi, ← chi_add i hi]; congr 1; ring
    simp_rw [h2]
    rw [← Finset.mul_sum, sum_chi i hi hne]
    split_ifs
    · field_simp
    · simp
  simp_rw [h1]
  rw [Finset.sum_eq_single ℓ]
  · simp
  · intro m _ hm
    have : m - ℓ ≠ 0 := sub_ne_zero.2 hm
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- 6:C3 — `F^{[s]} Π_m = z^{m s} Π_m`, and `Π_m` commutes with the family (both are polynomials in `f`). -/
theorem chi_pow_three (hi2 : i ^ 2 = -1) (ℓ : ZMod 4) : chi i ℓ ^ 3 = chi (-i) ℓ := by
  unfold chi
  rw [← pow_mul, mul_comm, pow_mul]
  congr 1
  linear_combination i * hi2

/-- 6:C9 — the conjugate reframing `(g, i) ↦ (g⁻¹, −i)`: the quarter-turn transform of the conjugate frame is
`F' = −F⁻¹ = −F³`, and its projectors are the shifted projectors, `Π'_ℓ = Π_{ℓ+2}`. -/
theorem proj_conj (hi : i ^ 4 = 1) (hi2 : i ^ 2 = -1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1)
    (h4 : (4 : K) ≠ 0) (hf : f ^ 4 = 1) (ℓ : ZMod 4) :
    proj (-i) (-(f ^ 3)) ℓ = proj i f (ℓ + 2) := by
  have hi' : (-i) ^ 4 = 1 := by rw [neg_pow, hi]; norm_num
  have hne' : ∀ d : ZMod 4, d ≠ 0 → chi (-i) d ≠ 1 := by
    intro d hd
    have h2 : (2 : K) ≠ 0 := by
      intro h2; apply hne 2 (by decide)
      show i ^ 2 = 1
      rw [hi2]; linear_combination -h2
    exact chi_ne_one (-i) (by rw [neg_sq, hi2]) h2 d hd
  refine proj_eq_of_resolution (-i) (-(f ^ 3)) hi' hne' h4 (fun m => proj i f (m + 2)) ?_ ?_ ℓ
  · intro m
    rw [neg_mul, pow_mul_proj i f hi hf, ← chi_pow_three i hi2, chi_add i hi]
    have h2 : chi i 2 = -1 := by unfold chi; rw [show (2 : ZMod 4).val = 2 from rfl, hi2]
    rw [h2, ← neg_smul]
    congr 1
    ring
  · rw [← sum_proj i f hi hne h4]
    exact Fintype.sum_equiv (Equiv.addRight (2 : ZMod 4)) _ _ (fun m => by simp)


end algebra

section family

variable {K : Type*} [Field K] {A : Type*} [Ring A] [Algebra K A] {n : ℕ} [NeZero n]

/-- `ψ x = z^(x.val)`: the character of `ZMod n` with value `z` at `1`, for `zⁿ = 1`. -/
def psi (z : K) (x : ZMod n) : K := z ^ x.val

lemma psi_add (z : K) (hz : z ^ n = 1) (x y : ZMod n) : psi z (x + y) = psi z x * psi z y := by
  unfold psi
  rw [ZMod.val_add, ← pow_add, pow_eq_pow_mod (x.val + y.val) hz]

omit [NeZero n] in
lemma psi_zero (z : K) : psi z (0 : ZMod n) = 1 := by simp [psi]

lemma psi_nsmul (z : K) (hz : z ^ n = 1) (k : ℕ) (x : ZMod n) : psi z (k • x) = psi z x ^ k := by
  induction k with
  | zero => simp [psi_zero]
  | succ k ih => rw [succ_nsmul, psi_add z hz, ih, pow_succ]

/-- The FRC-native fractional family `F^{[s]} = Σ_ℓ z^{ℓ s} Π_ℓ` (eq. FRC-FrFT-def), `z = g⁻¹` the
refinement base, `s ∈ ZMod n`, `n = 4κ`. -/
def frft (i z : K) (f : A) (s : ZMod n) : A := ∑ ℓ : ZMod 4, psi z (ℓ.val • s) • proj i f ℓ

variable (i z : K) (f : A)

/-- 6:C3 — additivity: `F^{[s+r]} = F^{[s]} F^{[r]}`, a representation of `ZMod n`. -/
theorem frft_add (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (hz : z ^ n = 1) (s r : ZMod n) :
    frft i z f (s + r) = frft i z f s * frft i z f r := by
  unfold frft
  rw [Finset.sum_mul_sum]
  have h1 : ∀ ℓ m : ZMod 4, psi z (ℓ.val • s) • proj i f ℓ * psi z (m.val • r) • proj i f m
      = if ℓ = m then (psi z (ℓ.val • s) * psi z (m.val • r)) • proj i f ℓ else 0 := by
    intro ℓ m
    rw [smul_mul_smul_comm, proj_mul_proj i f hi hne h4 hf]
    split_ifs <;> simp
  simp_rw [h1, Finset.sum_ite_eq, Finset.mem_univ, ite_true]
  refine Finset.sum_congr rfl (fun ℓ _ => ?_)
  rw [smul_add, psi_add z hz]

omit [NeZero n] in
/-- 6:C3 — the family at `0` is the identity. -/
theorem frft_zero (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0) :
    frft i z f (0 : ZMod n) = 1 := by
  unfold frft
  simp only [smul_zero, psi_zero, one_smul]
  exact sum_proj i f hi hne h4

/-- 6:C3 — `F^{[k s]} = (F^{[s]})^k`; in particular `(F^{[1]})^κ = F^{[κ]}`. -/
theorem frft_nsmul (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (hz : z ^ n = 1) (k : ℕ) (s : ZMod n) :
    frft i z f (k • s) = frft i z f s ^ k := by
  induction k with
  | zero => rw [zero_smul, pow_zero]; exact frft_zero i z f hi hne h4
  | succ k ih => rw [succ_nsmul, frft_add i z f hi hne h4 hf hz, ih, pow_succ]

/-- 6:C3 — the cardinal values: with `z^κ = i` (the quarter-turn is the `κ`-th power of the
refinement base), `F^{[m κ]} = f^m` for every `m`: `F^{[0]} = 1`, `F^{[κ]} = f`, `F^{[2κ]} = f² = J`,
`F^{[3κ]} = f³ = f⁻¹`, `F^{[4κ]} = 1`. -/
theorem frft_cardinal (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (hz : z ^ n = 1) (κ : ℕ) (hκ : z ^ κ = i) (m : ℕ) :
    frft i z f (m • (κ : ZMod n)) = f ^ m := by
  rw [pow_eq_sum_proj i f hi hne h4 hf m]
  unfold frft
  refine Finset.sum_congr rfl (fun ℓ _ => ?_)
  congr 1
  rw [smul_comm, psi_nsmul z hz]
  congr 1
  unfold psi chi
  rw [nsmul_eq_mul, ← Nat.cast_mul, ZMod.val_natCast, ← pow_eq_pow_mod _ hz, mul_comm ℓ.val κ, pow_mul, hκ]

/-- 6:C4 — faithfulness: if some projector `Π_m` with `m` coprime to `n` is nonzero and `z` is a
primitive `n`-th root of unity, `s ↦ F^{[s]}` is injective on `ZMod n`. -/
theorem frft_injective [NoZeroSMulDivisors K A] (hi : i ^ 4 = 1)
    (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0) (hf : f ^ 4 = 1)
    (hz : IsPrimitiveRoot z n) (m : ZMod 4) (hm : proj i f m ≠ 0) (hcop : Nat.Coprime m.val n) :
    Function.Injective (frft i z f : ZMod n → A) := by
  intro s r hsr
  have key : ∀ t : ZMod n, frft i z f t * proj i f m = psi z (m.val • t) • proj i f m := by
    intro t
    unfold frft
    rw [Finset.sum_mul]
    have h1 : ∀ ℓ : ZMod 4, psi z (ℓ.val • t) • proj i f ℓ * proj i f m
        = if ℓ = m then psi z (ℓ.val • t) • proj i f ℓ else 0 := by
      intro ℓ; rw [smul_mul_assoc, proj_mul_proj i f hi hne h4 hf]; split_ifs <;> simp
    simp_rw [h1, Finset.sum_ite_eq', Finset.mem_univ, ite_true]
  have h : frft i z f s * proj i f m = frft i z f r * proj i f m := by rw [hsr]
  rw [key, key] at h
  have h' : (psi z (m.val • s) - psi z (m.val • r)) • proj i f m = 0 := by
    rw [sub_smul, h, sub_self]
  rcases smul_eq_zero.1 h' with h'' | h''
  · have hv : psi z (m.val • s) = psi z (m.val • r) := sub_eq_zero.1 h''
    unfold psi at hv
    have hval := hz.pow_inj (ZMod.val_lt _) (ZMod.val_lt _) hv
    have hsm : (m.val • s : ZMod n) = m.val • r := ZMod.val_injective n hval
    have hu : IsUnit ((m.val : ℕ) : ZMod n) := (ZMod.unitOfCoprime m.val hcop).isUnit
    rw [nsmul_eq_mul, nsmul_eq_mul] at hsm
    exact hu.mul_left_cancel hsm
  · exact absurd h'' hm

omit [NeZero n] in
/-- 6:E6 — the character sector: on `im Π_1` the family acts by the meridian character,
`F^{[s]} Π_1 = z^{s} Π_1`; the intertwiner `F^{[s]} (x Π_1 v) = Π_1 ((z^s x) v)` is linearity. -/
theorem frft_mul_proj_one (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (s : ZMod n) :
    frft i z f s * proj i f 1 = psi z s • proj i f 1 := by
  unfold frft
  rw [Finset.sum_mul]
  have h1 : ∀ ℓ : ZMod 4, psi z (ℓ.val • s) • proj i f ℓ * proj i f 1
      = if ℓ = 1 then psi z (ℓ.val • s) • proj i f ℓ else 0 := by
    intro ℓ; rw [smul_mul_assoc, proj_mul_proj i f hi hne h4 hf]; split_ifs <;> simp
  simp_rw [h1, Finset.sum_ite_eq', Finset.mem_univ, ite_true]
  rw [show ((1 : ZMod 4)).val = 1 from rfl, one_nsmul]

/-- 6:C8 — an exponent lift `a : ZMod 4 → ℕ` gives the family `U^{(a)}_s = Σ_ℓ z^{a_ℓ s} Π_ℓ` (Rem. classification);
the principal lift is `a ℓ = ℓ`. -/
def frftLift (i z : K) (f : A) (a : ZMod 4 → ℕ) (s : ZMod n) : A :=
  ∑ ℓ : ZMod 4, psi z (a ℓ • s) • proj i f ℓ

omit [NeZero n] in
theorem frft_eq_frftLift (s : ZMod n) : frft i z f s = frftLift i z f (fun ℓ => ℓ.val) s := rfl

/-- 6:C8 — every exponent lift is additive, with the same group law as the principal one. -/
theorem frftLift_add (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (hz : z ^ n = 1) (a : ZMod 4 → ℕ) (s r : ZMod n) :
    frftLift i z f a (s + r) = frftLift i z f a s * frftLift i z f a r := by
  unfold frftLift
  rw [Finset.sum_mul_sum]
  have h1 : ∀ ℓ m : ZMod 4, psi z (a ℓ • s) • proj i f ℓ * psi z (a m • r) • proj i f m
      = if ℓ = m then (psi z (a ℓ • s) * psi z (a m • r)) • proj i f ℓ else 0 := by
    intro ℓ m
    rw [smul_mul_smul_comm, proj_mul_proj i f hi hne h4 hf]
    split_ifs <;> simp
  simp_rw [h1, Finset.sum_ite_eq, Finset.mem_univ, ite_true]
  refine Finset.sum_congr rfl (fun ℓ _ => ?_)
  rw [smul_add, psi_add z hz]

/-- 6:C8 — every exponent lift with `a_ℓ ≡ ℓ (mod 4)` has the cardinal skeleton of the principal lift:
`U^{(a)}_{mκ} = f^m`. -/
theorem frftLift_cardinal (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (hz : z ^ n = 1) (κ : ℕ) (hκ : z ^ κ = i) (a : ZMod 4 → ℕ)
    (ha : ∀ ℓ, a ℓ % 4 = ℓ.val) (m : ℕ) :
    frftLift i z f a (m • (κ : ZMod n)) = f ^ m := by
  rw [pow_eq_sum_proj i f hi hne h4 hf m]
  unfold frftLift
  refine Finset.sum_congr rfl (fun ℓ _ => ?_)
  congr 1
  rw [smul_comm, psi_nsmul z hz]
  congr 1
  unfold psi chi
  rw [nsmul_eq_mul, ← Nat.cast_mul, ZMod.val_natCast, ← pow_eq_pow_mod _ hz, mul_comm (a ℓ) κ, pow_mul, hκ,
    pow_eq_pow_mod (a ℓ) hi, ha ℓ]

omit [NeZero n] in
/-- 6:C3 — `F^{[s]} Π_m = z^{m s} Π_m` for every `m`. -/
theorem frft_mul_proj (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (s : ZMod n) (m : ZMod 4) :
    frft i z f s * proj i f m = psi z (m.val • s) • proj i f m := by
  unfold frft
  rw [Finset.sum_mul]
  have h1 : ∀ ℓ : ZMod 4, psi z (ℓ.val • s) • proj i f ℓ * proj i f m
      = if ℓ = m then psi z (ℓ.val • s) • proj i f ℓ else 0 := by
    intro ℓ; rw [smul_mul_assoc, proj_mul_proj i f hi hne h4 hf]; split_ifs <;> simp
  simp_rw [h1, Finset.sum_ite_eq', Finset.mem_univ, ite_true]

omit [NeZero n] in
/-- `Π_m F^{[s]} = z^{m s} Π_m`: the projectors commute with the family. -/
theorem proj_mul_frft (hi : i ^ 4 = 1) (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0)
    (hf : f ^ 4 = 1) (s : ZMod n) (m : ZMod 4) :
    proj i f m * frft i z f s = psi z (m.val • s) • proj i f m := by
  unfold frft
  rw [Finset.mul_sum]
  have h1 : ∀ ℓ : ZMod 4, proj i f m * psi z (ℓ.val • s) • proj i f ℓ
      = if m = ℓ then psi z (ℓ.val • s) • proj i f m else 0 := by
    intro ℓ; rw [mul_smul_comm, proj_mul_proj i f hi hne h4 hf]; split_ifs <;> simp
  simp_rw [h1, Finset.sum_ite_eq, Finset.mem_univ, ite_true]


end family

section rotation

variable {K : Type*} [Field K]

/-- `c = (z + z⁻¹)/2` and `d = (z − z⁻¹)/(2i)` (eq. csds-def), `z = g^{−s}`. -/
def cc (z : K) : K := (z + z⁻¹) / 2
def dd (i z : K) : K := (z - z⁻¹) / (2 * i)

/-- The rotation `R_s = [[c, −d], [d, c]]` (eq. Rs-def). -/
def rot (i z : K) : Matrix (Fin 2) (Fin 2) K := !![cc z, -dd i z; dd i z, cc z]

variable (i : K)

lemma quarter_turn_ne_zero (hi : i ^ 2 = -1) : i ≠ 0 := by rintro rfl; norm_num at hi

lemma inv_quarter_turn (hi : i ^ 2 = -1) : i⁻¹ = -i := by
  have hi0 := quarter_turn_ne_zero i hi
  field_simp
  linear_combination hi

/-- 6:E2 — `R_s ∈ SO(2)`: `c² + d² = 1` for `z ≠ 0`, so `det R_s = 1` and `R_sᵀ R_s = 1`. -/
theorem circle (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z : K) (hz : z ≠ 0) : cc z ^ 2 + dd i z ^ 2 = 1 := by
  have hi0 := quarter_turn_ne_zero i hi
  unfold cc dd
  field_simp
  linear_combination (z ^ 2 - 1) ^ 2 * hi

/-- 6:E2 — `det R_s = 1`. -/
theorem rot_det (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z : K) (hz : z ≠ 0) : (rot i z).det = 1 := by
  rw [rot, Matrix.det_fin_two_of]
  linear_combination circle i hi h2 z hz

/-- 6:E2 — `R_sᵀ R_s = 1`: the rotation is orthogonal. -/
theorem rot_transpose_mul (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z : K) (hz : z ≠ 0) :
    Matrix.transpose (rot i z) * rot i z = 1 := by
  have h := circle i hi h2 z hz
  have ht : Matrix.transpose (rot i z) = !![cc z, dd i z; -dd i z, cc z] := by
    ext a b; fin_cases a <;> fin_cases b <;> rfl
  rw [ht, rot, Matrix.mul_fin_two, Matrix.one_fin_two]
  congr 1
  funext a b
  fin_cases a <;> fin_cases b <;> simp <;> first | linear_combination h | ring

/-- The angle-addition identities: `c_{zw} = c_z c_w − d_z d_w`, `d_{zw} = d_z c_w + c_z d_w`. -/
lemma cc_mul (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z w : K) (hz : z ≠ 0) (hw : w ≠ 0) :
    cc (z * w) = cc z * cc w - dd i z * dd i w := by
  have hi0 := quarter_turn_ne_zero i hi
  unfold cc dd
  field_simp
  linear_combination (z ^ 2 - 1) * (w ^ 2 - 1) * hi

lemma dd_mul (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z w : K) (hz : z ≠ 0) (hw : w ≠ 0) :
    dd i (z * w) = dd i z * cc w + cc z * dd i w := by
  have hi0 := quarter_turn_ne_zero i hi
  unfold cc dd
  field_simp
  ring

/-- 6:E2 — `s ↦ R_s` is a homomorphism of the meridian cycle: `R_{s+r} = R_s R_r` reads
`rot (z w) = rot z * rot w` for `z = g^{−s}`, `w = g^{−r}`. -/
theorem rot_mul (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z w : K) (hz : z ≠ 0) (hw : w ≠ 0) :
    rot i (z * w) = rot i z * rot i w := by
  have hc := cc_mul i hi h2 z w hz hw
  have hd := dd_mul i hi h2 z w hz hw
  ext a b
  fin_cases a <;> fin_cases b <;> simp [rot, Matrix.mul_apply, Fin.sum_univ_two, hc, hd] <;> ring

/-- 6:E3 — the cardinal values: `R_0 = 1` (`z = 1`), `R_κ = w = [[0, −1], [1, 0]]` (`z = i`),
`R_{2κ} = −1` (`z = −1`), `R_{3κ} = w⁻¹` (`z = −i`). -/
theorem rot_cardinal (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) :
    rot i 1 = 1 ∧ rot i i = !![0, -1; 1, 0] ∧ rot i (-1) = -1 ∧ rot i (-i) = !![0, 1; -1, 0] := by
  have hi0 := quarter_turn_ne_zero i hi
  have hinv := inv_quarter_turn i hi
  have hc1 : cc (1 : K) = 1 := by unfold cc; rw [inv_one]; field_simp; ring
  have hd1 : dd i 1 = 0 := by unfold dd; simp
  have hci : cc i = 0 := by unfold cc; rw [hinv]; ring
  have hdi : dd i i = 1 := by unfold dd; rw [hinv]; field_simp; ring
  have hcm : cc (-1 : K) = -1 := by unfold cc; rw [inv_neg, inv_one]; field_simp; ring
  have hdm : dd i (-1) = 0 := by unfold dd; simp
  have hcmi : cc (-i) = 0 := by unfold cc; rw [inv_neg, hinv]; ring
  have hdmi : dd i (-i) = -1 := by unfold dd; rw [inv_neg, hinv]; field_simp; ring
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [rot, hc1, hd1]; ext a b; fin_cases a <;> fin_cases b <;> simp
  · rw [rot, hci, hdi]
  · rw [rot, hcm, hdm]; ext a b; fin_cases a <;> fin_cases b <;> simp
  · rw [rot, hcmi, hdmi]; simp

/-- 6:E6 — the eigenline: `R_s (1, −i)ᵀ = z (1, −i)ᵀ`, the same character `z = g^{−s}` (Prop. charsector). -/
theorem rot_eigenline (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) (z : K) (hz : z ≠ 0) :
    (rot i z).mulVec ![1, -i] = z • ![1, -i] := by
  have hi0 := quarter_turn_ne_zero i hi
  have h1 : cc z + i * dd i z = z := by
    unfold cc dd; field_simp; ring
  have h2' : dd i z - i * cc z = -i * z := by
    unfold cc dd; field_simp; linear_combination (z ^ 2 - 1) * hi
  ext a
  fin_cases a <;> simp [rot, Matrix.mulVec, dotProduct, Fin.sum_univ_two]
  · linear_combination h1
  · linear_combination h2'

/-- The circle `c² + d² = 1` of the plane over `K`. -/
abbrev Circle (K : Type*) [Field K] := {x : K × K // x.1 ^ 2 + x.2 ^ 2 = 1}

/-- 6:E2 — the circle is the unit group: `u ↦ (c_u, d_u)` with inverse `(c, d) ↦ c + i d`, so
`SO(2, K) ≃ K^×` when `K` has a quarter-turn. -/
def unitsEquivCircle (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) : Kˣ ≃ Circle K where
  toFun u := ⟨(cc (u : K), dd i u), circle i hi h2 u u.ne_zero⟩
  invFun x := Units.mk (x.1.1 + i * x.1.2) (x.1.1 - i * x.1.2)
    (by linear_combination x.2 - x.1.2 ^ 2 * hi) (by linear_combination x.2 - x.1.2 ^ 2 * hi)
  left_inv u := by
    have hi0 := quarter_turn_ne_zero i hi
    have hu := u.ne_zero
    ext
    show cc (u : K) + i * dd i u = u
    unfold cc dd; field_simp; ring
  right_inv x := by
    have hi0 := quarter_turn_ne_zero i hi
    obtain ⟨⟨c, d⟩, hx⟩ := x
    have hx' : c ^ 2 + d ^ 2 = 1 := hx
    have hmul : (c + i * d) * (c - i * d) = 1 := by linear_combination hx' - d ^ 2 * hi
    have hinv : (c + i * d)⁻¹ = c - i * d := inv_eq_of_mul_eq_one_right hmul
    apply Subtype.ext
    show (cc (c + i * d), dd i (c + i * d)) = (c, d)
    unfold cc dd
    rw [hinv]
    refine Prod.ext ?_ ?_
    · show (c + i * d + (c - i * d)) / 2 = c
      field_simp; ring
    · show (c + i * d - (c - i * d)) / (2 * i) = d
      field_simp; ring

/-- 6:E2 — `|SO(2, K)| = |K| − 1` for a finite field with a quarter-turn: the rotation group of the
`p²`-point plane has `p − 1 = 4κ` elements, the size of the meridian cycle. -/
theorem card_circle [Fintype K] [DecidableEq K] (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0) :
    Fintype.card (Circle K) = Fintype.card K - 1 := by
  rw [← Fintype.card_units, Fintype.card_congr (unitsEquivCircle i hi h2).symm]


end rotation


/-! ## The Gauss sum of the frame (6:C7): `G G* = −2` in the field, and the conjugate sign -/

section gauss

variable {K : Type*} [Field K] {n : ℕ} [NeZero n]

/-- `ψ x = g^(x.val)` on `Fin n`, for `gⁿ = 1`. -/
def psiF (g : K) (x : Fin n) : K := g ^ (x : ℕ)

lemma psiF_zero (g : K) : psiF g (0 : Fin n) = 1 := by simp [psiF]

omit [NeZero n] in
lemma psiF_add {g : K} (hg : g ^ n = 1) (x y : Fin n) : psiF g (x + y) = psiF g x * psiF g y := by
  unfold psiF; rw [Fin.val_add, ← pow_add, pow_eq_pow_mod ((x : ℕ) + y) hg]

omit [NeZero n] in
lemma psiF_mul_val {g : K} (hg : g ^ n = 1) (x y : Fin n) : psiF g (x * y) = psiF g x ^ (y : ℕ) := by
  unfold psiF; rw [Fin.val_mul, ← pow_mul, pow_eq_pow_mod ((x : ℕ) * y) hg]

lemma psiF_neg_mul_self {g : K} (hg : g ^ n = 1) (x : Fin n) : psiF g (-x) * psiF g x = 1 := by
  rw [← psiF_add hg, neg_add_cancel, psiF_zero]

omit [NeZero n] in
lemma psiF_pow_n {g : K} (hg : g ^ n = 1) (x : Fin n) : psiF g x ^ n = 1 := by
  unfold psiF; rw [← pow_mul, mul_comm, pow_mul, hg, one_pow]

/-- The frame's exponent-cycle Gauss sum `G = Σ_k g^{k²}` (Thm. multiplicity); `G(g⁻¹) = Σ_k g^{−k²}` is `G*`. -/
def gauss (n : ℕ) (g : K) : K := ∑ k : Fin n, g ^ ((k : ℕ) * (k : ℕ))

omit [NeZero n] in
lemma gauss_eq {g : K} (hg : g ^ n = 1) : gauss n g = ∑ k : Fin n, psiF g (k * k) := by
  unfold gauss psiF
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [Fin.val_mul, pow_eq_pow_mod ((k : ℕ) * k) hg]

lemma gauss_inv_eq {g : K} (hg : g ^ n = 1) : gauss n g⁻¹ = ∑ k : Fin n, psiF g (-(k * k)) := by
  unfold gauss
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [inv_pow]
  apply inv_eq_of_mul_eq_one_right
  have h := psiF_neg_mul_self hg (k * k)
  unfold psiF at h ⊢
  rw [mul_comm] at h
  rw [pow_eq_pow_mod ((k : ℕ) * k) hg, ← Fin.val_mul]
  exact h

/-- `2d = 0` in `Fin (4κ)` exactly for `d ∈ {0, 2κ}`. -/
lemma two_mul_eq_zero_iff (κ : ℕ) [NeZero κ] (d : Fin (4 * κ)) :
    d + d = 0 ↔ d = 0 ∨ d = ⟨2 * κ, by have := NeZero.ne κ; omega⟩ := by
  have hd := d.isLt
  constructor
  · intro h
    have h' : ((d : ℕ) + d) % (4 * κ) = 0 := by rw [← Fin.val_add, h, Fin.val_zero]
    obtain ⟨c, hc⟩ := Nat.dvd_of_mod_eq_zero h'
    have hc2 : c < 2 := by
      by_contra hcon
      have : 4 * κ * 2 ≤ 4 * κ * c := Nat.mul_le_mul_left _ (not_lt.1 hcon)
      omega
    interval_cases c
    · left; exact Fin.ext (by show (d : ℕ) = 0; omega)
    · right; exact Fin.ext (by show (d : ℕ) = 2 * κ; omega)
  · rintro (rfl | rfl)
    · simp
    · exact Fin.ext (by
        rw [Fin.val_add]
        show (2 * κ + 2 * κ) % (4 * κ) = 0
        rw [show 2 * κ + 2 * κ = 4 * κ by ring, Nat.mod_self])

open Fin.CommRing in
/-- 6:C7 — `G G* = −2` in the field: `Σ_{k,l} g^{k²−l²} = Σ_d g^{d²} Σ_l g^{2ld}`, the inner geometric sum vanishing
unless `2d = 0`, i.e. `d ∈ {0, 2κ}`, where it is `n ≡ −1`. -/
theorem gauss_mul_gauss_inv (κ : ℕ) [NeZero κ] (g : K) (hg : IsPrimitiveRoot g (4 * κ))
    (hnK : ((4 * κ : ℕ) : K) = -1) : gauss (4 * κ) g * gauss (4 * κ) g⁻¹ = -2 := by
  have hg1 := hg.pow_eq_one
  rw [gauss_eq hg1, gauss_inv_eq hg1, Finset.sum_mul_sum]
  simp_rw [← psiF_add hg1]
  rw [Finset.sum_comm]
  have h1 : ∀ l : Fin (4 * κ), ∑ k : Fin (4 * κ), psiF g (k * k + -(l * l))
      = ∑ d : Fin (4 * κ), psiF g (d * d) * psiF g (d + d) ^ (l : ℕ) := by
    intro l
    symm
    refine Fintype.sum_equiv (Equiv.addLeft l) _ _ (fun d => ?_)
    simp only [Equiv.coe_addLeft]
    rw [← psiF_mul_val hg1, ← psiF_add hg1]
    congr 1; ring
  simp_rw [h1]
  rw [Finset.sum_comm]
  have h2 : ∀ d : Fin (4 * κ), ∑ l : Fin (4 * κ), psiF g (d * d) * psiF g (d + d) ^ (l : ℕ)
      = psiF g (d * d) * (if d + d = 0 then ((4 * κ : ℕ) : K) else 0) := by
    intro d
    rw [← Finset.mul_sum]
    congr 1
    by_cases hd : d + d = 0
    · simp only [hd, ite_true, psiF_zero]
      simp
    · simp only [hd, ite_false]
      apply sum_pow_eq_zero_of_ne_one (psiF_pow_n hg1 _)
      intro h1
      apply hd
      unfold psiF at h1
      rw [hg.pow_eq_one_iff_dvd] at h1
      exact Fin.ext (Nat.eq_zero_of_dvd_of_lt h1 (d + d).isLt)
  simp_rw [h2]
  rw [← Finset.sum_filter_add_sum_filter_not Finset.univ (fun d : Fin (4 * κ) => d + d = 0)]
  have h3 : ∑ d ∈ Finset.univ.filter (fun d : Fin (4 * κ) => ¬ (d + d = 0)),
      psiF g (d * d) * (if d + d = 0 then ((4 * κ : ℕ) : K) else 0) = 0 := by
    apply Finset.sum_eq_zero
    intro d hd
    rw [Finset.mem_filter] at hd
    simp only [hd.2, ite_false, mul_zero]
  rw [h3, add_zero]
  have hset : Finset.univ.filter (fun d : Fin (4 * κ) => d + d = 0)
      = {0, ⟨2 * κ, by have := NeZero.ne κ; omega⟩} := by
    ext d
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Finset.mem_singleton]
    exact two_mul_eq_zero_iff κ d
  rw [hset, Finset.sum_pair (by simp [Fin.ext_iff]; have := NeZero.ne κ; omega)]
  have hm : (⟨2 * κ, by have := NeZero.ne κ; omega⟩ : Fin (4 * κ)) * ⟨2 * κ, by have := NeZero.ne κ; omega⟩ = 0 := by
    rw [Fin.ext_iff, Fin.val_mul]
    show (2 * κ * (2 * κ)) % (4 * κ) = 0
    rw [show 2 * κ * (2 * κ) = 4 * κ * κ by ring, Nat.mul_mod_right]
  have hmm : (⟨2 * κ, by have := NeZero.ne κ; omega⟩ : Fin (4 * κ)) + ⟨2 * κ, by have := NeZero.ne κ; omega⟩ = 0 := by
    rw [Fin.ext_iff, Fin.val_add]
    show (2 * κ + 2 * κ) % (4 * κ) = 0
    rw [show 2 * κ + 2 * κ = 4 * κ by ring, Nat.mod_self]
  rw [hm, hmm, zero_mul, zero_add, psiF_zero, hnK]
  simp only [ite_true]
  ring

omit [NeZero n] in
/-- 6:C7 — the conjugate frame's sign: with `G = ε(1 + i)`, `ε = ±1`, the conjugate Gauss sum is
`G* = G(g⁻¹) = −ε(1 + i')` for the conjugate quarter-turn `i' = −i`, so `ε(g⁻¹) = −ε(g)`. -/
theorem gauss_inv_of_sign {g i : K} (hGG : gauss n g * gauss n g⁻¹ = -2) (hi : i ^ 2 = -1) (h2 : (2 : K) ≠ 0)
    (ε : K) (hε : ε = 1 ∨ ε = -1) (hG : gauss n g = ε * (1 + i)) : gauss n g⁻¹ = -ε * (1 + -i) := by
  have hε2 : ε ^ 2 = 1 := by rcases hε with rfl | rfl <;> norm_num
  have key : gauss n g⁻¹ * (ε * (1 + i)) = -2 := by rw [← hG, mul_comm]; exact hGG
  have h3 : 2 * gauss n g⁻¹ = 2 * (-ε * (1 + -i)) := by
    linear_combination (ε * (1 - i)) * key + gauss n g⁻¹ * hi - (gauss n g⁻¹ * (1 - i ^ 2)) * hε2
  exact mul_left_cancel₀ h2 h3

end gauss

/-! ## The shift and the modulation (6:E7), and the eigenvalues of the family (6:E5) -/

section shift

variable {K : Type*} [Field K] {n : ℕ} [NeZero n]

/-- The cyclic shift `σ`, `(σ v)_k = v_{k−1}`: `σ k j = [k = j + 1]`. -/
def shift : Matrix (Fin n) (Fin n) K := Matrix.of fun k j => if k = j + 1 then 1 else 0

/-- The inverse shift `σ⁻¹ k j = [j = k + 1]`, `(σ⁻¹ v)_k = v_{k+1}`. -/
def shift' : Matrix (Fin n) (Fin n) K := Matrix.of fun k j => if j = k + 1 then 1 else 0

/-- The modulation `D_1 = diag(g^k)`. -/
def modul (g : K) : Matrix (Fin n) (Fin n) K := Matrix.diagonal fun k => g ^ (k : ℕ)

lemma shift_apply (k j : Fin n) : (shift : Matrix (Fin n) (Fin n) K) k j = if k = j + 1 then 1 else 0 := rfl
lemma shift'_apply (k j : Fin n) : (shift' : Matrix (Fin n) (Fin n) K) k j = if j = k + 1 then 1 else 0 := rfl

/-- `σ σ⁻¹ = 1`. -/
theorem shift_mul_shift' : (shift : Matrix (Fin n) (Fin n) K) * shift' = 1 := by
  ext k j
  rw [Matrix.mul_apply, Matrix.one_apply]
  simp only [shift_apply, shift'_apply, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_eq_single (k - 1)]
  · simp only [sub_add_cancel, ite_true]
    by_cases h : k = j
    · subst h; simp
    · simp [h, Ne.symm h]
  · intro l _ hl
    have : ¬ (k = l + 1) := by
      intro h; apply hl; rw [h, add_sub_cancel_right]
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

omit [NeZero n] in
/-- The exponent identity behind the covariance: `g^{((a+1) % n) b} = g^{(a+1) b}` for `gⁿ = 1`. -/
lemma pow_succ_mod_mul {g : K} (hg : g ^ n = 1) (a b : ℕ) :
    g ^ ((a + 1) % n * b) = g ^ ((a + 1) * b) := by
  rw [pow_eq_pow_mod ((a + 1) % n * b) hg, pow_eq_pow_mod ((a + 1) * b) hg]
  congr 1
  rw [Nat.mul_mod, Nat.mod_mod, ← Nat.mul_mod]

lemma val_add_one (hn : 1 < n) (j : Fin n) : ((j + 1 : Fin n) : ℕ) = (j + 1) % n := by
  rw [Fin.val_add, Fin.val_one', Nat.mod_eq_of_lt hn]

/-- 6:E7 — `W σ = D_1 W`: the Fourier matrix carries the shift to the modulation. -/
theorem W_mul_shift {g : K} (hg : g ^ n = 1) (hn : 1 < n) :
    (W g : Matrix (Fin n) (Fin n) K) * shift = modul g * W g := by
  ext k j
  rw [Matrix.mul_apply, modul, Matrix.diagonal_mul, W_apply]
  simp only [W_apply, shift_apply, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_eq_single (j + 1)]
  · simp only [ite_true]
    rw [val_add_one hn, pow_succ_mod_mul hg, ← pow_add]
    congr 1; ring
  · intro l _ hl; simp [hl]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- 6:E7 — `W D_1 = σ⁻¹ W`: the modulation goes back to the inverse shift. -/
theorem W_mul_modul {g : K} (hg : g ^ n = 1) (hn : 1 < n) :
    (W g : Matrix (Fin n) (Fin n) K) * modul g = shift' * W g := by
  ext k j
  rw [modul, Matrix.mul_diagonal, Matrix.mul_apply, W_apply]
  simp only [W_apply, shift'_apply, ite_mul, one_mul, zero_mul]
  rw [Finset.sum_eq_single (k + 1)]
  · simp only [ite_true]
    rw [val_add_one hn]
    conv_rhs => rw [mul_comm, pow_succ_mod_mul hg]
    rw [← pow_add]
    congr 1; ring
  · intro l _ hl; simp [hl]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- 6:E7 — cardinal Heisenberg covariance: `F σ = D_1 F` and `F D_1 = σ⁻¹ F` for `F = c • W`, any scalar `c`:
the quarter-turn conjugates the shift to the modulation and the modulation to the inverse shift. -/
theorem heisenberg {g : K} (hg : g ^ n = 1) (hn : 1 < n) (c : K) :
    (c • W g : Matrix (Fin n) (Fin n) K) * shift = modul g * (c • W g) ∧
    (c • W g : Matrix (Fin n) (Fin n) K) * modul g = shift' * (c • W g) := by
  constructor
  · rw [smul_mul_assoc, W_mul_shift hg hn, mul_smul_comm]
  · rw [smul_mul_assoc, W_mul_modul hg hn, mul_smul_comm]

/-- The geometric vector `(a^j)_j` is an eigenvector of the shift with eigenvalue `a⁻¹`, for `aⁿ = 1`. -/
theorem shift_mulVec_geom {a : K} (ha : a ^ n = 1) (hn : 1 < n) :
    (shift : Matrix (Fin n) (Fin n) K) *ᵥ (fun j : Fin n => a ^ (j : ℕ))
      = a⁻¹ • (fun j : Fin n => a ^ (j : ℕ)) := by
  ext k
  rw [Matrix.mulVec, dotProduct]
  simp only [shift_apply, ite_mul, one_mul, zero_mul, Pi.smul_apply, smul_eq_mul]
  rw [Finset.sum_eq_single (k - 1)]
  · simp only [sub_add_cancel, ite_true]
    rw [Fin.val_sub, Fin.val_one', Nat.mod_eq_of_lt hn, ← pow_eq_pow_mod _ ha, pow_add]
    have h1 : a ^ (n - 1) = a⁻¹ := by
      symm; apply inv_eq_of_mul_eq_one_right
      rw [← pow_succ', Nat.sub_add_cancel (by omega), ha]
    rw [h1]
  · intro l _ hl
    have : ¬ (k = l + 1) := by intro h; apply hl; rw [h, add_sub_cancel_right]
    simp [this]
  · intro h; exact absurd (Finset.mem_univ _) h

omit [NeZero n] in
/-- 6:E5 — every eigenvalue of `F^{[s]}` is one of the four values `z^{ℓ s}`: apply `Π_m` to an eigenvector. -/
theorem frft_eigenvalue_mem (i z : K) (f : Matrix (Fin n) (Fin n) K) (hi : i ^ 4 = 1)
    (hne : ∀ d : ZMod 4, d ≠ 0 → chi i d ≠ 1) (h4 : (4 : K) ≠ 0) (hf : f ^ 4 = 1) {m : ℕ} [NeZero m]
    (s : ZMod m) (v : Fin n → K) (hv : v ≠ 0) (lam : K) (h : frft i z f s *ᵥ v = lam • v) :
    ∃ ℓ : ZMod 4, lam = psi z (ℓ.val • s) := by
  by_contra hcon
  have hcon' : ∀ ℓ : ZMod 4, lam ≠ psi z (ℓ.val • s) := fun ℓ h => hcon ⟨ℓ, h⟩
  have hzero : ∀ ℓ : ZMod 4, proj i f ℓ *ᵥ v = 0 := by
    intro ℓ
    have h1 : proj i f ℓ *ᵥ (frft i z f s *ᵥ v) = psi z (ℓ.val • s) • (proj i f ℓ *ᵥ v) := by
      rw [Matrix.mulVec_mulVec, proj_mul_frft i z f hi hne h4 hf s ℓ, Matrix.smul_mulVec]
    rw [h, Matrix.mulVec_smul] at h1
    have h2 : (psi z (ℓ.val • s) - lam) • (proj i f ℓ *ᵥ v) = 0 := by rw [sub_smul, h1, sub_self]
    rcases smul_eq_zero.1 h2 with h3 | h3
    · exact absurd (sub_eq_zero.1 h3).symm (hcon' ℓ)
    · exact h3
  apply hv
  calc v = (1 : Matrix (Fin n) (Fin n) K) *ᵥ v := (Matrix.one_mulVec v).symm
    _ = (∑ ℓ : ZMod 4, proj i f ℓ) *ᵥ v := by rw [sum_proj i f hi hne h4]
    _ = ∑ ℓ : ZMod 4, proj i f ℓ *ᵥ v := Matrix.sum_mulVec _ _ _
    _ = 0 := by simp [hzero]

omit [NeZero n] in
/-- 6:C5 — the multiplicities are traces: for an idempotent matrix `P`, `rank P = trace P` (read in the field). -/
theorem rank_eq_trace_of_idempotent {m : ℕ} (P : Matrix (Fin m) (Fin m) K)
    (hP : P * P = P) : (P.rank : K) = P.trace := by
  have hidem : IsIdempotentElem (Matrix.toLin' P) := by
    unfold IsIdempotentElem
    rw [Module.End.mul_eq_comp, ← Matrix.toLin'_mul, hP]
  have hproj := LinearMap.IsIdempotentElem.isProj_range _ hidem
  have htr := hproj.trace
  rw [LinearMap.trace_eq_matrix_trace K (Pi.basisFun K (Fin m)), LinearMap.toMatrix_eq_toMatrix',
    LinearMap.toMatrix'_toLin'] at htr
  rw [htr]
  unfold Matrix.rank
  rw [Matrix.toLin'_apply']


end shift

/-! ## The shell: the projectors, the family, the shift and the spectral obstruction on `𝔽_p`, `p = 4κ + 1` -/

section shellFamily

variable {F : Type*} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F)

omit [NeZero κ] in
/-- `4κ ≡ −1` in a field with `4κ + 1` elements (the normalisation of B6, on the meridian cycle). -/
lemma natCast_four_mul_eq_neg_one (hκ : Fintype.card F = 4 * κ + 1) : ((4 * κ : ℕ) : F) = -1 := by
  have := natCast_card_pred_eq_neg_one (F := F)
  rwa [hκ, Nat.add_sub_cancel] at this

omit [Fintype F] in
/-- The half-period: `g^{2κ} = −1` for a primitive root of order `4κ`. -/
lemma half_period (hg : IsPrimitiveRoot g (4 * κ)) : g ^ (2 * κ) = -1 := by
  have hκ0 : κ ≠ 0 := NeZero.ne κ
  have h2 : IsPrimitiveRoot (g ^ (2 * κ)) 2 := by
    have hd : 2 * κ ∣ 4 * κ := ⟨2, by ring⟩
    have := hg.pow_of_dvd (show 2 * κ ≠ 0 by omega) hd
    have hq : 4 * κ / (2 * κ) = 2 := by
      rw [show 4 * κ = 2 * κ * 2 by ring]; exact Nat.mul_div_cancel_left _ (by omega)
    rwa [hq] at this
  exact h2.eq_neg_one_of_two_right

omit [Fintype F] in
lemma quarter_turn_sq' (hg : IsPrimitiveRoot g (4 * κ)) : (-(g ^ κ)) ^ 2 = -1 := by
  rw [neg_sq, ← pow_mul, mul_comm κ 2, half_period κ g hg]

omit [Fintype F] in
lemma quarter_turn_pow_four (hg : IsPrimitiveRoot g (4 * κ)) : (-(g ^ κ)) ^ 4 = 1 := by
  rw [show (4 : ℕ) = 2 * 2 by norm_num, pow_mul, quarter_turn_sq' κ g hg]; norm_num

omit [Fintype F] in
/-- The characteristic is odd: `2 ≠ 0`, since `g^{2κ} = −1 ≠ 1`. -/
lemma two_ne_zero' (hg : IsPrimitiveRoot g (4 * κ)) : (2 : F) ≠ 0 := by
  intro h2
  have h := half_period κ g hg
  have h1 : (-1 : F) = 1 := by linear_combination -h2
  have hκ0 : κ ≠ 0 := NeZero.ne κ
  have := hg.pow_ne_one_of_pos_of_lt (show 2 * κ ≠ 0 by omega) (show 2 * κ < 4 * κ by omega)
  exact this (by rw [h, h1])

omit [Fintype F] in
lemma four_ne_zero' (hg : IsPrimitiveRoot g (4 * κ)) : (4 : F) ≠ 0 := by
  have h2 := two_ne_zero' κ g hg
  rw [show (4 : F) = 2 * 2 by norm_num]; exact mul_ne_zero h2 h2

omit [Fintype F] in
/-- `(g⁻¹)^κ = −g^κ = i`: the quarter-turn is the `κ`-th power of the refinement base `g⁻¹`. -/
lemma inv_pow_kappa (hg : IsPrimitiveRoot g (4 * κ)) : (g⁻¹) ^ κ = -(g ^ κ) := by
  rw [inv_pow]; apply inv_eq_of_mul_eq_one_right
  have := quarter_turn_sq' κ g hg
  linear_combination -this

omit [Fintype F] [NeZero κ] in
lemma inv_pow_four_kappa (hg : IsPrimitiveRoot g (4 * κ)) : (g⁻¹) ^ (4 * κ) = 1 := by
  rw [inv_pow, hg.pow_eq_one, inv_one]

omit [Fintype F] in
lemma chi_ne_one' (hg : IsPrimitiveRoot g (4 * κ)) : ∀ d : ZMod 4, d ≠ 0 → chi (-(g ^ κ)) d ≠ 1 :=
  chi_ne_one _ (quarter_turn_sq' κ g hg) (two_ne_zero' κ g hg)

/-- 6:B4 — the quarter-turn transform `F = i W` as a `4κ × 4κ` matrix, `i = −g^κ`. -/
def Fmat : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F := (-(g ^ κ)) • W g

/-- 6:B5 — `F² = J` and `F⁴ = 1` on the meridian cycle (the form the fractional family consumes). -/
theorem Fmat_sq (hκ : Fintype.card F = 4 * κ + 1) (hg : IsPrimitiveRoot g (4 * κ)) : Fmat κ g ^ 2 = J := by
  unfold Fmat
  rw [smul_pow, W_sq g hg, natCast_four_mul_eq_neg_one κ hκ, quarter_turn_sq' κ g hg, neg_one_smul,
    neg_one_smul, neg_neg]

theorem Fmat_pow_four (hκ : Fintype.card F = 4 * κ + 1) (hg : IsPrimitiveRoot g (4 * κ)) :
    Fmat κ g ^ 4 = 1 := by
  have h : Fmat κ g ^ 4 = (Fmat κ g ^ 2) ^ 2 := by rw [← pow_mul]
  rw [h, Fmat_sq κ g hκ hg, J_sq]

/-- 6:C1 — the shell projectors `Π_ℓ = ¼ Σ_r i^{−ℓr} F^r`, `ℓ ∈ ZMod 4`. -/
def shellProj (ℓ : ZMod 4) : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F := proj (-(g ^ κ)) (Fmat κ g) ℓ

/-- 6:C1 — the shell family `F^{[s]} = Σ_ℓ g^{−ℓs} Π_ℓ`, `s ∈ ZMod (4κ)`: the refinement base is `g⁻¹`. -/
def shellFrft (s : ZMod (4 * κ)) : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F :=
  frft (-(g ^ κ)) g⁻¹ (Fmat κ g) s

variable (hκ : Fintype.card F = 4 * κ + 1) (hg : IsPrimitiveRoot g (4 * κ))
include hκ hg

/-- 6:C2 — on every shell: `F Π_ℓ = i^ℓ Π_ℓ`, `Π_ℓ Π_m = [ℓ = m] Π_ℓ`, `Σ_ℓ Π_ℓ = 1`. -/
theorem shell_proj (ℓ m : ZMod 4) :
    Fmat κ g * shellProj κ g ℓ = chi (-(g ^ κ)) ℓ • shellProj κ g ℓ ∧
    shellProj κ g ℓ * shellProj κ g m = (if ℓ = m then shellProj κ g ℓ else 0) ∧
    ∑ ℓ : ZMod 4, shellProj κ g ℓ = 1 :=
  ⟨mul_proj _ _ (quarter_turn_pow_four κ g hg) (Fmat_pow_four κ g hκ hg) ℓ,
   proj_mul_proj _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
     (Fmat_pow_four κ g hκ hg) ℓ m,
   sum_proj _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)⟩

/-- 6:C3 — additivity on every shell: `F^{[s+r]} = F^{[s]} F^{[r]}`, a representation of `ZMod (4κ)`. -/
theorem shell_frft_add (s r : ZMod (4 * κ)) :
    shellFrft κ g (s + r) = shellFrft κ g s * shellFrft κ g r :=
  frft_add _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
    (Fmat_pow_four κ g hκ hg) (inv_pow_four_kappa κ g hg) s r

/-- 6:C3 — the cardinal values on every shell: `F^{[mκ]} = F^m`, so `F^{[0]} = 1`, `F^{[κ]} = F`,
`F^{[2κ]} = J`, `F^{[3κ]} = F³ = F⁻¹`, `F^{[4κ]} = 1`. -/
theorem shell_frft_cardinal (m : ℕ) :
    shellFrft κ g (m • (κ : ZMod (4 * κ))) = Fmat κ g ^ m :=
  frft_cardinal _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
    (Fmat_pow_four κ g hκ hg) (inv_pow_four_kappa κ g hg) κ (inv_pow_kappa κ g hg) m

/-- 6:C3 — `F^{[κ]} = F`, `F^{[2κ]} = J`, and the exact `κ`-th root `(F^{[1]})^κ = F`. -/
theorem shell_frft_values :
    shellFrft κ g (κ : ZMod (4 * κ)) = Fmat κ g ∧
    shellFrft κ g (2 • (κ : ZMod (4 * κ))) = J ∧
    shellFrft κ g (1 : ZMod (4 * κ)) ^ κ = Fmat κ g := by
  refine ⟨?_, ?_, ?_⟩
  · have := shell_frft_cardinal κ g hκ hg 1; rwa [one_nsmul, pow_one] at this
  · rw [shell_frft_cardinal κ g hκ hg 2, Fmat_sq κ g hκ hg]
  · unfold shellFrft
    rw [← frft_nsmul _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
      (Fmat_pow_four κ g hκ hg) (inv_pow_four_kappa κ g hg)]
    have := shell_frft_cardinal κ g hκ hg 1
    unfold shellFrft at this
    rwa [one_nsmul, pow_one, ← nsmul_one κ] at this

/-- 6:C8 — every exponent lift `a_ℓ ≡ ℓ (mod 4)` gives an additive family with the cardinal skeleton of the
principal one, on every shell. -/
theorem shell_frftLift (a : ZMod 4 → ℕ) (ha : ∀ ℓ, a ℓ % 4 = ℓ.val) (s r : ZMod (4 * κ)) (m : ℕ) :
    frftLift (-(g ^ κ)) g⁻¹ (Fmat κ g) a (s + r)
      = frftLift (-(g ^ κ)) g⁻¹ (Fmat κ g) a s * frftLift (-(g ^ κ)) g⁻¹ (Fmat κ g) a r ∧
    frftLift (-(g ^ κ)) g⁻¹ (Fmat κ g) a (m • (κ : ZMod (4 * κ))) = Fmat κ g ^ m :=
  ⟨frftLift_add _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
     (Fmat_pow_four κ g hκ hg) (inv_pow_four_kappa κ g hg) a s r,
   frftLift_cardinal _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
     (Fmat_pow_four κ g hκ hg) (inv_pow_four_kappa κ g hg) κ (inv_pow_kappa κ g hg) a ha m⟩

/-- 6:C9 — the conjugate frame `(g⁻¹, −i)`: its transform is `F' = −F³ = −F⁻¹` (since `W(g⁻¹) = W J`), and its
projectors are the shifted ones, `Π'_ℓ = Π_{ℓ+2}`. -/
theorem shell_conj (ℓ : ZMod 4) :
    (-(-(g ^ κ))) • W g⁻¹ = -(Fmat κ g ^ 3) ∧
    proj (-(-(g ^ κ))) (-(Fmat κ g ^ 3)) ℓ = shellProj κ g (ℓ + 2) := by
  have hWJ : (W g⁻¹ : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) = W g * J := by
    ext k j
    rw [W_apply, mul_J_apply, W_apply]
    conv_rhs => rw [pow_mul, pow_neg_val hg.pow_eq_one, ← inv_pow, ← pow_mul]
  refine ⟨?_, ?_⟩
  · rw [hWJ, pow_three, ← sq, Fmat_sq κ g hκ hg]
    unfold Fmat
    rw [smul_mul_assoc, ← neg_smul]
  · exact proj_conj _ _ (quarter_turn_pow_four κ g hg) (quarter_turn_sq' κ g hg) (chi_ne_one' κ g hg)
      (four_ne_zero' κ g hg) (Fmat_pow_four κ g hκ hg) ℓ

/-- 6:D2 — `F^{[s+2κ]} = F^{[s]} J`: the framed domains `s` and `s + 2κ` differ by the parity involution, which
permutes the standard basis (`mul_J_apply`), so they are one unordered measurement basis. -/
theorem shell_frft_add_two_kappa (s : ZMod (4 * κ)) :
    shellFrft κ g (s + 2 • (κ : ZMod (4 * κ))) = shellFrft κ g s * J := by
  rw [shell_frft_add κ g hκ hg, (shell_frft_values κ g hκ hg).2.1]

/-- 6:E7 — on every shell: `F σ = D_1 F` and `F D_1 = σ⁻¹ F`, with `σ σ⁻¹ = 1`. -/
theorem shell_heisenberg :
    Fmat κ g * shift = modul g * Fmat κ g ∧ Fmat κ g * modul g = shift' * Fmat κ g ∧
    (shift : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) * shift' = 1 := by
  have hn : 1 < 4 * κ := by have := NeZero.ne κ; omega
  exact ⟨(heisenberg hg.pow_eq_one hn _).1, (heisenberg hg.pow_eq_one hn _).2, shift_mul_shift'⟩

/-- 6:E5 — the spectral obstruction: the shift has every unit of `𝔽_p` as an eigenvalue (eigenvector `(a^j)_j`),
the family at most four; for `κ ≥ 2` no invertible `T` conjugates `σ` to `F^{[s]}`. -/
theorem shell_spectral_obstruction [DecidableEq F] (hκ2 : 2 ≤ κ) (s : ZMod (4 * κ)) :
    ¬ ∃ T : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F, IsUnit T ∧ T * shift * T⁻¹ = shellFrft κ g s := by
  rintro ⟨T, hT, hconj⟩
  have hdet : IsUnit T.det := (Matrix.isUnit_iff_isUnit_det T).1 hT
  have hn : 1 < 4 * κ := by omega
  -- every unit `a` gives the eigenvalue `a⁻¹` of `F^{[s]}`, with eigenvector `T (a^j)_j`
  have key : ∀ a : Fˣ, ∃ ℓ : ZMod 4, (a : F)⁻¹ = psi g⁻¹ (ℓ.val • s) := by
    intro a
    have ha : (a : F) ^ (4 * κ) = 1 := by
      have := FiniteField.pow_card_sub_one_eq_one (a : F) a.ne_zero
      rwa [hκ, Nat.add_sub_cancel] at this
    set v : Fin (4 * κ) → F := fun j => (a : F) ^ (j : ℕ) with hv
    have hv0 : v ≠ 0 := by
      intro h
      have := congrFun h 0
      simp [hv] at this
    have hσ : (shift : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) *ᵥ v = (a : F)⁻¹ • v := by
      rw [hv, shift_mulVec_geom ha hn]
    have hTv : T *ᵥ v ≠ 0 := by
      intro h
      apply hv0
      have := congrArg (fun w => T⁻¹ *ᵥ w) h
      simp only [Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul T hdet, Matrix.one_mulVec,
        Matrix.mulVec_zero] at this
      exact this
    have heig : shellFrft κ g s *ᵥ (T *ᵥ v) = (a : F)⁻¹ • (T *ᵥ v) := by
      rw [← hconj, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, Matrix.mulVec_mulVec v T⁻¹ T,
        Matrix.nonsing_inv_mul T hdet, Matrix.one_mulVec, hσ, Matrix.mulVec_smul]
    exact frft_eigenvalue_mem _ _ _ (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg) (four_ne_zero' κ g hg)
      (Fmat_pow_four κ g hκ hg) s (T *ᵥ v) hTv _ heig
  choose φ hφ using key
  have hinj : Function.Injective φ := by
    intro a b hab
    have : (a : F)⁻¹ = (b : F)⁻¹ := by rw [hφ a, hφ b, hab]
    exact Units.ext (inv_injective this)
  have hcard := Fintype.card_le_of_injective φ hinj
  rw [Fintype.card_units, hκ, ZMod.card, Nat.add_sub_cancel] at hcard
  omega

omit [Fintype F] [NeZero κ] hκ hg in
/-- A sum over `ZMod 4`, expanded. -/
lemma sum_zmod_four {A : Type*} [AddCommMonoid A] (f : ZMod 4 → A) : ∑ x, f x = f 0 + f 1 + f 2 + f 3 :=
  Fin.sum_univ_four f

omit [Fintype F] hκ in
/-- The values of the character at the four residues: `χ 0 = 1`, `χ 1 = i`, `χ 2 = −1`, `χ 3 = −i`. -/
lemma chi_values : chi (-(g ^ κ)) 0 = 1 ∧ chi (-(g ^ κ)) 1 = -(g ^ κ) ∧ chi (-(g ^ κ)) 2 = -1 ∧
    chi (-(g ^ κ)) 3 = g ^ κ := by
  have hi2 := quarter_turn_sq' κ g hg
  refine ⟨chi_zero _, ?_, ?_, ?_⟩
  · show (-(g ^ κ)) ^ 1 = _; rw [pow_one]
  · show (-(g ^ κ)) ^ 2 = _; rw [hi2]
  · show (-(g ^ κ)) ^ 3 = _; linear_combination (-(g ^ κ)) * hi2

/-- 6:C5 — the parity eigenspaces are the projector sums: `1 − J = 2(Π_1 + Π_3)`, `1 + J = 2(Π_0 + Π_2)`. -/
theorem parity_proj :
    (1 : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) - J = (2 : F) • (shellProj κ g 1 + shellProj κ g 3) ∧
    (1 : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) + J = (2 : F) • (shellProj κ g 0 + shellProj κ g 2) := by
  have hsum := (shell_proj κ g hκ hg 0 0).2.2
  have hsq := pow_eq_sum_proj (-(g ^ κ)) (Fmat κ g) (quarter_turn_pow_four κ g hg) (chi_ne_one' κ g hg)
    (four_ne_zero' κ g hg) (Fmat_pow_four κ g hκ hg) 2
  rw [Fmat_sq κ g hκ hg] at hsq
  obtain ⟨h0, h1, h2, h3⟩ := chi_values κ g hg
  rw [sum_zmod_four] at hsum hsq
  unfold shellProj at hsum ⊢
  have hk2 : (g ^ κ) ^ 2 = -1 := by rw [← pow_mul, mul_comm κ 2, half_period κ g hg]
  rw [h0, h1, h2, h3, one_pow, one_smul, neg_sq, hk2, neg_one_sq, one_smul, neg_one_smul] at hsq
  rw [hsq, ← hsum]
  constructor <;> (ext k j; simp only [Matrix.sub_apply, Matrix.add_apply, Matrix.smul_apply, Matrix.neg_apply,
    neg_one_smul, smul_eq_mul]; ring)

omit [Fintype F] [NeZero κ] hκ hg in
/-- The coordinate vectors and their images: `J e_j = e_{−j}`. -/
lemma J_mulVec_single (j : Fin (4 * κ)) :
    (J : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) *ᵥ Pi.single j 1 = Pi.single (-j) 1 := by
  rw [Matrix.mulVec_single_one]
  ext k
  rw [Matrix.col_apply, J_apply, Pi.single_apply]
  congr 1
  exact propext ⟨fun h => by rw [h, neg_neg], fun h => by rw [h, neg_neg]⟩

omit [NeZero κ] hκ in
/-- An antisymmetric coordinate vector `e_1 − e_{−1}` is not an eigenvector of `F` when `κ ≥ 2`: `(F v)_2 =
−g^κ (g² − g^{−2}) ≠ 0` while `v_2 = 0`. -/
lemma antisym_not_eigen (hκ2 : 2 ≤ κ) (c : F) :
    Fmat κ g *ᵥ (Pi.single (⟨1, by omega⟩ : Fin (4 * κ)) (1 : F) - Pi.single ⟨4 * κ - 1, by omega⟩ 1)
      ≠ c • (Pi.single (⟨1, by omega⟩ : Fin (4 * κ)) (1 : F) - Pi.single ⟨4 * κ - 1, by omega⟩ 1) := by
  intro h
  have hc := congrFun h ⟨2, by omega⟩
  unfold Fmat at hc
  rw [Matrix.smul_mulVec, Matrix.mulVec_sub, Matrix.mulVec_single_one, Matrix.mulVec_single_one] at hc
  simp only [Pi.smul_apply, Pi.sub_apply, Matrix.col_apply, W_apply, Pi.single_apply, smul_eq_mul] at hc
  have hne1 : ¬ ((⟨2, by omega⟩ : Fin (4 * κ)) = ⟨1, by omega⟩) := by simp [Fin.ext_iff]
  have hne2 : ¬ ((⟨2, by omega⟩ : Fin (4 * κ)) = ⟨4 * κ - 1, by omega⟩) := by simp [Fin.ext_iff]; omega
  simp only [hne1, hne2, ite_false, sub_zero, mul_zero] at hc
  have hgκ : g ^ κ ≠ 0 := pow_ne_zero _ (hg.ne_zero (by omega))
  have h1 : g ^ (1 * 2) = g ^ ((4 * κ - 1) * 2) := by
    have := mul_eq_zero.1 hc
    rcases this with h | h
    · exact absurd (neg_eq_zero.1 h) hgκ
    · exact sub_eq_zero.1 h
  have h4 : g ^ 4 = 1 := by
    have h2 : g ^ (1 * 2) * g ^ 2 = g ^ ((4 * κ - 1) * 2) * g ^ 2 := by rw [h1]
    rw [← pow_add, ← pow_add, show (4 * κ - 1) * 2 + 2 = 4 * κ * 2 by omega, pow_mul, hg.pow_eq_one,
      one_pow] at h2
    exact h2
  exact hg.pow_ne_one_of_pos_of_lt (by norm_num) (by omega) h4

/-- `e_0` is not an eigenvector of `F`: `(F e_0)_1 = −g^κ ≠ 0` while `(e_0)_1 = 0`. -/
lemma e0_not_eigen (c : F) :
    Fmat κ g *ᵥ Pi.single (0 : Fin (4 * κ)) (1 : F) ≠ c • Pi.single (0 : Fin (4 * κ)) (1 : F) := by
  intro h
  have hn : 1 < 4 * κ := by have := NeZero.ne κ; omega
  have hc := congrFun h ⟨1, hn⟩
  unfold Fmat at hc
  rw [Matrix.smul_mulVec, Matrix.mulVec_single_one] at hc
  simp only [Pi.smul_apply, Matrix.col_apply, W_apply, Pi.single_apply, smul_eq_mul, Fin.val_zero,
    pow_zero, mul_one] at hc
  have hne : ¬ ((⟨1, hn⟩ : Fin (4 * κ)) = 0) := by simp [Fin.ext_iff]
  simp only [hne, ite_false, mul_zero, neg_eq_zero] at hc
  exact pow_ne_zero _ (hg.ne_zero (by have := NeZero.ne κ; omega)) hc

/-- 6:C5 — `Π_1 ≠ 0` and `Π_3 ≠ 0` for `κ ≥ 2`: otherwise `e_1 − e_{−1}` would be an eigenvector of `F`. -/
theorem shell_odd_proj_ne_zero (hκ2 : 2 ≤ κ) : shellProj κ g 1 ≠ 0 ∧ shellProj κ g 3 ≠ 0 := by
  set v : Fin (4 * κ) → F := Pi.single (⟨1, by omega⟩ : Fin (4 * κ)) (1 : F) - Pi.single ⟨4 * κ - 1, by omega⟩ 1
    with hv
  have hneg1 : -(⟨1, by omega⟩ : Fin (4 * κ)) = ⟨4 * κ - 1, by omega⟩ := by
    ext
    rw [Fin.val_neg]
    have hne : (⟨1, by omega⟩ : Fin (4 * κ)) ≠ 0 := by simp [Fin.ext_iff]
    simp only [hne, ite_false]
  have hneg2 : -(⟨4 * κ - 1, by omega⟩ : Fin (4 * κ)) = ⟨1, by omega⟩ := by
    ext
    rw [Fin.val_neg]
    have hne : (⟨4 * κ - 1, by omega⟩ : Fin (4 * κ)) ≠ 0 := by simp [Fin.ext_iff]; omega
    simp only [hne, ite_false]
    show 4 * κ - (4 * κ - 1) = 1
    omega
  have hJv : J *ᵥ v = -v := by
    rw [hv, Matrix.mulVec_sub, J_mulVec_single κ, J_mulVec_single κ, hneg1, hneg2, neg_sub]
  have hpar : (2 : F) • ((shellProj κ g 1 + shellProj κ g 3) *ᵥ v) = (2 : F) • v := by
    rw [← Matrix.smul_mulVec, ← (parity_proj κ g hκ hg).1, Matrix.sub_mulVec, Matrix.one_mulVec, hJv, sub_neg_eq_add,
      two_smul]
  have hsum : (shellProj κ g 1 + shellProj κ g 3) *ᵥ v = v :=
    smul_right_injective _ (two_ne_zero' κ g hg) hpar
  have h2 := two_ne_zero' κ g hg
  constructor
  · intro h1
    rw [h1, zero_add] at hsum
    have := (shell_proj κ g hκ hg 3 3).1
    apply antisym_not_eigen κ g hg hκ2 (chi (-(g ^ κ)) 3)
    rw [← hv, ← hsum, Matrix.mulVec_mulVec, this, Matrix.smul_mulVec, hsum]
  · intro h3
    rw [h3, add_zero] at hsum
    have := (shell_proj κ g hκ hg 1 1).1
    apply antisym_not_eigen κ g hg hκ2 (chi (-(g ^ κ)) 1)
    rw [← hv, ← hsum, Matrix.mulVec_mulVec, this, Matrix.smul_mulVec, hsum]

/-- 6:C5 — `Π_0 ≠ 0` and `Π_2 ≠ 0` for every `κ ≥ 1`: otherwise `e_0` would be an eigenvector of `F`. -/
theorem shell_even_proj_ne_zero : shellProj κ g 0 ≠ 0 ∧ shellProj κ g 2 ≠ 0 := by
  set v : Fin (4 * κ) → F := Pi.single (0 : Fin (4 * κ)) (1 : F) with hv
  have hJv : J *ᵥ v = v := by rw [hv, J_mulVec_single κ, neg_zero]
  have hpar : (2 : F) • ((shellProj κ g 0 + shellProj κ g 2) *ᵥ v) = (2 : F) • v := by
    rw [← Matrix.smul_mulVec, ← (parity_proj κ g hκ hg).2, Matrix.add_mulVec, Matrix.one_mulVec, hJv, two_smul]
  have hsum : (shellProj κ g 0 + shellProj κ g 2) *ᵥ v = v :=
    smul_right_injective _ (two_ne_zero' κ g hg) hpar
  constructor
  · intro h0
    rw [h0, zero_add] at hsum
    have := (shell_proj κ g hκ hg 2 2).1
    apply e0_not_eigen κ g hκ hg (chi (-(g ^ κ)) 2)
    rw [← hv, ← hsum, Matrix.mulVec_mulVec, this, Matrix.smul_mulVec, hsum]
  · intro h2
    rw [h2, add_zero] at hsum
    have := (shell_proj κ g hκ hg 0 0).1
    apply e0_not_eigen κ g hκ hg (chi (-(g ^ κ)) 0)
    rw [← hv, ← hsum, Matrix.mulVec_mulVec, this, Matrix.smul_mulVec, hsum]

/-- 6:C4, 6:D2 — faithfulness on every shell: `s ↦ F^{[s]}` is injective on `ZMod (4κ)`, so the `4κ` fractional
domains are distinct. For `κ ≥ 2` the odd projector `Π_1` is nonzero (C5); for `κ = 1` one of `Π_1`, `Π_3` is,
and both indices are coprime to `4`. -/
theorem shell_frft_injective : Function.Injective (shellFrft κ g) := by
  have hi4 := quarter_turn_pow_four κ g hg
  have hne := chi_ne_one' κ g hg
  have h4 := four_ne_zero' κ g hg
  have hf := Fmat_pow_four κ g hκ hg
  have hz : IsPrimitiveRoot g⁻¹ (4 * κ) := hg.inv
  by_cases hκ2 : 2 ≤ κ
  · exact frft_injective _ _ _ hi4 hne h4 hf hz 1 (shell_odd_proj_ne_zero κ g hκ hg hκ2).1
      (by rw [show (1 : ZMod 4).val = 1 from rfl]; exact Nat.coprime_one_left _)
  · have hκ1 : κ = 1 := by have := NeZero.ne κ; omega
    subst hκ1
    -- `Π_1 + Π_3 = (1 − J)/2 ≠ 0`, since `(1 − J) e_1 = e_1 − e_3 ≠ 0`
    have hne0 : shellProj 1 g 1 + shellProj 1 g 3 ≠ 0 := by
      intro h
      have hpar := (parity_proj 1 g hκ hg).1
      rw [h, smul_zero, sub_eq_zero] at hpar
      have := congrFun (congrFun hpar ⟨1, by norm_num⟩) ⟨1, by norm_num⟩
      rw [Matrix.one_apply_eq, J_apply] at this
      have hne : ¬ ((⟨1, by norm_num⟩ : Fin (4 * 1)) = -⟨1, by norm_num⟩) := by
        simp [Fin.ext_iff, Fin.val_neg]
      simp only [hne, ite_false] at this
      exact one_ne_zero this
    by_cases h1 : shellProj 1 g 1 = 0
    · have h3 : shellProj 1 g 3 ≠ 0 := by rwa [h1, zero_add] at hne0
      exact frft_injective _ _ _ hi4 hne h4 hf hz 3 h3
        (by rw [show (3 : ZMod 4).val = 3 from rfl]; norm_num)
    · exact frft_injective _ _ _ hi4 hne h4 hf hz 1 h1
        (by rw [show (1 : ZMod 4).val = 1 from rfl]; exact Nat.coprime_one_left _)

/-! ### 6:C7 — the multiplicity dichotomy from the traces, given the Gauss sign -/

omit [Fintype F] hκ in
/-- `tr F = i G` and `tr(F J) = tr F³ = i G*`: the diagonal of `W` is `g^{k²}`, that of `W J` is `g^{−k²}`. -/
theorem trace_Fmat : (Fmat κ g).trace = -(g ^ κ) * gauss (4 * κ) g ∧
    (Fmat κ g * J).trace = -(g ^ κ) * gauss (4 * κ) g⁻¹ := by
  constructor
  · unfold Fmat gauss
    rw [Matrix.trace_smul, smul_eq_mul]
    congr 1
  · unfold Fmat gauss
    rw [smul_mul_assoc, Matrix.trace_smul, smul_eq_mul]
    congr 1
    unfold Matrix.trace
    refine Finset.sum_congr rfl (fun k _ => ?_)
    rw [Matrix.diag_apply, mul_J_apply, W_apply, pow_mul, pow_neg_val hg.pow_eq_one, ← inv_pow, ← pow_mul]

omit [Fintype F] hκ hg in
/-- `tr J = 2`: the reversal fixes exactly `0` and `2κ`. -/
theorem trace_J : (J : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F).trace = 2 := by
  unfold Matrix.trace
  simp only [Matrix.diag_apply, J_apply]
  rw [Finset.sum_boole]
  have hset : Finset.univ.filter (fun k : Fin (4 * κ) => k = -k)
      = {0, ⟨2 * κ, by have := NeZero.ne κ; omega⟩} := by
    ext d
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Finset.mem_singleton]
    rw [eq_neg_iff_add_eq_zero]
    exact two_mul_eq_zero_iff κ d
  rw [hset, Finset.card_pair (by simp [Fin.ext_iff]; have := NeZero.ne κ; omega)]
  norm_num

/-- The trace of a projector as the character sum of the traces of the powers,
`4 tr Π_ℓ = Σ_r i^{−ℓr} tr F^r = tr 1 + i^{−ℓ} tr F + i^{−2ℓ} tr J + i^{−3ℓ} tr(F J)`. -/
theorem four_mul_trace_proj (ℓ : ZMod 4) :
    (4 : F) * (shellProj κ g ℓ).trace
      = (Matrix.trace (1 : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F)) + chi (-(g ^ κ)) (-ℓ) * (Fmat κ g).trace
        + chi (-(g ^ κ)) (-(ℓ * 2)) * (J : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F).trace
        + chi (-(g ^ κ)) (-(ℓ * 3)) * (Fmat κ g * J).trace := by
  unfold shellProj proj
  rw [Matrix.trace_smul, smul_eq_mul, mul_inv_cancel_left₀ (four_ne_zero' κ g hg), sum_zmod_four,
    Matrix.trace_add, Matrix.trace_add, Matrix.trace_add, Matrix.trace_smul, Matrix.trace_smul,
    Matrix.trace_smul, Matrix.trace_smul, smul_eq_mul, smul_eq_mul, smul_eq_mul, smul_eq_mul]
  have h0 : phi (Fmat κ g) 0 = 1 := phi_zero _
  have h1 : phi (Fmat κ g) 1 = Fmat κ g := phi_one _
  have h2 : phi (Fmat κ g) 2 = J := by show Fmat κ g ^ 2 = J; exact Fmat_sq κ g hκ hg
  have h3 : phi (Fmat κ g) 3 = Fmat κ g * J := by
    show Fmat κ g ^ 3 = _; rw [pow_three, ← sq, Fmat_sq κ g hκ hg]
  rw [h0, h1, h2, h3, mul_zero, neg_zero, chi_zero, one_mul, mul_one]

omit [Fintype F] hκ hg in
/-- The character on the residues, for the dichotomy's arithmetic. -/
lemma chi_neg_values (i : F) (hi : i ^ 2 = -1) :
    (chi i (-(1 : ZMod 4)) = -i ∧ chi i (-((1 : ZMod 4) * 2)) = -1 ∧ chi i (-((1 : ZMod 4) * 3)) = i) ∧
    (chi i (-(2 : ZMod 4)) = -1 ∧ chi i (-((2 : ZMod 4) * 2)) = 1 ∧ chi i (-((2 : ZMod 4) * 3)) = -1) ∧
    (chi i (-(3 : ZMod 4)) = i ∧ chi i (-((3 : ZMod 4) * 2)) = -1 ∧ chi i (-((3 : ZMod 4) * 3)) = -i) := by
  have h3 : i ^ 3 = -i := by linear_combination i * hi
  refine ⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩
  · show i ^ 3 = -i; exact h3
  · show i ^ 2 = -1; exact hi
  · show i ^ 1 = i; exact pow_one i
  · show i ^ 2 = -1; exact hi
  · show i ^ 0 = 1; exact pow_zero i
  · show i ^ 2 = -1; exact hi
  · show i ^ 1 = i; exact pow_one i
  · show i ^ 2 = -1; exact hi
  · show i ^ 3 = -i; exact h3

/-- The four trace equations with the character values substituted (`i = −g^κ`, `i³ = g^κ`, `i² = −1`). -/
theorem four_mul_trace_proj_values :
    (4 : F) * (shellProj κ g 0).trace = -1 + (Fmat κ g).trace + 2 + (Fmat κ g * J).trace ∧
    (4 : F) * (shellProj κ g 1).trace
      = -1 + g ^ κ * (Fmat κ g).trace + (-1) * 2 + (-(g ^ κ)) * (Fmat κ g * J).trace ∧
    (4 : F) * (shellProj κ g 2).trace = -1 + (-1) * (Fmat κ g).trace + 1 * 2 + (-1) * (Fmat κ g * J).trace ∧
    (4 : F) * (shellProj κ g 3).trace
      = -1 + (-(g ^ κ)) * (Fmat κ g).trace + (-1) * 2 + g ^ κ * (Fmat κ g * J).trace := by
  have hi := quarter_turn_sq' κ g hg
  have hn : ((4 * κ : ℕ) : F) = -1 := natCast_four_mul_eq_neg_one κ hκ
  have hJ := trace_J (F := F) κ
  have h1 : Matrix.trace (1 : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) = -1 := by
    rw [Matrix.trace_one, Fintype.card_fin, hn]
  obtain ⟨⟨c11, c12, c13⟩, ⟨c21, c22, c23⟩, ⟨c31, c32, c33⟩⟩ := chi_neg_values (-(g ^ κ)) hi
  have t0 := four_mul_trace_proj κ g hκ hg 0
  have t1 := four_mul_trace_proj κ g hκ hg 1
  have t2 := four_mul_trace_proj κ g hκ hg 2
  have t3 := four_mul_trace_proj κ g hκ hg 3
  simp only [h1, hJ, zero_mul, neg_zero, chi_zero, one_mul] at t0
  simp only [h1, hJ, c11, c12, c13, neg_neg] at t1
  simp only [h1, hJ, c21, c22, c23] at t2
  simp only [h1, hJ, c31, c32, c33, neg_neg] at t3
  exact ⟨t0, t1, t2, t3⟩

/-- 6:C5 — the parity sums of the traces: `tr Π_0 + tr Π_2 = 2κ + 1` and `tr Π_1 + tr Π_3 = 2κ − 1`, read in the
field (the Gauss-sum terms cancel between the two summands). -/
theorem trace_proj_parity_sums :
    (shellProj κ g 0).trace + (shellProj κ g 2).trace = ((2 * κ + 1 : ℕ) : F) ∧
    (shellProj κ g 1).trace + (shellProj κ g 3).trace = ((2 * κ - 1 : ℕ) : F) := by
  have h4 := four_ne_zero' κ g hg
  have hn : ((4 * κ : ℕ) : F) = -1 := natCast_four_mul_eq_neg_one κ hκ
  have hκF : ((4 * κ : ℕ) : F) = 4 * (κ : F) := by push_cast; ring
  rw [hκF] at hn
  have hκ1 : 1 ≤ κ := Nat.one_le_iff_ne_zero.2 (NeZero.ne κ)
  obtain ⟨t0, t1, t2, t3⟩ := four_mul_trace_proj_values κ g hκ hg
  constructor
  · apply mul_left_cancel₀ h4
    rw [mul_add, t0, t2]; push_cast
    linear_combination (-2 : F) * hn
  · apply mul_left_cancel₀ h4
    rw [mul_add, t1, t3, Nat.cast_sub (by omega)]; push_cast
    linear_combination (-2 : F) * hn

/-- 6:C7 — the multiplicity dichotomy: with `G = ε(1 + i)`, `ε = ±1` (the classical evaluation, import A3), the
traces of the projectors — the multiplicities read in the field — are `(κ, κ, κ+1, κ−1)` for `ε = 1` and
`(κ+1, κ−1, κ, κ)` for `ε = −1`. -/
theorem shell_multiplicity_dichotomy (ε : F) (hε : ε = 1 ∨ ε = -1)
    (hG : gauss (4 * κ) g = ε * (1 + -(g ^ κ))) :
    (ε = 1 → (shellProj κ g 0).trace = κ ∧ (shellProj κ g 1).trace = κ ∧
      (shellProj κ g 2).trace = κ + 1 ∧ (shellProj κ g 3).trace = κ - 1) ∧
    (ε = -1 → (shellProj κ g 0).trace = κ + 1 ∧ (shellProj κ g 1).trace = κ - 1 ∧
      (shellProj κ g 2).trace = κ ∧ (shellProj κ g 3).trace = κ) := by
  have hi := quarter_turn_sq' κ g hg
  have h4 := four_ne_zero' κ g hg
  have hn : ((4 * κ : ℕ) : F) = -1 := natCast_four_mul_eq_neg_one κ hκ
  have hGG := gauss_mul_gauss_inv κ g hg hn
  have hGinv := gauss_inv_of_sign hGG hi (two_ne_zero' κ g hg) ε hε hG
  obtain ⟨hF, hFJ⟩ := trace_Fmat κ g hg
  have hJ := trace_J (F := F) κ
  have h1 : Matrix.trace (1 : Matrix (Fin (4 * κ)) (Fin (4 * κ)) F) = -1 := by
    rw [Matrix.trace_one, Fintype.card_fin, hn]
  have hκF : ((4 * κ : ℕ) : F) = 4 * (κ : F) := by push_cast; ring
  rw [hκF] at hn
  obtain ⟨⟨c11, c12, c13⟩, ⟨c21, c22, c23⟩, ⟨c31, c32, c33⟩⟩ := chi_neg_values (-(g ^ κ)) hi
  have t0 := four_mul_trace_proj κ g hκ hg 0
  have t1 := four_mul_trace_proj κ g hκ hg 1
  have t2 := four_mul_trace_proj κ g hκ hg 2
  have t3 := four_mul_trace_proj κ g hκ hg 3
  simp only [h1, hF, hFJ, hJ, hG, hGinv, zero_mul, neg_zero, chi_zero, one_mul] at t0
  simp only [h1, hF, hFJ, hJ, hG, hGinv, c11, c12, c13] at t1
  simp only [h1, hF, hFJ, hJ, hG, hGinv, c21, c22, c23] at t2
  simp only [h1, hF, hFJ, hJ, hG, hGinv, c31, c32, c33] at t3
  constructor
  · rintro rfl
    refine ⟨mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_⟩
    · rw [t0]; linear_combination (2 : F) * hi - hn
    · rw [t1]; linear_combination (-2 : F) * hi - hn
    · rw [t2]; linear_combination (-2 : F) * hi - hn
    · rw [t3]; linear_combination (2 : F) * hi - hn
  · rintro rfl
    refine ⟨mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_, mul_left_cancel₀ h4 ?_⟩
    · rw [t0]; linear_combination (-2 : F) * hi - hn
    · rw [t1]; linear_combination (2 : F) * hi - hn
    · rw [t2]; linear_combination (2 : F) * hi - hn
    · rw [t3]; linear_combination (-2 : F) * hi - hn

end shellFamily

/-! ## The prime shell `𝔽_p = ZMod p`: multiplicities as ranks (6:C5, 6:C7) -/

section prime

variable (p κ : ℕ) [hp : Fact p.Prime] [NeZero κ] (hpκ : p = 4 * κ + 1)
include hpκ

omit [NeZero κ] in
/-- On the prime shell a trace below `p` determines the rank of an idempotent: `rank P ≡ tr P (mod p)`. -/
theorem rank_eq_of_trace_eq (P : Matrix (Fin (4 * κ)) (Fin (4 * κ)) (ZMod p)) (hP : P * P = P) (m : ℕ)
    (hm : m < p) (htr : P.trace = (m : ZMod p)) : P.rank = m := by
  have h := rank_eq_trace_of_idempotent P hP
  rw [htr] at h
  have hr : P.rank ≤ 4 * κ := by
    have := Matrix.rank_le_card_width P; rwa [Fintype.card_fin] at this
  have := (ZMod.natCast_eq_natCast_iff' _ _ _).1 h
  rwa [Nat.mod_eq_of_lt (by omega), Nat.mod_eq_of_lt hm] at this

omit [NeZero κ] in
/-- Ranks add over orthogonal idempotents on the prime shell: `rank (P + Q) = rank P + rank Q` when `PQ = QP = 0`
(both sides agree modulo `p` by the traces and differ by less than `p`). -/
theorem rank_add_of_orthogonal (P Q : Matrix (Fin (4 * κ)) (Fin (4 * κ)) (ZMod p)) (hP : P * P = P)
    (hQ : Q * Q = Q) (hPQ : P * Q = 0) (hQP : Q * P = 0) : (P + Q).rank = P.rank + Q.rank := by
  have hPQi : (P + Q) * (P + Q) = P + Q := by
    rw [add_mul, mul_add, mul_add, hP, hQ, hPQ, hQP, zero_add, add_zero]
  have h1 := rank_eq_trace_of_idempotent P hP
  have h2 := rank_eq_trace_of_idempotent Q hQ
  have h3 := rank_eq_trace_of_idempotent (P + Q) hPQi
  rw [Matrix.trace_add, ← h1, ← h2, ← Nat.cast_add] at h3
  have hmod := (ZMod.natCast_eq_natCast_iff' _ _ _).1 h3
  have hb : (P + Q).rank ≤ 4 * κ := by
    have := Matrix.rank_le_card_width (P + Q); rwa [Fintype.card_fin] at this
  have hPle : P.rank ≤ (P + Q).rank := by
    have : (P + Q) * P = P := by rw [add_mul, hP, hQP, add_zero]
    have := Matrix.rank_mul_le_left (P + Q) P; rwa [‹(P + Q) * P = P›] at this
  have hQle : Q.rank ≤ (P + Q).rank := by
    have : (P + Q) * Q = Q := by rw [add_mul, hQ, hPQ, zero_add]
    have := Matrix.rank_mul_le_left (P + Q) Q; rwa [‹(P + Q) * Q = Q›] at this
  -- `a ≡ b (mod p)`, `b ≤ a ≤ 2b`, `b < p` force `a = b`
  set a := P.rank + Q.rank with ha
  set b := (P + Q).rank with hb'
  have hba : b ≤ a ∨ a ≤ b := le_total b a
  have hmod' : a % p = b % p := by rw [hmod]
  rcases hba with hba | hab
  · have : (a - b) % p = 0 := by
      rw [← Nat.sub_mod_eq_zero_of_mod_eq hmod']
    have hlt : a - b < p := by omega
    have := Nat.eq_zero_of_dvd_of_lt (Nat.dvd_of_mod_eq_zero this) hlt
    omega
  · have : (b - a) % p = 0 := by
      rw [← Nat.sub_mod_eq_zero_of_mod_eq hmod'.symm]
    have hlt : b - a < p := by omega
    have := Nat.eq_zero_of_dvd_of_lt (Nat.dvd_of_mod_eq_zero this) hlt
    omega

variable (g : ZMod p) (hg : IsPrimitiveRoot g (4 * κ))
include hg

omit [NeZero κ] hg in
lemma card_zmod_shell : Fintype.card (ZMod p) = 4 * κ + 1 := by rw [ZMod.card, hpκ]

/-- 6:C5 — the multiplicity sums on the prime shell: `m_0 + m_2 = 2κ + 1` and `m_1 + m_3 = 2κ − 1`, with
`m_ℓ = rank Π_ℓ`: the even and odd projector sums are the parity idempotents `(1 ± J)/2`, of traces `2κ + 1`
and `2κ − 1`. -/
theorem shell_multiplicity_sums :
    (shellProj κ g 0).rank + (shellProj κ g 2).rank = 2 * κ + 1 ∧
    (shellProj κ g 1).rank + (shellProj κ g 3).rank = 2 * κ - 1 := by
  have hp' : p = 4 * κ + 1 := hpκ
  have hκ1 : 1 ≤ κ := Nat.one_le_iff_ne_zero.2 (NeZero.ne κ)
  have hκc := card_zmod_shell p κ hpκ
  have hidem : ∀ ℓ, shellProj κ g ℓ * shellProj κ g ℓ = shellProj κ g ℓ := by
    intro ℓ; have := (shell_proj κ g hκc hg ℓ ℓ).2.1; simpa using this
  have horth : ∀ ℓ m, ℓ ≠ m → shellProj κ g ℓ * shellProj κ g m = 0 := by
    intro ℓ m h; have := (shell_proj κ g hκc hg ℓ m).2.1; simpa [h] using this
  obtain ⟨s02, s13⟩ := trace_proj_parity_sums κ g hκc hg
  constructor
  · rw [← rank_add_of_orthogonal p κ hpκ _ _ (hidem 0) (hidem 2) (horth 0 2 (by decide)) (horth 2 0 (by decide))]
    have hi2 : (shellProj κ g 0 + shellProj κ g 2) * (shellProj κ g 0 + shellProj κ g 2)
        = shellProj κ g 0 + shellProj κ g 2 := by
      rw [add_mul, mul_add, mul_add, hidem 0, hidem 2, horth 0 2 (by decide), horth 2 0 (by decide)]
      abel
    apply rank_eq_of_trace_eq p κ hpκ _ hi2 (2 * κ + 1) (by rw [hp']; omega)
    rw [Matrix.trace_add]; exact s02
  · rw [← rank_add_of_orthogonal p κ hpκ _ _ (hidem 1) (hidem 3) (horth 1 3 (by decide)) (horth 3 1 (by decide))]
    have hi2 : (shellProj κ g 1 + shellProj κ g 3) * (shellProj κ g 1 + shellProj κ g 3)
        = shellProj κ g 1 + shellProj κ g 3 := by
      rw [add_mul, mul_add, mul_add, hidem 1, hidem 3, horth 1 3 (by decide), horth 3 1 (by decide)]
      abel
    apply rank_eq_of_trace_eq p κ hpκ _ hi2 (2 * κ - 1) (by rw [hp']; omega)
    rw [Matrix.trace_add]; exact s13

/-- 6:C7 — the multiplicity tuple on the prime shell, as natural numbers: with `G = ε(1 + i)` (the classical
evaluation, import A3), `(m_0, m_1, m_2, m_3) = (κ, κ, κ+1, κ−1)` for `ε = 1` and `(κ+1, κ−1, κ, κ)` for `ε = −1`. -/
theorem shell_multiplicity_tuple (ε : ZMod p) (hε : ε = 1 ∨ ε = -1)
    (hG : gauss (4 * κ) g = ε * (1 + -(g ^ κ))) :
    (ε = 1 → (shellProj κ g 0).rank = κ ∧ (shellProj κ g 1).rank = κ ∧
      (shellProj κ g 2).rank = κ + 1 ∧ (shellProj κ g 3).rank = κ - 1) ∧
    (ε = -1 → (shellProj κ g 0).rank = κ + 1 ∧ (shellProj κ g 1).rank = κ - 1 ∧
      (shellProj κ g 2).rank = κ ∧ (shellProj κ g 3).rank = κ) := by
  have hp' : p = 4 * κ + 1 := hpκ
  have hκc := card_zmod_shell p κ hpκ
  have hidem : ∀ ℓ, shellProj κ g ℓ * shellProj κ g ℓ = shellProj κ g ℓ := by
    intro ℓ; have := (shell_proj κ g hκc hg ℓ ℓ).2.1; simpa using this
  have hd := shell_multiplicity_dichotomy κ g hκc hg ε hε hG
  have hκ1 : 1 ≤ κ := Nat.one_le_iff_ne_zero.2 (NeZero.ne κ)
  have hc1 : ((κ + 1 : ℕ) : ZMod p) = (κ : ZMod p) + 1 := by push_cast; ring
  have hcm : ((κ - 1 : ℕ) : ZMod p) = (κ : ZMod p) - 1 := by rw [Nat.cast_sub hκ1, Nat.cast_one]
  constructor
  · intro h
    obtain ⟨t0, t1, t2, t3⟩ := hd.1 h
    exact ⟨rank_eq_of_trace_eq p κ hpκ _ (hidem 0) κ (by omega) t0,
      rank_eq_of_trace_eq p κ hpκ _ (hidem 1) κ (by omega) t1,
      rank_eq_of_trace_eq p κ hpκ _ (hidem 2) (κ + 1) (by omega) (by rw [t2, hc1]),
      rank_eq_of_trace_eq p κ hpκ _ (hidem 3) (κ - 1) (by omega) (by rw [t3, hcm])⟩
  · intro h
    obtain ⟨t0, t1, t2, t3⟩ := hd.2 h
    exact ⟨rank_eq_of_trace_eq p κ hpκ _ (hidem 0) (κ + 1) (by omega) (by rw [t0, hc1]),
      rank_eq_of_trace_eq p κ hpκ _ (hidem 1) (κ - 1) (by omega) (by rw [t1, hcm]),
      rank_eq_of_trace_eq p κ hpκ _ (hidem 2) κ (by omega) t2,
      rank_eq_of_trace_eq p κ hpκ _ (hidem 3) κ (by omega) t3⟩

end prime

-- Ledger predicates of 6-fourier (generated by make_predicates.py from docs/6-fourier/6-fourier-ledger.json; edit the ledger, not this section)
set_option linter.defProp false in
/-- 6:B5 (p06012) — $\Wt^{2}=-J$, $\Ft^{2}=J$, $\Ft^{4}=I$: the normalized operator generates the four-cycle, on the six shells of Table~\ref{tab:checks}. -/
def p06012 := @FRC.Fourier.shell_relations
set_option linter.defProp false in
/-- 6:B7 (p06014) — $\Wt J=J\Wt$, hence $\Ft J=J\Ft$; $\Vt=V^{+}\oplus V^{-}$ with $\dim V^{+}=2\kap+1$, $\dim V^{-}=2\kap-1$. -/
def p06014 := @FRC.Fourier.shell_relations
/-- 6:C2 (p06016) — $\Pi_\ell^{2}=\Pi_\ell$, $\Pi_\ell\Pi_m=0$ for $\ell\neq m$, $\sum_\ell\Pi_\ell=I$, $\Ft\Pi_\ell=\im^{\ell}\Pi_\ell$. -/
theorem p06016 : (∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → ∀ (ℓ m : ZMod (4 : ℕ)), FRC.Fourier.Fmat κ g * FRC.Fourier.shellProj κ g ℓ = FRC.Fourier.chi (-g ^ κ) ℓ • FRC.Fourier.shellProj κ g ℓ ∧ (FRC.Fourier.shellProj κ g ℓ * FRC.Fourier.shellProj κ g m = if ℓ = m then FRC.Fourier.shellProj κ g ℓ else (0 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F)) ∧ ∑ ℓ, FRC.Fourier.shellProj κ g ℓ = (1 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F)) ∧ (∀ {K : Type u_2} [Field K] {A : Type u_3} [Ring A] [Algebra K A] (i : K) (f : A), i ^ (4 : ℕ) = (1 : K) → (∀ (d : ZMod (4 : ℕ)), d ≠ (0 : ZMod (4 : ℕ)) → FRC.Fourier.chi i d ≠ (1 : K)) → (4 : K) ≠ (0 : K) → f ^ (4 : ℕ) = (1 : A) → ∀ (ℓ m : ZMod (4 : ℕ)), FRC.Fourier.proj i f ℓ * FRC.Fourier.proj i f m = if ℓ = m then FRC.Fourier.proj i f ℓ else (0 : A)) ∧ ∀ {K : Type u_4} [Field K] {A : Type u_5} [Ring A] [Algebra K A] (i : K) (f : A), i ^ (4 : ℕ) = (1 : K) → (∀ (d : ZMod (4 : ℕ)), d ≠ (0 : ZMod (4 : ℕ)) → FRC.Fourier.chi i d ≠ (1 : K)) → (4 : K) ≠ (0 : K) → ∑ ℓ, FRC.Fourier.proj i f ℓ = (1 : A) :=
  And.intro @FRC.Fourier.shell_proj (And.intro @FRC.Fourier.proj_mul_proj (@FRC.Fourier.sum_proj))
/-- 6:C3 (p06017) — The exact finite-field FrFT: $s\mapsto\Ft^{[s]}$ is a representation of $\Phit$, $\Ft^{[s+r]}=\Ft^{[s]}\Ft^{[r]}$ on every pair of the six shells, with the cardinal values $\Ft^{[0]}=I$, $\Ft^{[\kap]}=\Ft$, $\Ft^{[2\kap]}=J$, $\Ft^{[3\kap]}=\Ft^{-1}$, and $(\Ft^{[1]})^{\kap}=\Ft$. -/
theorem p06017 : (∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → ∀ (s r : ZMod ((4 : ℕ) * κ)), FRC.Fourier.shellFrft κ g (s + r) = FRC.Fourier.shellFrft κ g s * FRC.Fourier.shellFrft κ g r) ∧ (∀ {F : Type u_2} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → ∀ (m : ℕ), FRC.Fourier.shellFrft κ g (m • ↑κ) = FRC.Fourier.Fmat κ g ^ m) ∧ ∀ {F : Type u_3} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → FRC.Fourier.shellFrft κ g ↑κ = FRC.Fourier.Fmat κ g ∧ FRC.Fourier.shellFrft κ g ((2 : ℕ) • ↑κ) = FRC.Fourier.J ∧ FRC.Fourier.shellFrft κ g (1 : ZMod ((4 : ℕ) * κ)) ^ κ = FRC.Fourier.Fmat κ g :=
  And.intro @FRC.Fourier.shell_frft_add (And.intro @FRC.Fourier.shell_frft_cardinal (@FRC.Fourier.shell_frft_values))
/-- 6:C4 (p06018) — Faithfulness: $s\mapsto\Ft^{[s]}$ is injective on $\Z_{4\kap}$ for every $\kap\ge1$; at $\p=5$ the surviving odd projector carries the faithful character. -/
theorem p06018 : ∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → Function.Injective (FRC.Fourier.shellFrft κ g) :=
  @FRC.Fourier.shell_frft_injective
/-- 6:C5 (p06019) — The multiplicities $m_\ell=\operatorname{rank}\Pi_\ell=\dim\ker(\Ft-\im^{\ell}I)$: $m_0+m_2=2\kap+1$, $m_1+m_3=2\kap-1$; $m_0,m_2\ge1$; $m_1,m_3\ge1$ for $\kap\ge2$; at $\p=5$ exactly one of $\Pi_1,\Pi_3$ vanishes. -/
theorem p06019 : (∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → (2 : ℕ) ≤ κ → FRC.Fourier.shellProj κ g (1 : ZMod (4 : ℕ)) ≠ (0 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F) ∧ FRC.Fourier.shellProj κ g (3 : ZMod (4 : ℕ)) ≠ (0 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F)) ∧ (∀ {F : Type u_2} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → FRC.Fourier.shellProj κ g (0 : ZMod (4 : ℕ)) ≠ (0 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F) ∧ FRC.Fourier.shellProj κ g (2 : ZMod (4 : ℕ)) ≠ (0 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F)) ∧ ∀ (p κ : ℕ) [hp : Fact (Nat.Prime p)] [NeZero κ], p = (4 : ℕ) * κ + (1 : ℕ) → ∀ (g : ZMod p), IsPrimitiveRoot g ((4 : ℕ) * κ) → (FRC.Fourier.shellProj κ g (0 : ZMod (4 : ℕ))).rank + (FRC.Fourier.shellProj κ g (2 : ZMod (4 : ℕ))).rank = (2 : ℕ) * κ + (1 : ℕ) ∧ (FRC.Fourier.shellProj κ g (1 : ZMod (4 : ℕ))).rank + (FRC.Fourier.shellProj κ g (3 : ZMod (4 : ℕ))).rank = (2 : ℕ) * κ - (1 : ℕ) :=
  And.intro @FRC.Fourier.shell_odd_proj_ne_zero (And.intro @FRC.Fourier.shell_even_proj_ne_zero (@FRC.Fourier.shell_multiplicity_sums))
/-- 6:C7 (p06021) — The multiplicity dichotomy: with $G=\sum_{k}\gen^{k^{2}}=\varepsilon(1+\im)$ (A3), the tuple is $(\kap,\kap,\kap+1,\kap-1)$ for $\varepsilon=+1$ and $(\kap+1,\kap-1,\kap,\kap)$ for $\varepsilon=-1$; $GG^{*}=-2$ and $\varepsilon(\gen^{-1})=-\varepsilon(\gen)$. Exact on the $38$ primitive frames of $\p\in\{5,13,17,29,37\}$ and the $16$ of $\p=41$. -/
theorem p06021 : (∀ {K : Type u_1} [Field K] (κ : ℕ) [NeZero κ] (g : K), IsPrimitiveRoot g ((4 : ℕ) * κ) → ↑((4 : ℕ) * κ) = (-1 : K) → FRC.Fourier.gauss ((4 : ℕ) * κ) g * FRC.Fourier.gauss ((4 : ℕ) * κ) g⁻¹ = (-2 : K)) ∧ (∀ {K : Type u_2} [Field K] {n : ℕ} {g i : K}, FRC.Fourier.gauss n g * FRC.Fourier.gauss n g⁻¹ = (-2 : K) → i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → ∀ (ε : K), ε = (1 : K) ∨ ε = (-1 : K) → FRC.Fourier.gauss n g = ε * ((1 : K) + i) → FRC.Fourier.gauss n g⁻¹ = -ε * ((1 : K) + -i)) ∧ ∀ (p κ : ℕ) [hp : Fact (Nat.Prime p)] [NeZero κ], p = (4 : ℕ) * κ + (1 : ℕ) → ∀ (g : ZMod p), IsPrimitiveRoot g ((4 : ℕ) * κ) → ∀ (ε : ZMod p), ε = (1 : ZMod p) ∨ ε = (-1 : ZMod p) → FRC.Fourier.gauss ((4 : ℕ) * κ) g = ε * ((1 : ZMod p) + -g ^ κ) → (ε = (1 : ZMod p) → (FRC.Fourier.shellProj κ g (0 : ZMod (4 : ℕ))).rank = κ ∧ (FRC.Fourier.shellProj κ g (1 : ZMod (4 : ℕ))).rank = κ ∧ (FRC.Fourier.shellProj κ g (2 : ZMod (4 : ℕ))).rank = κ + (1 : ℕ) ∧ (FRC.Fourier.shellProj κ g (3 : ZMod (4 : ℕ))).rank = κ - (1 : ℕ)) ∧ (ε = (-1 : ZMod p) → (FRC.Fourier.shellProj κ g (0 : ZMod (4 : ℕ))).rank = κ + (1 : ℕ) ∧ (FRC.Fourier.shellProj κ g (1 : ZMod (4 : ℕ))).rank = κ - (1 : ℕ) ∧ (FRC.Fourier.shellProj κ g (2 : ZMod (4 : ℕ))).rank = κ ∧ (FRC.Fourier.shellProj κ g (3 : ZMod (4 : ℕ))).rank = κ) :=
  And.intro @FRC.Fourier.gauss_mul_gauss_inv (And.intro @FRC.Fourier.gauss_inv_of_sign (@FRC.Fourier.shell_multiplicity_tuple))
set_option linter.defProp false in
/-- 6:C8 (p06022) — Exponent lifts: every lift $a_\ell\equiv\ell\pmod4$, $U^{(a)}_s=\sum_\ell\gen^{-a_\ell s}\Pi_\ell$, is additive with the same cardinal skeleton, $U^{(a)}_{s+r}=U^{(a)}_sU^{(a)}_r$ and $U^{(a)}_{m\kap}=\Ft^{m}$. -/
def p06022 := @FRC.Fourier.shell_frftLift
/-- 6:C9 (p06023) — The conjugate reframing $(\gen,\im)\mapsto(\gen^{-1},-\im)$: exactly $\Ft'=-\Ft^{-1}$ and $\Pi'_\ell=\Pi_{\ell+2}$; the operator relations, cardinal values, additivity and faithfulness hold on the conjugate frame, and its multiplicity tuple is the other pattern of C7. -/
theorem p06023 : ∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → ∀ (ℓ : ZMod (4 : ℕ)), - -g ^ κ • FRC.Fourier.W g⁻¹ = -FRC.Fourier.Fmat κ g ^ (3 : ℕ) ∧ FRC.Fourier.proj (- -g ^ κ) (-FRC.Fourier.Fmat κ g ^ (3 : ℕ)) ℓ = FRC.Fourier.shellProj κ g (ℓ + (2 : ZMod (4 : ℕ))) :=
  @FRC.Fourier.shell_conj
set_option linter.defProp false in
/-- 6:D2 (p06025) — The $4\kap$ framed domains are pairwise distinct; read as unordered measurement bases $B_{s+2\kap}=B_s$, since $\Ft^{[s+2\kap]}=\Ft^{[s]}J$ and $J$ permutes the standard basis. -/
def p06025 := And.intro @FRC.Fourier.shell_frft_injective (And.intro @FRC.Fourier.shell_frft_add_two_kappa (@FRC.Fourier.mul_J_apply))
/-- 6:E2 (p06031) — $R_s\in SO(2,\Fp)$, and $s\mapsto R_s$ is an isomorphism $\Phit\simeq SO(2,\Fp)$ with $|SO(2,\Fp)|=\p-1=4\kap$: the full rotation group of the $\p^{2}$-point plane is the meridian cycle. Cited definitions (not proofs): FRC.Fourier.unitsEquivCircle. -/
theorem p06031 : (∀ {K : Type u_1} [Field K] (i : K), i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → ∀ (z : K), z ≠ (0 : K) → FRC.Fourier.cc z ^ (2 : ℕ) + FRC.Fourier.dd i z ^ (2 : ℕ) = (1 : K)) ∧ (∀ {K : Type u_2} [Field K] (i : K), i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → ∀ (z w : K), z ≠ (0 : K) → w ≠ (0 : K) → FRC.Fourier.rot i (z * w) = FRC.Fourier.rot i z * FRC.Fourier.rot i w) ∧ ∀ {K : Type u_3} [Field K] (i : K) [Fintype K] [DecidableEq K], i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → Fintype.card (FRC.Fourier.Circle K) = Fintype.card K - (1 : ℕ) :=
  And.intro @FRC.Fourier.circle (And.intro @FRC.Fourier.rot_mul (@FRC.Fourier.card_circle))
/-- 6:E3 (p06032) — The cardinal-skeleton dictionary $M_s\leftrightarrow s\leftrightarrow z_s\leftrightarrow R_s$ with $R_0=I$, $R_\kap=w$, $R_{2\kap}=-I$, $R_{3\kap}=w^{-1}$ (the $R_\kap$ column of Table~\ref{tab:checks}), $z_\kap=\im$; the FRC-native and Weil families stand in cardinal Weil correspondence, the Weil side by the normalization of A2. -/
theorem p06032 : ∀ {K : Type u_1} [Field K] (i : K), i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → FRC.Fourier.rot i (1 : K) = (1 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Fourier.rot i i = !![(0 : K), (-1 : K); (1 : K), (0 : K)] ∧ FRC.Fourier.rot i (-1 : K) = (-1 : Matrix (Fin (2 : ℕ)) (Fin (2 : ℕ)) K) ∧ FRC.Fourier.rot i (-i) = !![(0 : K), (1 : K); (-1 : K), (0 : K)] :=
  @FRC.Fourier.rot_cardinal
set_option linter.defProp false in
/-- 6:E5 (p06034) — Spectral obstruction: for $\kap\ge2$ no invertible $T$ on $\Vt$ satisfies $T\sigma T^{-1}=\Ft^{[s]}$ for any $s$; the cyclic groups $\langle\sigma\rangle$ and $\langle\Ft^{[1]}\rangle$, of the same order $4\kap$, are not conjugate. -/
def p06034 := @FRC.Fourier.shell_spectral_obstruction
/-- 6:E6 (p06035) — Common character sector: on $E_1=\operatorname{im}\Pi_1\neq0$ ($\kap\ge2$) $\Ft^{[s]}=\gen^{-s}I$, the intertwiner $\Ft^{[s]}T_v=T_vS_{-s}$ on every $x\in\Fp$ and $s$, and $R_s(1,-\im)^{\mathsf T}=\gen^{-s}(1,-\im)^{\mathsf T}$. -/
theorem p06035 : (∀ {K : Type u_1} [Field K] {A : Type u_2} [Ring A] [Algebra K A] {n : ℕ} (i z : K) (f : A), i ^ (4 : ℕ) = (1 : K) → (∀ (d : ZMod (4 : ℕ)), d ≠ (0 : ZMod (4 : ℕ)) → FRC.Fourier.chi i d ≠ (1 : K)) → (4 : K) ≠ (0 : K) → f ^ (4 : ℕ) = (1 : A) → ∀ (s : ZMod n), FRC.Fourier.frft i z f s * FRC.Fourier.proj i f (1 : ZMod (4 : ℕ)) = FRC.Fourier.psi z s • FRC.Fourier.proj i f (1 : ZMod (4 : ℕ))) ∧ ∀ {K : Type u_3} [Field K] (i : K), i ^ (2 : ℕ) = (-1 : K) → (2 : K) ≠ (0 : K) → ∀ (z : K), z ≠ (0 : K) → (FRC.Fourier.rot i z).mulVec ![(1 : K), -i] = z • ![(1 : K), -i] :=
  And.intro @FRC.Fourier.frft_mul_proj_one (@FRC.Fourier.rot_eigenline)
/-- 6:E7 (p06036) — Cardinal Heisenberg covariance: $\Ft\sigma\Ft^{-1}=D_1$, $\Ft D_1\Ft^{-1}=\sigma^{-1}$; $\Ft^{r}\sigma=\sigma_r\Ft^{r}$ with $(\sigma,D_1,\sigma^{-1},D_1^{-1})$; the expansion \eqref{eq:conj-expansion}; $\Ft^{[s]}\sigma\Ft^{[s]-1}$ monomial exactly at the four cardinal indices and non-monomial at every one of the $112$ intermediate indices of $\p\in\{13,17,29,37,41\}$. -/
theorem p06036 : ∀ {F : Type u_1} [Field F] [Fintype F] (κ : ℕ) [NeZero κ] (g : F), Fintype.card F = (4 : ℕ) * κ + (1 : ℕ) → IsPrimitiveRoot g ((4 : ℕ) * κ) → FRC.Fourier.Fmat κ g * FRC.Fourier.shift = FRC.Fourier.modul g * FRC.Fourier.Fmat κ g ∧ FRC.Fourier.Fmat κ g * FRC.Fourier.modul g = FRC.Fourier.shift' * FRC.Fourier.Fmat κ g ∧ FRC.Fourier.shift * FRC.Fourier.shift' = (1 : Matrix (Fin ((4 : ℕ) * κ)) (Fin ((4 : ℕ) * κ)) F) :=
  @FRC.Fourier.shell_heisenberg
-- end ledger predicates

end FRC.Fourier
